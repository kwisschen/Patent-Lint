# SPDX-License-Identifier: LicenseRef-PolyForm-Strict-1.0.0
# Copyright (c) 2025-2026 Christopher Chen
"""Patent claim parsing and analysis.

Parses claim text into structured Claim objects and detects
wording/formatting issues. Patterns validated against real U.S. patent conventions.
"""

import re

from patentlint.models import Claim, ClaimWordingResult

# Pattern to detect claim dependency references.
# Supports: "claim 1", "claims 1-3", "according to claim 1",
# "as recited in claim 1", "as set forth in claim 1", "as defined in claim 1"
_DEP_REF = re.compile(
    r"\b("
    r"(according\s+to\s+)?"
    r"|(as\s+(recited|set\s+forth|defined)\s+in\s+)"
    r")?"
    r"claims?\s+\d+(?:\s*(?:to|and|or|-)\s*\d+)?\b",
    re.IGNORECASE,
)

# Body cross-reference shape: `(the|said) <NP up to 5 words>
# (of|according to|as recited in|...) claim N`. Detects 引用記載型式
# (incorporation-by-reference) inside the claim body - the English
# equivalent of TW `如請求項N所述的X`. Common in TW/JP-translated US
# drafts: `A module, comprising: the X according to claim 1; ...`.
#
# Populates Claim.quoted_references so the antecedent walker can chain
# to the referenced claim even when the statutory independence
# classification doesn't route through dependencies. The 5-word NP cap
# distinguishes body cross-refs (typically `the <short head noun>
# according to claim N`) from a long preamble that happens to end in
# `of claim N` - without the cap, an entire body sentence preceding
# `claim N` would match.
#
# MPEP § 2173.05(b) "reasonably ascertainable" antecedent standard
# supports treating these body cross-refs as antecedent-providing for
# their named element; MPEP § 608.01(n) recognizes cross-reference
# forms.
_BODY_CROSS_REF = re.compile(
    r"\b(?:the|said)\s+"
    r"[\w\-]+(?:\s+[\w\-]+){0,4}\s+"
    r"(?:of|according\s+to|"
    r"as\s+(?:in|claimed\s+in|recited\s+in|set\s+forth\s+in|defined\s+in))"
    r"\s*claims?\s+(\d+)\b",
    re.IGNORECASE,
)

# Pattern to match individual claim blocks.
# Uses [\r\n] instead of \n for cross-platform .docx compatibility.
_CLAIM_BLOCK = re.compile(
    r"(?m)^\s*(\d{1,3})\.\s*(.*?)(?=[\r\n]+\s*\d{1,3}\.\s|\Z)",
    re.DOTALL,
)

# PDF→text whitespace collapse: dep-preamble "of claim N" sometimes loses
# its space ("ofclaim N") in machine-translated/PDF-extract pipelines. The
# walker then fails to match the dep-preamble exclusion and emits the
# whole "the X ofclaim N" as a §112(b) reference. Normalize so downstream
# regexes (incl. _DEP_REF above and the dep-preamble body-scan exclusion)
# see canonical spacing. Idempotent on already-spaced text.
#
# R35 (2026-05-04): widened from `of\s*claims?` to `(of|to)\s*claims?`.
# US round-1 corpus has 564 `toclaim N` occurrences (`according toclaim 7`)
# in addition to 10316 `ofclaim` occurrences - same root cause (Google
# Patents PDF→HTML extraction collapses prep-then-claim whitespace).
# Without `to` coverage, dep-claims using `according to claim N` form
# parsed as independent → broken chain → walker_fp inflation.
#
# R15 (2026-06-23, ADR-159 Zero-FP Sweep 1A): widened to add `in`. US
# round-1 corpus has 543 `inclaim N` occurrences - the `as claimed in
# claim N` / `as recited in claim N` / `as defined in claim N` dependency
# forms whose `in claim` space collapsed (`claimed inclaim 1`). `\bclaims?`
# needs a word boundary before `claim`, which `inclaim` lacks, so `_DEP_REF`
# missed them → those dep-claims classified independent → ancestor chain
# empty → every body reference (`the host computer`, `the BIOS`, ...) emitted
# as a spurious §112(b) finding (US9158628B2 alone: ~100). Same PDF/HTML
# whitespace-collapse root cause as `of`/`to`; same documented artifact as
# R11's `as inclaim 1` dep break. `\bin` cannot match inside `within`,
# `main`, `obtain` (no word boundary before the embedded `in`). Resolving a
# dependency only ADDS ancestor-intro coverage → can only SILENCE antecedent
# FPs, never hide a real missing antecedent (maximally FN-safe).
_OFCLAIM_FIX = re.compile(r"\b(of|to|in|with|as)\s*(claims?)\b", re.IGNORECASE)
# R17 (2026-06-24): `with`/`as` join the prep set. `withclaim N` (34x) is the
# `in accordance with claim N` dependency preamble; `asclaim N` (17x) is the
# `... media as [claimed/recited in] claim N` form - both whitespace-collapsed
# so `_DEP_REF` missed them and the dep-claim parsed independent. Same FN-safe
# dependency-resolution play as R15. Only the COLLAPSED form is newly affected
# (properly-spaced `as claim N` already triggers `_DEP_REF`).

# R35 (2026-05-04): claim-number → following-word boundary fix. After
# the OFCLAIM normalization above, US corpus still has 1257 occurrences
# of `claim N<word>` (no space between digit and following letter):
# `claim 1wherein` 825x, `claim 1further` 214x, `claim 1comprising` 105x,
# `claim 1where` 36x, etc. Python regex `\b` requires a non-word char
# between the digit and the next letter to fire - without this fix, the
# `_DEP_REF` regex (`claims?\s+\d+\b`) misses these and the affected
# dep-claim falls back to independent classification → ancestor chain
# empty → walker emits spurious antecedent findings on every body
# reference. Idempotent on already-spaced text.
_CLAIM_NUM_BOUNDARY_FIX = re.compile(
    r"(\bclaims?\s+\d+)([a-zA-Z])", re.IGNORECASE
)

# R40 (2026-08-01, report #474): claim-word-less dependency preamble. The
# drafter wrote `The game information system according to 1, wherein ...` -
# a dependency preamble with the word `claim` dropped. `_DEP_REF` requires
# the literal `claim`, so claim 6 parsed INDEPENDENT, its ancestor chain came
# back empty, and every element introduced in claim 1 re-emitted as a §112(b)
# finding: five spurious findings (`the application`, `the display surface`,
# `the game information system`, `the portable electronic device`, `the start
# option`) whose own did-you-mean named the identical term in claim 1. That
# did_you_mean == term signature is the tell for a broken dependency link
# rather than an over-capture.
#
# Same root cause and same FN-safe play as R15/R17/R35 (`ofclaim`/`inclaim`/
# `claim 1wherein`): resolving a dependency only ADDS ancestor-intro coverage,
# so it can only silence antecedent FPs, never hide a real missing antecedent.
#
# Two guards keep the bare form from over-matching, because unlike the earlier
# whitespace repairs this one flips the `independent` classification that other
# checks consume:
#   1. The number must be followed by a clause boundary or `wherein` and must
#      NOT open a digit list - so `operating according to 1, 2, or 3 modes`
#      is not read as a dependency.
#   2. The preamble must sit in the claim PREAMBLE, i.e. before the body
#      begins at the first comma (falling back to a 100-character window when
#      the claim has no comma at all). A dependent-claim preamble precedes the
#      body by definition, so `... wherein the sensor is trimmed according to
#      1, and then sealed` is correctly left alone. This guard only ever
#      REMOVES matches, so it cannot manufacture a dependency.
# The malformed dependency itself still surfaces through the dependency-format
# check - this fix only stops it from cascading into the antecedent walker.
_BARE_DEP_REF = re.compile(
    r"\b(?:according\s+to|as\s+(?:recited|set\s+forth|defined|claimed)\s+in|"
    r"in\s+accordance\s+with)\s+(\d{1,3})\s*"
    r"(?=(?:[,;.](?!\s*\d)|\bwherein\b|$))",
    re.IGNORECASE,
)
_BARE_DEP_PREAMBLE_WINDOW = 100


def _bare_dep_refs(text: str) -> list[int]:
    """Claim numbers from a dependency preamble that omitted the word `claim`."""
    body_start = text.find(",")
    if body_start == -1:
        body_start = _BARE_DEP_PREAMBLE_WINDOW
    return [
        int(m.group(1))
        for m in _BARE_DEP_REF.finditer(text)
        if m.start() < body_start
    ]


# Pattern to detect multiple dependency
_MULTIPLE_DEP = re.compile(
    r"claim(s)?\s+\d+\s*(to|and|or|-)\s*(claim(s)?\s+)?\d+",
    re.IGNORECASE,
)

# MPEP § 2173.01: restrictive absolutes. Over-qualifying a claim limitation
# with absolute language ("must," "essential," "required," etc.) unnecessarily
# narrows scope and can create §112(b) indefiniteness when the specification
# doesn't actually require the absoluteness asserted.
# `key` is intentionally NOT a bare alternation member (#286): it is heavily
# overloaded as an element NOUN ("a key", "the key", "key 12", "pressing the
# key", "a key state") - flagging every occurrence is a false positive. It is a
# restrictive absolute only ADJECTIVALLY, modifying an importance-noun ("a key
# feature/aspect/factor…"). Group 2 fires only in that adjectival context; the
# element-noun use is left alone. The other terms are unambiguously restrictive.
_RESTRICTIVE_ABSOLUTES_CLAIM_RE = re.compile(
    r"\b(always|never|must|solely|every|required|essential|critical|vital)\b"
    r"|\b(key)(?=\s+(?:feature|aspect|factor|role|advantage|benefit|innovation"
    r"|point|characteristic|difference|distinction|parameter|requirement"
    r"|consideration|importance)s?\b)",
    re.IGNORECASE,
)

# MPEP § 2173.05(b): relative / indefinite terminology. Covers probabilistic
# modals, approximation adverbs, frequency qualifiers, relative adjectives,
# and open-ended exemplars that each leave claim scope unclear.
_INDEFINITE_WORDING_CLAIM_RE = re.compile(
    r"\b("
    r"may|might|can|could|should"
    r"|substantially|approximately|capable of|about"
    r"|generally|normally|typically|usually"
    r"|relatively|fairly|reasonably"
    r"|essentially|similar|comparable"
    r"|close|near|fast|slow|hard|soft|wide|narrow"
    # MPEP § 2173.05(d) optional / preferential language (2026-06-25 audit):
    # `optionally` / `if|as desired` / `as needed` / `where appropriate` make
    # it unclear whether the limitation is required; `preferably`/`desirably`
    # are preferential. All high-confidence § 112(b) red flags, low FP in a
    # claim limitation. Kept REVIEW (not FIX) - see check tier note in models.py.
    r"|preferably|desirably|optionally"
    r"|if desired|as desired|as needed|as appropriate|where appropriate"
    r"|in particular"
    r")\b"
    # MPEP § 2173.05(d) open-ended / exemplary language. `and the like`
    # mirrors the existing `or the like`; `e.g.`/`etc.` are the abbreviated
    # forms of `for example`. A lookbehind keeps `e.g.`/`etc.` from matching
    # inside a word; the trailing period is matched literally. `i.e.` is
    # intentionally excluded - it restates/defines (often DEFINITE), unlike
    # the open-ended exemplars.
    r"|\b(for example|such as|kind of|type of|and the like|or the like)\b"
    r"|(?<![A-Za-z])(?:e\.g\.|etc\.)",
    re.IGNORECASE,
)

# Notes on intentionally-excluded tokens (vs. the pre-split history):
# - "means", "step": § 112(f) MPF triggers handled by detect_means_plus_function;
#   keeping them here would double-flag the same token under two checks.
# - "improved", "optimized": no § 2173 support; pure puffery, not indefiniteness.
# - "invention": standalone self-reference is legitimate in many claims (e.g.
#   antecedent-basis patterns); not a § 2173.01 absolute. Removed to cut noise.
# - "it", "high", "low", "long", "short": removed in a prior pass (too many FPs).

# Words that require a comma after "wherein"
_WORDS_REQUIRING_COMMA = [
    "when", "after", "before", "during", "once", "while", "upon", "according",
    "unless", "provided that", "assuming", "contingent upon", "depending on",
    "because", "since", "due to", "owing to", "given that", "considering that",
    "whereas", "as opposed to", "relative to", "between", "among", "within", "based on",
    "if", "as", "on", "under", "in", "at", "for", "along",
]


def is_method_claim(text: str) -> bool:
    """A claim is a method claim if 'method' appears before the first comma."""
    comma_idx = text.find(",")
    method_idx = text.lower().find("method")
    return method_idx != -1 and (comma_idx == -1 or method_idx < comma_idx)


def parse_dependencies(text: str, independent: bool, claim_number: int) -> list[int]:
    """Extract dependency claim numbers from claim text.

    Self-references (e.g., claim 11 listing itself as a parent) are silently
    dropped: such input is parser noise from malformed source, but it causes
    infinite loops in BFS antecedent walkers.
    """
    if independent:
        return []
    dependencies = [
        int(m.group(1)) for m in re.finditer(r"\bclaims?\s*(\d+)\b", text, re.IGNORECASE)
    ]
    dependencies.extend(_bare_dep_refs(text))
    return [d for d in dependencies if d != claim_number]


def parse_claims(claims_text: str) -> list[Claim]:
    """Parse raw claims section text into a list of Claim objects.

    Strips all known claims headers before parsing individual claim blocks.
    """
    cleaned = re.sub(r"(?is)^\s*CLAIMS\s*", "", claims_text)
    cleaned = re.sub(
        r"(?is)^\s*(What\s+is\s+claimed\s+is|I\s+claim|We\s+(hereby\s+)?claim|Claimed\s+are)\s*:\s*",
        "",
        cleaned,
    )

    if not cleaned.strip():
        return []

    claims = []
    for match in _CLAIM_BLOCK.finditer(cleaned):
        claim_number = int(match.group(1))
        # Lowercase the preposition (of/to) to match the original
        # ofclaim-fix behavior; preserve the `Claim`/`claim` capitalization.
        claim_text = _OFCLAIM_FIX.sub(
            lambda m: f"{m.group(1).lower()} {m.group(2)}",
            match.group(2).strip(),
        )
        claim_text = _CLAIM_NUM_BOUNDARY_FIX.sub(r"\1 \2", claim_text)

        independent = not (
            _DEP_REF.search(claim_text) or _bare_dep_refs(claim_text)
        )
        multiple_dependent = bool(_MULTIPLE_DEP.search(claim_text))
        method = is_method_claim(claim_text)
        dependencies = parse_dependencies(claim_text, independent, claim_number)

        # 引用記載型式 / incorporation-by-reference body cross-refs.
        # Scans claim body for `(the|said) <NP> (of|according to|...)
        # claim N` patterns and routes those N's to quoted_references -
        # the antecedent walker traverses both dependencies and
        # quoted_references to build the chain. Mirrors TW parser's
        # existing `quoted_references` semantics (see claims_tw.py:120).
        #
        # Overlap policy: the broad `parse_dependencies` scan above also
        # captures these body-form refs into `dependencies` for backward
        # compatibility with downstream multi-dep / chain-format checks
        # written before the quoted_references mechanism existed.
        # quoted_references records the body-form refs INDEPENDENTLY so
        # future ADRs that split the statutory classification (preamble-
        # only dependencies) have a clean signal already populated. The
        # walker `visited` set deduplicates the overlap during BFS.
        # Only self-refs are filtered (walker-loop guard).
        quoted_refs = []
        for cross_ref_match in _BODY_CROSS_REF.finditer(claim_text):
            ref_num = int(cross_ref_match.group(1))
            if ref_num == claim_number:
                continue
            quoted_refs.append(ref_num)
        quoted_refs = sorted(set(quoted_refs))

        claims.append(Claim(
            id=claim_number,
            text=claim_text,
            independent=independent,
            multiple_dependent=multiple_dependent,
            method_claim=method,
            dependencies=dependencies,
            quoted_references=quoted_refs,
        ))

    return claims


_PARENTHETICAL_PREPS = {"in", "on", "at", "for", "by", "with", "from", "of", "to", "during", "after", "before", "under", "over", "between", "among", "within", "along", "through", "across", "upon"}


def _is_parenthetical_prep_phrase(text_after_comma: str) -> bool:
    """Detect parenthetical prepositional phrases: 'wherein, <prep ...>, <clause>'.

    Pattern: text starts with a preposition and contains another comma
    within ~60 characters, indicating a parenthetical insertion where both
    commas are grammatically correct.
    """
    stripped = text_after_comma.strip().lower()
    first_word = stripped.split()[0] if stripped.split() else ""
    if first_word not in _PARENTHETICAL_PREPS:
        return False
    second_comma = stripped.find(",")
    return 0 < second_comma <= 60


def detect_wherein_issue(claim_text: str) -> bool:
    """Check a single claim for wherein comma issues. Returns True if issue found."""
    for match in re.finditer(r"\bwherein\b", claim_text, re.IGNORECASE):
        wherein_idx = match.start()
        following = claim_text[wherein_idx + 7:].strip()

        if not following:
            continue

        has_comma = following.startswith(",")
        remaining = following.lstrip(",").strip().lower()

        # Skip parenthetical prepositional phrases: "wherein, in each group, the..."
        if has_comma and _is_parenthetical_prep_phrase(remaining):
            continue

        requires_comma = False

        for phrase in _WORDS_REQUIRING_COMMA:
            if remaining == phrase:
                requires_comma = True
                break

            if " " in phrase and remaining.startswith(phrase + " "):
                requires_comma = True
                break

            if " " not in phrase and remaining.startswith(phrase + " "):
                after_phrase = remaining[len(phrase):].strip()
                tokens = after_phrase.split()
                if tokens:
                    next_word = tokens[0]
                    if not re.match(
                        r"(?i)least|most|several|many|few|each|every|any|some|all",
                        next_word,
                    ):
                        requires_comma = True
                        break

        if (requires_comma and not has_comma) or (not requires_comma and has_comma):
            return True

    return False


def detect_incorrect_wherein_commas(claims: list[Claim]) -> list[int]:
    """Returns list of claim IDs with incorrect wherein comma usage."""
    return [c.id for c in claims if detect_wherein_issue(c.text)]


def _scan_claims(pattern: re.Pattern, claims: list[Claim]) -> ClaimWordingResult:
    flagged: list[int] = []
    parts: list[str] = []
    for claim in claims:
        for match in pattern.finditer(claim.text):
            matched = match.group(1) or (match.group(2) if match.lastindex and match.lastindex >= 2 else None)
            if matched is None:
                matched = match.group(0)
            if claim.id not in flagged:
                flagged.append(claim.id)
            parts.append(f'[{claim.id}] → "{matched}"\n              ')
    return ClaimWordingResult(improper_claims=flagged, formatted_phrases="".join(parts))


def detect_restrictive_absolutes_in_claims(claims: list[Claim]) -> ClaimWordingResult:
    """Detect MPEP § 2173.01 restrictive absolutes (must, essential, always, etc.)."""
    return _scan_claims(_RESTRICTIVE_ABSOLUTES_CLAIM_RE, claims)


def detect_indefinite_wording_in_claims(claims: list[Claim]) -> ClaimWordingResult:
    """Detect MPEP § 2173.05(b) relative/indefinite + § 2173.05(d) optional/
    exemplary terminology (may, substantially, approximately, generally,
    relatively, similar, preferably, optionally, if/as desired, for example,
    such as, e.g., etc., and/or the like). REVIEW tier, not FIX - definiteness
    is examiner-judgment-in-context (degree terms are definite when the spec
    supplies a standard, § 2173.05(b)), so the matched word is a flag, not a
    verdict."""
    return _scan_claims(_INDEFINITE_WORDING_CLAIM_RE, claims)
