# SPDX-License-Identifier: LicenseRef-PolyForm-Strict-1.0.0
# Copyright (c) 2025-2026 Christopher Chen
"""CN claim parser - extract claims from Chinese patent .docx text."""

from __future__ import annotations

import re

from patentlint.models import Claim

# Claim number: "1." or "1．" or "1。" or "1、" at start of line.
# The 顿号 (U+3001) terminator is common in firm-template CN drafts even
# though 专利法实施细则 §22 only mandates Arabic numerals (no fixed
# terminator).
# Mirror of the TW decimal guard - see claims_tw.py. Scoped to the DOT forms
# only, because a decimal is written `.` / `．` and never `。` / `、`, so the
# CJK enumeration punctuation keeps its old behaviour. CN had ZERO corpus
# occurrences when this shipped (TW had 14 across 4 drafts), so this is a
# parity fix against a latent defect rather than a measured one - the
# pattern is character-for-character the same and the next CN draft with a
# line-initial decimal would hit it.
_CN_CLAIM_NUM = re.compile(r"^[\s\u3000]*(\d+)\s*(?:[.．](?!\d)|[。、])\s*", re.MULTILINE)

# Mid-paragraph claim boundary: drafters sometimes pack two claims into one
# Word paragraph (no newline between them). Preprocessing inserts a newline
# before a digit+dot token that is preceded by sentence-end punctuation +
# whitespace OR by ≥2 whitespace chars, AND followed by a claim-start
# content character. The lookahead guards against false positives on
# step references (`步骤S2`, `2.3`), inline enumerations, and formulas.
_MID_PARAGRAPH_CLAIM_BOUNDARY = re.compile(
    r"(?:(?<=[。；！？])[\s\u3000]+|(?<=[\s\u3000]{2}))"
    r"(\d+)[\s\u3000]*[.．。、][\s\u3000]*"
    r"(?=[一如根其权依包对将在本])"
)

# Dependency - covers all real-world CN dependent-claim forms:
#   prefix   : 如 | 根据 | 依据 | bare (dominant form in real CNIPA
#              filings is 根据权利要求N所述的; bare form seen in older
#              filings as 权利要求N的)
#   numspec  : N               (single)
#              N{至,到,-}M[中任一/意项]  (range)
#              N或M              (disjunction)
#              N、M[、...][或K]   (enumeration)
#   suffix   : 所述的 | 所述 | bare
#
# The full spec (post-prefix, pre-suffix) is captured in named group
# ``spec`` and expanded into a parent-claim list by
# ``_expand_dependency_spec``.
_NUMSPEC_RANGE = r"\d+\s*[至到\-]\s*\d+(?:\s*中?\s*任[一意]\s*项)?"
_NUMSPEC_ENUM = r"\d+(?:\s*[、,]\s*\d+)+(?:\s*或\s*\d+)?"
_NUMSPEC_OR = r"\d+\s*或\s*\d+"
_NUMSPEC_SINGLE = r"\d+"
_CN_DEPENDENCY = re.compile(
    # Introducing verb: CNIPA 审查指南 §3.3.1 canonical uses 根据; drafters
    # also use 如/依据/按照/依照/基于 or bare form. Match the full set rather
    # than locking to a single verb - pair with the `_CN_DEPENDENCY` usage
    # pattern (validator `_DEP_FORMAT_SINGLE` in analysis/cn_claims.py also
    # accepts the same range).
    r"(?:如|根据|依据|按照|依照|基于|依)?\s*权利要求\s*"
    r"(?P<spec>"
    + f"(?:{_NUMSPEC_RANGE}|{_NUMSPEC_ENUM}|{_NUMSPEC_OR}|{_NUMSPEC_SINGLE})"
    + r")"
    # Trailing connective accepts CNIPA-standard 所述[的] + JP-translation
    # variants (所记载/所揭示/所描述) + bare. All optional so range/or-list
    # references alone still parse (dependency detection uses group captures,
    # not this suffix).
    r"\s*(?:所(?:述|记载|揭示|描述)的?)?"
)

# R43 (2026-05-04): "every preceding claim" multi-dep form. CN drafters
# use `如前述权利要求中任一项所述` / `如以上任一权利要求所述` /
# `如任一前述权利要求所述` to depend on ALL prior claims (functionally
# equivalent to listing 1..N-1). Without recognition, claims of this
# shape parse as INDEPENDENT and downstream walker chain traversal
# fails - surfaced on CN115023827A c3-c14 (10 claims chain-broken;
# ~25 chain-broken walker_fp findings on `阴极材料涂层` / `阳极材料
# 涂层` / `固体聚合物电解质涂层` etc.).
#
# Pattern requires BOTH a "preceding" marker (前述/以上/前面/前) and
# an "any" marker (任[一]?项?) in either word order around 权利要求.
# Word boundaries: 前述/以上/前面/前 anchored to the verb/start, 任一项
# adjacent to 权利要求. Tightness prevents false matches on bare
# `权利要求` text fragments inside a non-dep clause.
_CN_PRECEDING_CLAIMS_DEP = re.compile(
    r"(?:如|根据|依据|按照|依照|基于|依)?\s*"
    r"(?:"
    r"(?:前述|以上|前面|前)\s*权利要求\s*(?:中\s*)?任\s*[一]?\s*项?"
    r"|"
    r"任\s*[一]?\s*(?:前述|以上|前面)\s*权利要求"
    r")"
    r"\s*(?:所(?:述|记载|揭示|描述)的?)?"
)


def _expand_dependency_spec(spec: str) -> list[int]:
    """Expand a dependency spec string into a list of parent claim numbers.

    Accepts the four numspec forms recognized by ``_CN_DEPENDENCY``:

    - ``"1"``              → ``[1]``
    - ``"1至5中任一项"``    → ``[1, 2, 3, 4, 5]``
    - ``"1或3"``            → ``[1, 3]``
    - ``"1、2或3"``         → ``[1, 2, 3]``
    """
    s = re.sub(r"\s+", "", spec)
    # Range form first - contains 至/到/- between the two numbers.
    m = re.match(r"^(\d+)[至到\-](\d+)(?:中?任[一意]项)?$", s)
    if m:
        a, b = int(m.group(1)), int(m.group(2))
        lo, hi = (a, b) if a <= b else (b, a)
        return list(range(lo, hi + 1))
    # Enumeration / disjunction - split on 、 and 或.
    parts = re.split(r"[、,或]", s)
    return [int(p) for p in parts if p.isdigit()]


def parse_cn_claims_docx(text: str) -> list[Claim]:
    """Parse claims from CN patent .docx text.

    CN claims in .docx use plain Arabic numerals: '1.', '2.', etc.
    Dependencies follow the '如权利要求N所述的' format.
    """
    if not text.strip():
        return []

    text = _MID_PARAGRAPH_CLAIM_BOUNDARY.sub(
        lambda m: "\n" + m.group(0).lstrip(), text
    )

    # Find all claim boundaries by number pattern
    matches = list(_CN_CLAIM_NUM.finditer(text))
    if not matches:
        return []

    claims: list[Claim] = []
    for i, match in enumerate(matches):
        num = int(match.group(1))
        # Claim text extends from this match to the next match (or end)
        start = match.start()
        end = matches[i + 1].start() if i + 1 < len(matches) else len(text)
        claim_text = text[start:end].strip()

        # Extract dependencies
        deps: list[int] = []
        for dep_match in _CN_DEPENDENCY.finditer(claim_text):
            deps.extend(_expand_dependency_spec(dep_match.group("spec")))

        # R43 (2026-05-04): "every preceding claim" multi-dep form.
        # `如前述权利要求中任一项所述` -> deps = [1..num-1].
        if not deps and _CN_PRECEDING_CLAIMS_DEP.search(claim_text):
            deps = list(range(1, num))

        # Remove self-references and deduplicate
        deps = sorted(set(d for d in deps if d != num))

        # 引用記載型式 / incorporation-by-reference body cross-refs (TW
        # parity, see claims_tw.py:120). Scans for `如/根据/依据/...
        # 权利要求N 所述[的]X` patterns anywhere in the body. Refs that
        # match the SAME _CN_DEPENDENCY pattern already used for the
        # statutory dependency extraction above - but here we ALSO route
        # them to quoted_references so the antecedent walker has the
        # incorporation signal explicitly. For backward-compatibility,
        # the broad `deps = ...` scan above continues to capture all body
        # refs into dependencies as well - the walker dedup'es when
        # building its chain queue, so the two lists may overlap without
        # double-traversal. Future ADR may split classification cleanly
        # (preamble → dependencies, body → quoted_references) - this
        # populates quoted_references now so the walker is forward-ready.
        quoted_refs: list[int] = []
        for dep_match in _CN_DEPENDENCY.finditer(claim_text):
            spec = dep_match.group("spec")
            for ref_num in _expand_dependency_spec(spec):
                if ref_num == num:
                    continue
                quoted_refs.append(ref_num)
        # quoted_references records every body cross-ref INDEPENDENTLY
        # of the dependencies extraction above (which also currently
        # captures body refs into deps for back-compat with downstream
        # multi-dep / chain-format checks). Overlap is intentional and
        # the walker's `visited` set deduplicates during BFS. Only
        # self-refs are dropped to prevent walker loops.
        quoted_refs = sorted(set(quoted_refs))

        claims.append(Claim(
            id=num,
            text=claim_text,
            independent=len(deps) == 0,
            dependencies=deps,
            quoted_references=quoted_refs,
            multiple_dependent=len(deps) > 1,
            method_claim=False,
        ))

    return claims
