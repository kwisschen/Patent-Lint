# SPDX-License-Identifier: LicenseRef-PolyForm-Strict-1.0.0
# Copyright (c) 2025–2026 Christopher Chen
"""CN claims analysis checks.

Twelve pure functions checking Chinese patent claim formatting
against CNIPA rules (专利法实施细则 and 审查指南).
"""

from __future__ import annotations

import re
import unicodedata
from typing import Any

from patentlint.analysis.cjk_ordinal_guard import (
    normalize_arabic_ordinal_to_cjk,
    ordinal_guard,
)
from patentlint.analysis.cjk_tokenize import jaccard, tokenize_cn
from patentlint.analysis.utils import (
    _dx,
    compute_confidence_score,
    first_ancestor_with_term,
    make_document_dedup_key,
)
from patentlint.analysis.connection_relationships import (
    _CN_CONNECTION_CONFIG,
    check_connection_relationships,
)
from patentlint.models import CheckItem, Claim, CnPatentDocument

# ADR-107 (Phase 8c Stage 2): CN antecedent walker adopts tuple dedup
# (normalized_term, normalized_reference_form) from day 1. TW uses single-key
# dedup pending Phase 9 parity migration. See CLAUDE.md Phase 8c locked
# decision Q3 and Phase 9 follow-up #2.

# Did-you-mean Jaccard threshold (ADR-094). Char-bigram Jaccard at 0.40
# is the calibration v2 sweet spot from the TW walker; inherited for CN.
_DIDYOUMEAN_THRESHOLD_CN = 0.40


def _dedupe_claim_ids(ids: list[int]) -> list[int]:
    """Drop duplicate claim IDs while preserving first-seen order.

    A malformed draft can print two distinct claim bodies under the same
    printed number (e.g., two "44."s in CN115952274B). The parser keeps
    both so ``check_claims_sequential`` can flag the duplication, but
    downstream emit sites should surface each claim ID at most once so
    the report does not render "claims: 44, 44".
    """
    return list(dict.fromkeys(ids))

# ── Check 9 ──────────────────────────────────────────────────────────────


def check_claims_sequential(cn_doc: CnPatentDocument) -> list[CheckItem]:
    """Verify claim IDs are 1, 2, 3, ... N with no gaps."""
    claims = cn_doc.claims
    if not claims:
        return [CheckItem(
            status="pass",
            message="No claims to check.",
            message_key="check.cn.claims.sequential.pass",
            reference="审查指南",
        )]

    for i, claim in enumerate(claims):
        expected = i + 1
        if claim.id != expected:
            return [CheckItem(
                status="amend",
                message=f"Claim numbering is not sequential: expected {expected}, found {claim.id}.",
                message_key="check.cn.claims.sequential.amend",
                details_key="details.cn.claimsSequential",
                details_params={"expected": expected, "found": claim.id},
                reference="审查指南",
                diagnostics=_dx(
                    expected_id=expected,
                    found_id=claim.id,
                    total_claims=len(claims),
                    gap_position=i,
                    is_backward=claim.id < expected,
                    preamble=(claim.text or "")[:80],
                ),
            )]

    return [CheckItem(
        status="pass",
        message="Claim numbers are sequential.",
        message_key="check.cn.claims.sequential.pass",
        reference="审查指南",
    )]


# ── Check 10 ─────────────────────────────────────────────────────────────

# CN dependent-claim preamble connective.
# CNIPA-standard is 所述 (per 专利法实施细则 §25 + CNIPA drafting examples).
# JP-translation variants 所记载/所揭示/所描述 surface in CN patents translated
# from Japanese originals; parse them tolerantly rather than flag them.
# The trailing 的 is optional — CN drafters sometimes write 所述X (without 的)
# when X starts with a measure word or complex noun phrase.
_CN_DEP_CONNECTIVE = r"所(?:述|记载|揭示|描述)的?"

# The introducing verb is NOT constrained: CNIPA drafting commonly uses
# 根据/如/按照/依照/依/依据/基于 + 权利要求N + 所述的, or even the bare
# 权利要求N所述的 form. 审查指南 第二部分第二章 §3.3.1 uses 根据 in its
# canonical example; 如 is equally valid. Requiring a specific verb
# false-positives on nearly all real CN drafts. The actually-enforced
# structure is: 权利要求 + digit + ... + 所述.
_DEP_FORMAT_SINGLE = re.compile(r"权利要求\s*\d+[\s\S]*?" + _CN_DEP_CONNECTIVE)

# Multi-dep alternative-reference forms (per 专利法实施细则 §25 第3款 —
# multi-dep claims must use 择一方式 / alternative reference):
#   (a) `权利要求1或2所述的` — 或 alternative
#   (b) `权利要求1、2或3所述的` — 、 + 或 alternative
#   (c) `权利要求1至3中任一项所述的` — range + 中任一项
#   (d) `权利要求1至3任一项所述的` — range + 任一项 (no 中)
#   (e) `权利要求10至12中任意一项所述的` — range + 中任意一项
#   (f) `权利要求1-3任一项所述的` / `1~3` / `1‑5` (U+2010–U+2015 dashes)
# At least one alternative-reference marker (range-form OR or-form) is required.
_CN_RANGE_SEPARATOR = r"(?:~|至|到|[‐-―\-])"
_CN_ANY_ITEM_QUANTIFIER = r"任\s*(?:意\s*)?(?:一|何)?\s*项"
_DEP_FORMAT_MULTI = re.compile(
    r"权利要求\s*\d+"
    r"(?:"
    #   Range form: `N至M[中[的]任[意][一|何]项]`
    r"\s*" + _CN_RANGE_SEPARATOR + r"\s*(?:权利要求\s*)?\d+"
    r"(?:\s*(?:中(?:\s*的)?\s*)?" + _CN_ANY_ITEM_QUANTIFIER + r")?"
    r"|"
    #   Or/comma form: `或 N`, `、N`, possibly repeated
    r"(?:\s*(?:或|、)\s*(?:权利要求\s*)?\d+)+"
    r"(?:\s*(?:中(?:\s*的)?\s*)?" + _CN_ANY_ITEM_QUANTIFIER + r")?"
    r")"
    r"[\s\S]*?" + _CN_DEP_CONNECTIVE
)


def check_dependency_format(cn_doc: CnPatentDocument) -> list[CheckItem]:
    """Check dependent claims use the 如权利要求N所述的 format."""
    dependents = [c for c in cn_doc.claims if not c.independent]
    if not dependents:
        return [CheckItem(
            status="pass",
            message="No dependent claims to check.",
            message_key="check.cn.claims.dependencyFormat.pass",
            reference="专利法实施细则 §25",
        )]

    bad_claim_ids: list[int] = []
    for claim in dependents:
        if claim.multiple_dependent:
            if not _DEP_FORMAT_MULTI.search(claim.text):
                bad_claim_ids.append(claim.id)
        else:
            if not _DEP_FORMAT_SINGLE.search(claim.text):
                bad_claim_ids.append(claim.id)

    if bad_claim_ids:
        bad_claim_ids = _dedupe_claim_ids(bad_claim_ids)
        claims_str = ", ".join(str(i) for i in bad_claim_ids)
        return [CheckItem(
            status="amend",
            message=f"{len(bad_claim_ids)} dependent claim(s) lack proper dependency format (claims: {claims_str}).",
            message_key="check.cn.claims.dependencyFormat.amend",
            details=f"{len(bad_claim_ids)} claims",
            details_key="details.cn.dependencyFormat",
            details_params={"count": len(bad_claim_ids), "claims": bad_claim_ids},
            reference="专利法实施细则 §25",
            diagnostics=_dx(
                flagged_count=len(bad_claim_ids),
                total_dependents=len(dependents),
                total_claims=len(cn_doc.claims),
                flagged_claim_id=bad_claim_ids[0] if bad_claim_ids else None,
                findings=[
                    {"claim_id": cid, "preamble": (next((c.text for c in cn_doc.claims if c.id == cid), "") or "")[:80]}
                    for cid in bad_claim_ids[:5]
                ],
            ),
        )]

    return [CheckItem(
        status="pass",
        message="All dependent claims use proper dependency format.",
        message_key="check.cn.claims.dependencyFormat.pass",
        reference="专利法实施细则 §25",
    )]


# ── Check 11 ─────────────────────────────────────────────────────────────


def check_excess_claims_count_cn(cn_doc: CnPatentDocument) -> list[CheckItem]:
    """Flag claims that exceed CNIPA fee-free threshold (10 claims).

    CNIPA 实施细则 §93 + 国家发改委 收费标准: the invention-patent
    application base fee includes the first 10 claims; additional
    per-claim fee applies for each claim above 10. Status verify when
    total exceeds 10; PASS otherwise. Threshold uses strict ``>``.

    Specific per-claim amount is intentionally NOT embedded in messages
    so the check stays future-proof against CNIPA fee schedule changes;
    drafters are asked to verify against the current schedule.
    """
    total = len(cn_doc.claims)
    if total <= 10:
        return [CheckItem(
            status="pass",
            message=f"未检测到 CNIPA 超项费触发条件（权利要求总数 {total} 项，实施细则 §93 免费阈值为 10 项以内）。",
            message_key="check.cn.claims.excessClaims.pass",
            reference="专利法实施细则 §93; CNIPA 收费办法",
            diagnostics=_dx(total_count=total),
        )]
    return [CheckItem(
        status="verify",
        message=(
            f"权利要求总数 {total} 项，超过 CNIPA 之 10 项免费阈值 —— "
            f"自第 11 项起每项加收超项费。请对照当前 CNIPA 收费办法核实规费。"
        ),
        message_key="check.cn.claims.excessClaims.verify",
        reference="专利法实施细则 §93; CNIPA 收费办法",
        diagnostics=_dx(total_count=total, excess_count=total - 10),
    )]


def check_self_dependent(cn_doc: CnPatentDocument) -> list[CheckItem]:
    """Check if any claim depends on itself."""
    bad = _dedupe_claim_ids([c.id for c in cn_doc.claims if c.id in c.dependencies])

    if bad:
        claims_str = ", ".join(str(i) for i in bad)
        return [CheckItem(
            status="amend",
            message=f"Self-dependent claims found: {claims_str}.",
            message_key="check.cn.claims.selfDependent.amend",
            details=claims_str,
            details_key="details.cn.selfDependent",
            details_params={"claims": bad},
            reference="专利法实施细则 §25",
            diagnostics=_dx(
                flagged_count=len(bad),
                total_claims=len(cn_doc.claims),
                flagged_claim_id=bad[0] if bad else None,
                findings=[
                    {"claim_id": cid, "preamble": (next((c.text for c in cn_doc.claims if c.id == cid), "") or "")[:80]}
                    for cid in bad[:5]
                ],
            ),
        )]

    return [CheckItem(
        status="pass",
        message="No self-dependent claims.",
        message_key="check.cn.claims.selfDependent.pass",
        details_key="details.cn.pass.selfDependent",
        reference="专利法实施细则 §25",
    )]


# Strip the ``N. `` / ``N．`` / ``N、`` claim-number prefix before checking
# preamble. Mirror of ``parser/claims_cn.py::_CN_CLAIM_NUM`` — keep the
# terminator class in sync.
_CN_CLAIM_NUM_PREFIX = re.compile(r"^[\s　]*\d+\s*[.．。、]\s*")


def check_independent_preamble(cn_doc: CnPatentDocument) -> list[CheckItem]:
    """Advisory: flag independent claims not opening with 「一种」.

    审查指南 第二部分第二章 §3.1.1 uses 一种X as the canonical preamble
    form in its examples, and CNIPA practitioner convention follows this.
    Note: 专利法实施细则 §24 (independent claim format) requires the
    preamble to state the 主题名称 (subject-matter name) but does NOT
    literally mandate 一种 — other preambles that still name the
    subject matter may satisfy the statute.
    Status is therefore VERIFY (advisory), not FIX.

    Dependent-claim opener set (根据/如/按照 etc.) is validated separately
    by ``check_dependency_format``.
    """
    bad: list[int] = []
    for claim in cn_doc.claims:
        if not claim.independent:
            continue
        body = _CN_CLAIM_NUM_PREFIX.sub("", claim.text).lstrip()
        if not body.startswith("一种"):
            bad.append(claim.id)

    if bad:
        bad_sorted = _dedupe_claim_ids(bad)
        claims_str = ", ".join(str(i) for i in bad_sorted)
        return [CheckItem(
            status="verify",
            message=f"Independent claim(s) not opening with 「一种」: {claims_str}.",
            message_key="check.cn.claims.independentPreamble.verify",
            details=claims_str,
            details_key="details.cn.independentPreamble",
            details_params={"count": len(bad_sorted), "claims": bad_sorted},
            reference="审查指南 第二部分第二章 §3.1.1 (canonical example form)",
            diagnostics=_dx(
                flagged_count=len(bad_sorted),
                total_claims=len(cn_doc.claims),
                flagged_claim_id=bad_sorted[0] if bad_sorted else None,
            ),
        )]
    return [CheckItem(
        status="pass",
        message="All independent claims open with 「一种」.",
        message_key="check.cn.claims.independentPreamble.pass",
        reference="审查指南 第二部分第二章 §3.1.1 (canonical example form)",
    )]


# ── Check 12 ─────────────────────────────────────────────────────────────


def check_forward_dependency(cn_doc: CnPatentDocument) -> list[CheckItem]:
    """Check if any claim depends on a higher-numbered claim."""
    bad = _dedupe_claim_ids(
        [c.id for c in cn_doc.claims if any(d > c.id for d in c.dependencies)]
    )

    if bad:
        return [CheckItem(
            status="amend",
            message=f"Forward-referencing claims found: {', '.join(str(i) for i in bad)}.",
            message_key="check.cn.claims.forwardDependency.amend",
            details=", ".join(str(i) for i in bad),
            details_key="details.cn.forwardDependency",
            details_params={"claims": bad},
            reference="专利法实施细则 §25",
            diagnostics=_dx(
                flagged_count=len(bad),
                total_claims=len(cn_doc.claims),
                flagged_claim_id=bad[0] if bad else None,
                findings=[
                    {"claim_id": cid, "preamble": (next((c.text for c in cn_doc.claims if c.id == cid), "") or "")[:80]}
                    for cid in bad[:5]
                ],
            ),
        )]

    return [CheckItem(
        status="pass",
        message="No forward-referencing dependencies.",
        message_key="check.cn.claims.forwardDependency.pass",
        details_key="details.cn.pass.forwardDependency",
        reference="专利法实施细则 §25",
    )]


# ── Check 13 ─────────────────────────────────────────────────────────────


def check_single_sentence(cn_doc: CnPatentDocument) -> list[CheckItem]:
    """Each claim must have exactly one 。 at the end."""
    bad_claim_ids: list[int] = []
    sample_last_cp: int | None = None
    for claim in cn_doc.claims:
        text = claim.text.strip()
        period_count = text.count("。")
        if period_count != 1 or not text.endswith("。"):
            bad_claim_ids.append(claim.id)
            if sample_last_cp is None and text:
                sample_last_cp = ord(text[-1])

    if bad_claim_ids:
        bad_claim_ids = _dedupe_claim_ids(bad_claim_ids)
        claims_str = ", ".join(str(i) for i in bad_claim_ids)
        return [CheckItem(
            status="amend",
            message=f"{len(bad_claim_ids)} claim(s) have invalid sentence structure (claims: {claims_str}).",
            message_key="check.cn.claims.singleSentence.amend",
            details=f"{len(bad_claim_ids)} claims",
            details_key="details.cn.singleSentence",
            details_params={"count": len(bad_claim_ids), "claims": bad_claim_ids},
            reference="审查指南 第二部分第二章",
            diagnostics=_dx(
                flagged_count=len(bad_claim_ids),
                total_claims=len(cn_doc.claims),
                sample_last_codepoint=sample_last_cp,
            ),
        )]

    return [CheckItem(
        status="pass",
        message="All claims are single sentences ending with 。.",
        message_key="check.cn.claims.singleSentence.pass",
        details_key="details.cn.pass.singleSentence",
        reference="审查指南 第二部分第二章",
    )]


# ── Check 14 ─────────────────────────────────────────────────────────────

# CJK char followed by optional space then 2-4 digits, not in parentheses.
# Exclude CJK unit tokens like 重量份, 重量百分比 etc. to avoid chemistry
# false positives (mirror of tw_claims._BARE_NUMERAL CJK unit exclusion).
_CJK_UNIT_TOKENS_CN = (
    # Concentration / ratio (longest first)
    r"重量百分比|重量份|重量比|质量百分比|"
    r"体积百分比|体积比|原子百分比|"
    r"摩尔百分比|摩尔比|摩尔|"
    # Length
    r"毫米|公釐|公分|公尺|公里|"
    r"微米|纳米|奈米|皮米|"
    r"英寸|英吋|英尺|英里|"
    # Mass
    r"毫克|公克|微克|奈克|皮克|纳克|"
    r"公斤|千克|公吨|盎司|磅|"
    # Volume
    r"毫升|公升|微升|奈升|皮升|纳升|"
    r"立方厘米|立方公分|立方米|"
    # Time
    r"毫秒|微秒|纳秒|皮秒|"
    r"分钟|小时|秒钟|"
    # Pressure
    r"千帕|百帕|兆帕|毫帕|微帕|"
    r"大气压|毫巴|"
    # Temperature
    r"摄氏|华氏|开尔文|"
    # Energy / power
    r"千焦|兆焦|毫焦|焦耳|"
    r"千卡|卡路里|"
    r"千瓦|兆瓦|毫瓦|微瓦|"
    r"电子伏特|"
    # Voltage / current
    r"毫伏|微伏|千伏|伏特|"
    r"毫安|微安|千安|安培|"
    # Concentration
    r"毫摩尔|微摩尔|摩尔|"
    r"百万分之|百分之|"
    # Frequency / data
    r"千赫|兆赫|吉赫|赫|"
    r"千比特|兆比特|比特|字节|"
    # Single-char
    r"克|升|份|个|颗|片|秒|天|日|月|年|度|帕|巴|瓦|"
    r"倍率|倍|"
    # Miller-index crystallography suffixes
    r"结晶面|晶面|平面|方向|面"
)
_BARE_NUMERAL = re.compile(
    r"(?<!\()(?<=[\u4e00-\u9fff])\s?\d{2,4}(?!\))"
    r"(?!\d)"  # R67 (2026-05-08): must match full digit run; without this
               # the regex backtracks from `100\u7eb3\u7c73` to `10` (0\u7eb3\u7c73
               # doesn't match the unit list), producing a FP. TW parity.
    r"(?!\s*(?:" + _CJK_UNIT_TOKENS_CN + r"))"
)

# Latin-prefix designators (R1, IC2, LED1) used for circuit / semiconductor
# element references. Same \u5b9e\u65bd\u7ec6\u5219 \u00a721 \u7b2c2\u6b3e / \u00a722 rule \u2014 \u7b26\u53f7 covers
# Latin-prefix too. CJK-anchored to skip standalone citations.
_BARE_LATIN_REF = re.compile(
    r"(?<!\()(?<=[\u4e00-\u9fff])"
    r"\s?[A-Z]{1,5}\d{1,4}[a-zA-Z]?"
    r"(?!\))(?![A-Za-z0-9])"
)


def _ref_numeral_finding_diag_cn(cid: int, claims: list) -> dict:
    """CN parallel of _ref_numeral_finding_diag_tw — adds context_after
    for self-diagnosing reports per R-refnum-1.
    """
    text = next((c.text for c in claims if c.id == cid), "") or ""
    m = _BARE_NUMERAL.search(text)
    if not m:
        m = _BARE_LATIN_REF.search(text)
    if not m:
        return {"claim_id": cid, "first_match": None, "context_after": None}
    return {
        "claim_id": cid,
        "first_match": m.group(0),
        "context_after": text[m.end():m.end() + 8],
    }


def check_reference_numeral_parentheses(cn_doc: CnPatentDocument) -> list[CheckItem]:
    """Find reference numerals in claims not enclosed in parentheses."""
    bad_claim_ids: list[int] = []
    for claim in cn_doc.claims:
        if _BARE_NUMERAL.search(claim.text) or _BARE_LATIN_REF.search(claim.text):
            bad_claim_ids.append(claim.id)

    if bad_claim_ids:
        bad_claim_ids = _dedupe_claim_ids(bad_claim_ids)
        claims_str = ", ".join(str(i) for i in bad_claim_ids)
        return [CheckItem(
            status="verify",
            message=f"{len(bad_claim_ids)} claim(s) have unparenthesized reference numerals (claims: {claims_str}).",
            message_key="check.cn.claims.refNumeralParens.verify",
            details=f"{len(bad_claim_ids)} claims",
            details_key="details.cn.refNumeralParens",
            details_params={"count": len(bad_claim_ids), "claims": bad_claim_ids},
            reference="审查指南",
            diagnostics=_dx(
                flagged_count=len(bad_claim_ids),
                total_claims=len(cn_doc.claims),
                flagged_claim_id=bad_claim_ids[0] if bad_claim_ids else None,
                # R-refnum-1 (2026-04-30): added context_after so future
                # reports of FPs like Miller-index `100面` arrive self-
                # diagnosing without needing the draft. Cross-port from TW.
                findings=[
                    _ref_numeral_finding_diag_cn(cid, cn_doc.claims)
                    for cid in bad_claim_ids[:5]
                ],
            ),
        )]

    return [CheckItem(
        status="pass",
        message="All reference numerals in claims are parenthesized.",
        message_key="check.cn.claims.refNumeralParens.pass",
        reference="审查指南",
    )]


# ── Check 15 ─────────────────────────────────────────────────────────────

# Extract subject matter: text after the last 所述的 (or 的) before 。
_SUBJECT_RE = re.compile(r"所述的(.+?)(?:[，,]|$)")
_LEADING_QUANTIFIER = re.compile(r"^(?:一种|一个|该|所述|所述的)\s*")

# Dependent-claim preamble anchored at start (CN mirror of TW fix): prevents
# body-text 所述的 inside independent claims from hijacking extraction.
# Trailing connective accepts 所(述|记载|揭示|描述)[的] + bare 的 (older form
# 权利要求N的X). JP-translated CN patents keep 所记载 even though CNIPA-standard
# is 所述 — parse the dep preamble tolerantly so subject extraction succeeds.
_DEP_PREAMBLE_CONNECTIVE_CN = r"(?:所(?:述|记载|揭示|描述)的?|的)?"
_DEP_PREFIX_RE_CN = re.compile(
    r"^(?:如|根据|依)权利要求\s*\d+"
    r"(?:\s*(?:~|至|到)\s*\d+)?"
    r"(?:\s*(?:或|、)\s*\d+)*"
    r"(?:\s*中\s*任一?项)?"
    r"\s*" + _DEP_PREAMBLE_CONNECTIVE_CN
)
_INDEP_PREFIX_RE_CN = re.compile(r"^(?:一种|一个)\s*")
# Subject-end boundary: any clause/sentence terminator stops extraction so
# realistic claim preambles (with trailing 。 or ；) yield a clean subject.
_SUBJECT_END_RE_CN = re.compile(r"(?:[，,；。]|其特征在于|其改良在于|其中)")


def _extract_subject_with_path(claim_text: str) -> tuple[str, str]:
    """Extract subject matter + provenance tag (CN mirror of TW helper).

    Returns (subject_text, extraction_path) where path is one of:
      - ``"dep_prefix"``    — matched `_DEP_PREFIX_RE_CN`
      - ``"indep_prefix"``  — matched `_INDEP_PREFIX_RE_CN`
      - ``"subject_re"``    — legacy body-scan `所述的` match path
      - ``"fallthrough"``   — no recognized preamble, returned raw text

    Subject-consistency callers use the path to split genuine mismatches
    from parse-limit fall-throughs (see ADR-145).
    """
    text = re.sub(r"^\s*\d+\s*[.．]\s*", "", claim_text).strip()
    dep_m = _DEP_PREFIX_RE_CN.match(text)
    if dep_m:
        remainder = text[dep_m.end():]
        end_m = _SUBJECT_END_RE_CN.search(remainder)
        return (
            (remainder[:end_m.start()] if end_m else remainder).strip(),
            "dep_prefix",
        )
    indep_m = _INDEP_PREFIX_RE_CN.match(text)
    if indep_m:
        body = text[indep_m.end():]
        end_m = _SUBJECT_END_RE_CN.search(body)
        return (
            (body[:end_m.start()] if end_m else body).strip(),
            "indep_prefix",
        )
    end_m = _SUBJECT_END_RE_CN.search(text)
    if end_m:
        return text[:end_m.start()].strip(), "fallthrough"
    # Legacy 所述的 body scan for claims that don't match preamble shapes
    match = _SUBJECT_RE.search(claim_text)
    if match:
        return match.group(1).strip(), "subject_re"
    return text.strip(), "fallthrough"


def _extract_subject(claim_text: str) -> str:
    """Back-compat wrapper — returns just the subject text."""
    subject, _path = _extract_subject_with_path(claim_text)
    return subject


def _normalize_subject(subject: str) -> str:
    """Strip leading quantifiers for comparison."""
    return _LEADING_QUANTIFIER.sub("", subject).strip()


def check_subject_name_consistency(cn_doc: CnPatentDocument) -> list[CheckItem]:
    """Check dependent claim subject matter matches parent claim subject matter.

    Extract both subjects with the same ``_extract_subject`` helper so a
    descriptive independent-claim preamble like
    ``一种基于深度学习模型的数据生成方法`` does not spuriously diverge from
    a dependent's short-form ``如权利要求1所述的数据生成方法``. Consistency
    allows equality, or either side being a suffix of the other, since
    CN drafters commonly drop qualifier phrases (``基于...的``) when
    re-referencing the parent subject matter.
    """
    claims_by_id = {c.id: c for c in cn_doc.claims}
    dependents = [c for c in cn_doc.claims if not c.independent]

    if not dependents:
        return [CheckItem(
            status="pass",
            message="No dependent claims to check.",
            message_key="check.cn.claims.subjectConsistency.pass",
            reference="审查指南 第二部分第二章",
        )]

    mismatch_ids: list[int] = []
    unclear_ids: list[int] = []
    mismatch_fp: dict[str, Any] | None = None
    unclear_fp: dict[str, Any] | None = None

    for claim in dependents:
        if not claim.dependencies:
            continue
        parent_id = claim.dependencies[0]
        parent = claims_by_id.get(parent_id)
        if not parent:
            continue

        dep_raw, dep_path = _extract_subject_with_path(claim.text)
        parent_raw, parent_path = _extract_subject_with_path(parent.text)
        dep_subject = _normalize_subject(dep_raw)
        parent_subject = _normalize_subject(parent_raw)

        # Parse-limit category — preamble didn't match a recognized shape.
        # ADR-145: emit parseUnclear instead of verify, so bug reports can
        # distinguish walker gaps from drafter-level mismatches.
        if dep_path == "fallthrough" or parent_path == "fallthrough":
            unclear_ids.append(claim.id)
            if unclear_fp is None:
                unclear_fp = {
                    "dep_path": dep_path,
                    "parent_path": parent_path,
                    "dep_subject_charlen": len(dep_subject),
                    "parent_subject_charlen": len(parent_subject),
                }
            continue

        if not dep_subject or not parent_subject:
            continue
        if dep_subject == parent_subject:
            continue
        if parent_subject.endswith(dep_subject) or dep_subject.endswith(parent_subject):
            continue
        mismatch_ids.append(claim.id)
        if mismatch_fp is None:
            mismatch_fp = {
                "dep_path": dep_path,
                "parent_path": parent_path,
                "dep_subject_charlen": len(dep_subject),
                "parent_subject_charlen": len(parent_subject),
            }

    results: list[CheckItem] = []
    if mismatch_ids:
        mismatch_ids = _dedupe_claim_ids(mismatch_ids)
        claims_str = ", ".join(str(i) for i in mismatch_ids)
        results.append(CheckItem(
            status="verify",
            message=f"{len(mismatch_ids)} dependent claim(s) have inconsistent subject matter (claims: {claims_str}).",
            message_key="check.cn.claims.subjectConsistency.verify",
            details=f"{len(mismatch_ids)} claims",
            details_key="details.cn.subjectConsistency",
            details_params={"count": len(mismatch_ids), "claims": mismatch_ids},
            reference="审查指南 第二部分第二章",
            diagnostics=mismatch_fp,
        ))
    if unclear_ids:
        unclear_ids = _dedupe_claim_ids(unclear_ids)
        claims_str = ", ".join(str(i) for i in unclear_ids)
        results.append(CheckItem(
            status="verify",
            message=f"{len(unclear_ids)} dependent claim(s) with an unrecognized preamble — couldn't verify subject consistency (claims: {claims_str}).",
            message_key="check.cn.claims.subjectConsistencyParseUnclear.verify",
            details=f"{len(unclear_ids)} claims",
            details_key="details.cn.subjectConsistencyParseUnclear",
            details_params={"count": len(unclear_ids), "claims": unclear_ids},
            reference="审查指南 第二部分第二章",
            diagnostics=unclear_fp,
        ))
    if results:
        return results

    return [CheckItem(
        status="pass",
        message="Dependent claim subject matter is consistent.",
        message_key="check.cn.claims.subjectConsistency.pass",
        reference="审查指南 第二部分第二章",
    )]


# ── Check 16 ─────────────────────────────────────────────────────────────

_TRANSITION_PHRASES = re.compile(r"其特征在于|其特征是|其改进在于")


def check_transition_phrase(cn_doc: CnPatentDocument) -> list[CheckItem]:
    """Check independent claims contain a characterizing transition."""
    independents = [c for c in cn_doc.claims if c.independent]
    if not independents:
        return [CheckItem(
            status="pass",
            message="No independent claims to check.",
            message_key="check.cn.claims.transitionPhrase.pass",
            reference="审查指南",
        )]

    bad_claim_ids: list[int] = []
    for claim in independents:
        if not _TRANSITION_PHRASES.search(claim.text):
            bad_claim_ids.append(claim.id)

    if bad_claim_ids:
        bad_claim_ids = _dedupe_claim_ids(bad_claim_ids)
        claims_str = ", ".join(str(i) for i in bad_claim_ids)
        return [CheckItem(
            status="verify",
            message=f"{len(bad_claim_ids)} independent claim(s) lack a transition phrase (claims: {claims_str}).",
            message_key="check.cn.claims.transitionPhrase.verify",
            details=f"{len(bad_claim_ids)} claims",
            details_key="details.cn.transitionPhrase",
            details_params={"count": len(bad_claim_ids), "claims": bad_claim_ids},
            reference="审查指南",
            diagnostics=_dx(
                flagged_count=len(bad_claim_ids),
                total_independent=len(independents),
                total_claims=len(cn_doc.claims),
                flagged_claim_id=bad_claim_ids[0] if bad_claim_ids else None,
                findings=[
                    {"claim_id": cid, "preamble": (next((c.text for c in cn_doc.claims if c.id == cid), "") or "")[:120]}
                    for cid in bad_claim_ids[:5]
                ],
            ),
        )]

    return [CheckItem(
        status="pass",
        message="All independent claims contain a transition phrase.",
        message_key="check.cn.claims.transitionPhrase.pass",
        details_key="details.cn.pass.transitionPhrase",
        reference="审查指南",
    )]


# ── Check 17 ─────────────────────────────────────────────────────────────

_TW_TERMS = re.compile(r"请求项|請求項")


def check_tw_terminology(cn_doc: CnPatentDocument) -> list[CheckItem]:
    """Scan claims for Taiwan-specific terminology."""
    hits: list[tuple[int, str]] = []
    seen: set[tuple[int, str]] = set()
    for claim in cn_doc.claims:
        for m in _TW_TERMS.finditer(claim.text):
            token = m.group(0)
            key = (claim.id, token)
            if key in seen:
                continue
            seen.add(key)
            hits.append((claim.id, token))

    if hits:
        return [CheckItem(
            status="amend",
            message="Taiwan-specific terminology found in claims.",
            message_key="check.cn.claims.twTerminology.amend",
            details_key="details.cn.twTerminology",
            details_params={
                "flagged_phrases": {
                    "items": [{"kind": "term", "token": token, "location": cid} for cid, token in hits]
                },
            },
            reference="",
            diagnostics=_dx(
                flagged_claim_id=hits[0][0],
                hit_count=len(hits),
                total_claims=len(cn_doc.claims),
                findings=[
                    {"claim_id": cid, "token": token}
                    for cid, token in hits[:5]
                ],
            ),
        )]

    return [CheckItem(
        status="pass",
        message="No Taiwan-specific terminology found.",
        message_key="check.cn.claims.twTerminology.pass",
        reference="",
    )]


# ── Check 18 ─────────────────────────────────────────────────────────────

_SPEC_REF = re.compile(r"如说明书|如图|参见说明书|参见图|参照说明书|参照附图")


def check_claims_spec_reference(cn_doc: CnPatentDocument) -> list[CheckItem]:
    """Check if claims reference the specification or drawings for scope."""
    bad_claim_ids: list[int] = []
    ref_hits: list[tuple[int, str]] = []
    seen: set[tuple[int, str]] = set()
    for claim in cn_doc.claims:
        for m in _SPEC_REF.finditer(claim.text):
            token = m.group(0)
            key = (claim.id, token)
            if key in seen:
                continue
            seen.add(key)
            ref_hits.append((claim.id, token))
            if claim.id not in bad_claim_ids:
                bad_claim_ids.append(claim.id)

    if bad_claim_ids:
        bad_claim_ids = _dedupe_claim_ids(bad_claim_ids)
        claims_str = ", ".join(str(i) for i in bad_claim_ids)
        return [CheckItem(
            status="amend",
            message=f"{len(bad_claim_ids)} claim(s) reference the specification or drawings (claims: {claims_str}).",
            message_key="check.cn.claims.specReference.amend",
            details=f"{len(bad_claim_ids)} claims",
            details_key="details.cn.claimsSpecReference",
            details_params={
                "count": len(bad_claim_ids),
                "claims": bad_claim_ids,
                "flagged_phrases": {
                    "items": [{"kind": "reference", "token": token, "location": cid} for cid, token in ref_hits]
                },
            },
            reference="审查指南 第二部分第二章",
            diagnostics=_dx(
                flagged_count=len(bad_claim_ids),
                total_claims=len(cn_doc.claims),
                hit_count=len(ref_hits),
            ),
        )]

    return [CheckItem(
        status="pass",
        message="No claims reference the specification or drawings.",
        message_key="check.cn.claims.specReference.pass",
        reference="审查指南 第二部分第二章",
    )]


# ── Check 19 ─────────────────────────────────────────────────────────────


def check_multi_multi_dependency(cn_doc: CnPatentDocument) -> list[CheckItem]:
    """Find claims that multiply-depend on another multiple-dependent claim."""
    multi_dep_ids = {c.id for c in cn_doc.claims if c.multiple_dependent}
    bad = []
    for claim in cn_doc.claims:
        if claim.multiple_dependent:
            if any(d in multi_dep_ids for d in claim.dependencies):
                bad.append(claim.id)

    if bad:
        bad = _dedupe_claim_ids(bad)
        claims_str = ", ".join(str(i) for i in bad)
        return [CheckItem(
            status="amend",
            message=f"Multiple-dependent claim(s) depend on other multiple-dependent claims: {claims_str}.",
            message_key="check.cn.claims.multiMultiDep.amend",
            details=claims_str,
            details_key="details.cn.multiMultiDep",
            details_params={"claims": bad},
            reference="专利法实施细则 §25",
            diagnostics=_dx(
                flagged_count=len(bad),
                total_multi_dep=len(multi_dep_ids),
                total_claims=len(cn_doc.claims),
                flagged_claim_id=bad[0] if bad else None,
                findings=[
                    {"claim_id": cid, "preamble": (next((c.text for c in cn_doc.claims if c.id == cid), "") or "")[:80]}
                    for cid in bad[:5]
                ],
            ),
        )]

    return [CheckItem(
        status="pass",
        message="No chained multiple dependencies.",
        message_key="check.cn.claims.multiMultiDep.pass",
        details_key="details.cn.pass.multiMultiDep",
        reference="专利法实施细则 §25",
    )]


# ── Check 20 ─────────────────────────────────────────────────────────────


def check_dependent_ordering(cn_doc: CnPatentDocument) -> list[CheckItem]:
    """Check dependents of each independent claim appear consecutively."""
    claims = cn_doc.claims
    if not claims:
        return [CheckItem(
            status="pass",
            message="No claims to check.",
            message_key="check.cn.claims.dependentOrdering.pass",
            reference="审查指南 第二部分第二章",
        )]

    # Build map: for each independent claim, find the last position of
    # any dependent that references it (directly or transitively via chain).
    # Then check no dependent of an earlier independent appears after a later
    # independent.

    # Find independent claim positions
    indep_positions = []
    for i, c in enumerate(claims):
        if c.independent:
            indep_positions.append(i)

    if len(indep_positions) < 2:
        return [CheckItem(
            status="pass",
            message="Dependent claim ordering is correct.",
            message_key="check.cn.claims.dependentOrdering.pass",
            reference="审查指南 第二部分第二章",
        )]

    # For each independent claim, find the "group boundary" — the position
    # of the next independent claim. Any dependent that references the
    # earlier independent but appears after the next independent is out of order.
    claims_by_id = {c.id: c for c in claims}

    def root_independent(claim_id: int, visited: set | None = None) -> int | None:
        """Trace dependency chain to find the root independent claim."""
        if visited is None:
            visited = set()
        if claim_id in visited:
            return None
        visited.add(claim_id)
        c = claims_by_id.get(claim_id)
        if not c:
            return None
        if c.independent:
            return c.id
        if c.dependencies:
            return root_independent(c.dependencies[0], visited)
        return None

    # Check: after each independent claim, all claims until the next
    # independent should depend (transitively) on the current or a
    # preceding independent claim, not on a later one.
    for idx in range(len(indep_positions) - 1):
        current_indep_pos = indep_positions[idx]
        next_indep_pos = indep_positions[idx + 1]

        # Check claims after next_indep_pos to see if any reference
        # the current independent
        current_indep_id = claims[current_indep_pos].id
        for j in range(next_indep_pos + 1, len(claims)):
            c = claims[j]
            if not c.independent:
                root = root_independent(c.id)
                if root == current_indep_id:
                    return [CheckItem(
                        status="amend",
                        message="Dependent claims are not grouped with their independent claim.",
                        message_key="check.cn.claims.dependentOrdering.amend",
                        details_key="details.cn.dependentOrdering",
                        reference="审查指南 第二部分第二章",
                        diagnostics=_dx(
                            total_claims=len(claims),
                            total_independent=len(indep_positions),
                            stranded_claim_id=c.id,
                            expected_after_independent_id=current_indep_id,
                            actual_position=j,
                            stranded_preamble=(c.text or "")[:80],
                        ),
                    )]

    return [CheckItem(
        status="pass",
        message="Dependent claim ordering is correct.",
        message_key="check.cn.claims.dependentOrdering.pass",
        reference="审查指南 第二部分第二章",
    )]


# ── Check 21 (连接关系) ──────────────────────────────────────────────────


def check_connection_relationships_cn(cn_doc: CnPatentDocument) -> list[CheckItem]:
    """Flag independent apparatus claims listing components without a
    connection verb (CNIPA 审查指南 §3.2.1 + 专利法 §26.4).

    Thin wrapper over the shared CN/TW helper. Method, CRM, MPF, and
    composition claims are carved out per ``_CN_CONNECTION_CONFIG``.
    """
    return check_connection_relationships(cn_doc.claims, _CN_CONNECTION_CONFIG)


# ── Check 22 (omnibus / 如说明书所述) ─────────────────────────────────────

# Mirrors US ``_OMNIBUS_LANG``; CN-practitioner phrasings that reference
# the description or drawings instead of reciting features. 审查指南
# 第二部分第二章 §3.3 — claims must recite technical features, not
# reference the specification.
_OMNIBUS_LANG_CN = re.compile(
    r"如说明书(?:及附图)?(?:所述|所描述|所记载)"
    r"|如说明书和附图(?:所述|所描述|所示|所描述的)"
    r"|如(?:附图|图)\s*\d*(?:所示|所述|所描述)"
    r"|基本上如说明书(?:所述|所描述)"
    r"|如(?:前述|前文)(?:所述|所描述)说明书"
)


def detect_omnibus_claims_cn(cn_doc: CnPatentDocument) -> list[int]:
    """Return IDs of CN claims that reference 说明书/附图 without reciting features.

    Mirrors :func:`patentlint.analysis.claims.check_special_claim_formats`
    omnibus branch, with CN practitioner patterns. Length threshold (<40
    CJK chars) guards against false positives on long detailed claims that
    incidentally mention 说明书.
    """
    out: list[int] = []
    for claim in cn_doc.claims:
        text = claim.text or ""
        cjk_count = sum(1 for ch in text if "一" <= ch <= "鿿")
        if cjk_count < 40 and _OMNIBUS_LANG_CN.search(text):
            out.append(claim.id)
    return out


def check_omnibus_claims(cn_doc: CnPatentDocument) -> list[CheckItem]:
    """Emit CheckItem for CN omnibus claims (FIX) — 审查指南 §3.3."""
    ids = detect_omnibus_claims_cn(cn_doc)
    if ids:
        claims_str = ", ".join(str(i) for i in ids)
        return [CheckItem(
            status="amend",
            message=f"Omnibus claim(s) reference the specification or drawings instead of reciting features: {claims_str}.",
            message_key="check.cn.claims.omnibus.amend",
            details=claims_str,
            details_key="details.cn.omnibusClaims",
            details_params={"claims": ids},
            reference="审查指南 第二部分第二章 §3.3",
            diagnostics=_dx(
                flagged_count=len(ids),
                total_claims=len(cn_doc.claims),
                flagged_claim_id=ids[0] if ids else None,
                findings=[
                    {"claim_id": cid, "preamble": (next((c.text for c in cn_doc.claims if c.id == cid), "") or "")[:80]}
                    for cid in ids[:5]
                ],
            ),
        )]
    return [CheckItem(
        status="pass",
        message="No omnibus claims found.",
        message_key="check.cn.claims.omnibus.pass",
        reference="审查指南 第二部分第二章 §3.3",
    )]


# ── Check 23 (Markush group open transition) ─────────────────────────────

# CNIPA 审查指南 第二部分第十章 §9.3 — a Markush claim must use the closed
# transition 组成的 (e.g. 选自由...所组成的群组 / 选自由X、Y、Z组成的群组).
# Open-ended variants (包括/具有/含有) are suspect.
_MARKUSH_OPEN_CN = re.compile(
    r"选自由[^，。；]{0,80}?(包括|具有|含有)"
)
_MARKUSH_CLOSED_CN = re.compile(r"选自由[^，。；]{0,80}?组成")


def detect_markush_open_transition_cn(cn_doc: CnPatentDocument) -> list[tuple[int, str]]:
    """Return (claim_id, open_transition) pairs for Markush claims using 包括/具有/含有."""
    out: list[tuple[int, str]] = []
    for claim in cn_doc.claims:
        text = claim.text or ""
        m = _MARKUSH_OPEN_CN.search(text)
        if m and not _MARKUSH_CLOSED_CN.search(text):
            out.append((claim.id, m.group(1)))
    return out


def check_markush_open_transition(cn_doc: CnPatentDocument) -> list[CheckItem]:
    """Emit CheckItem for CN Markush claims using open transition (FIX).

    Improper Markush is a substantive rejection per 审查指南 第二部分第十章
    §9.3 (Markush requires 选自由...组成的 closed group), not a formal
    correction — open transition triggers an examiner rejection on the
    merits.
    """
    pairs = detect_markush_open_transition_cn(cn_doc)
    if pairs:
        ids = [cid for cid, _ in pairs]
        transitions = sorted({t for _, t in pairs})
        claims_str = ", ".join(str(i) for i in ids)
        return [CheckItem(
            status="amend",
            message=f"Markush claim(s) use open-ended transition instead of 组成的: {claims_str}.",
            message_key="check.cn.claims.markushOpenTransition.amend",
            details=claims_str,
            details_key="details.cn.markushOpenTransition",
            details_params={"claims": ids, "transitions": transitions},
            reference="审查指南 第二部分第十章 §9.3",
            diagnostics=_dx(
                flagged_count=len(ids),
                total_claims=len(cn_doc.claims),
                flagged_claim_id=ids[0] if ids else None,
                transitions=transitions,
                findings=[
                    {
                        "claim_id": cid,
                        "open_transition": tw_word,
                        "preamble": (next((c.text for c in cn_doc.claims if c.id == cid), "") or "")[:120],
                    }
                    for cid, tw_word in pairs[:5]
                ],
            ),
        )]
    return [CheckItem(
        status="pass",
        message="Markush groups use closed transition 组成的.",
        message_key="check.cn.claims.markushOpenTransition.pass",
        reference="审查指南 第二部分第十章 §9.3",
    )]


# ── Check 24 (CRM non-transitory) ────────────────────────────────────────
#
# 专利法 §25 excludes mental activities / abstract methods; 审查指南
# 第二部分第九章 governs computer-implemented inventions. A claim to a
# 计算机可读介质 / 计算机可读存储介质 without the 非暂态 / 非暂时性
# qualifier may be read to cover transitory signals (carrier waves),
# which fall outside patentable subject matter. CN drafters commonly
# write 计算机可读介质 (介质 is CNIPA standard; 媒体 is rarer but
# accepted) — both forms covered. Independent claims only — dep
# claims inherit medium type from the parent.

_CRM_MEDIUM_CN = re.compile(
    r"(?:计算机|机器)\s*可读(?:存储)?(?:介质|媒体)"
    r"|存储介质"
    r"|记录介质"
)
_NON_TRANSITORY_CN = re.compile(r"非暂态|非暂时性|非临时性")


def check_crm_non_transitory_cn(cn_doc: CnPatentDocument) -> list[CheckItem]:
    """Flag CN computer-readable medium claims missing 非暂态/非暂时性.

    专利法 §25 (excluded subject matter) + 审查指南 第二部分第九章
    (computer-implemented inventions). A claim to a 计算机可读介质
    without 非暂态 may cover transitory signals which fall outside
    patentable subject matter.
    """
    bad = [
        c.id for c in cn_doc.claims
        if c.independent
        and _CRM_MEDIUM_CN.search(c.text or "")
        and not _NON_TRANSITORY_CN.search(c.text or "")
    ]
    if bad:
        claims_str = ", ".join(str(i) for i in bad)
        return [CheckItem(
            status="amend",
            message=f"Computer-readable medium claim(s) missing 非暂态/非暂时性: {claims_str}.",
            message_key="check.cn.claims.crmNonTransitory.amend",
            details=claims_str,
            details_key="details.cn.crmNonTransitory",
            details_params={"claims": bad},
            reference="专利法 §25; 审查指南 第二部分第九章",
            diagnostics=_dx(
                flagged_count=len(bad),
                total_claims=len(cn_doc.claims),
                flagged_claim_id=bad[0] if bad else None,
                findings=[
                    {"claim_id": cid, "preamble": (next((c.text for c in cn_doc.claims if c.id == cid), "") or "")[:80]}
                    for cid in bad[:5]
                ],
            ),
        )]
    return [CheckItem(
        status="pass",
        message="No CRM claims missing 非暂态.",
        message_key="check.cn.claims.crmNonTransitory.pass",
        reference="专利法 §25",
    )]


# ─────────────────────────────────────────────────────────────────────────
# Phase 8c Stage 2 — CN antecedent-basis BFS walker
# ─────────────────────────────────────────────────────────────────────────
#
# Mechanical port of the TW walker (tw_claims.py lines 771–2390) with
# TC→SC character swap per v2 swap table. Historical tuning rationale
# lives in tw_claims.py; see ADR-095/096/097/098/099/100/101 for the
# invariants preserved here. Phase 8c audit-locked divergences:
#
#   Q1: 该等 strict-rejected (tw_contamination finding category). The
#       SC reference-prefix tuples omit 该等/该些 entirely — see Step 1
#       exception 4 of the Stage 2 port prompt.
#   Q2: 朝向 retained in _INTERIOR_VERB_BOUNDARIES_CN (carried over by
#       construction — already in TW set at tw_claims.py line 1319).
#   Q3: tuple dedup (normalized_term, normalized_reference_form) from
#       day 1 (ADR-107). TW uses single-key; parity migration is a
#       Phase 9 follow-up.
#   Q4: 独 added to _WORD_INTERNAL_YI_PREDECESSORS_CN defensively.
#
# Constants and functions carry `_CN` / `_cn` suffixes. The walker
# returns list[dict] like TW; _run_cn_pipeline wraps a summary CheckItem.

# ── Walker normalization constants ───────────────────────────────────────

# Noun exclusion class (mechanical TC→SC swap per v2 § 4).
# R67 (2026-05-05) sweep: added 由 — relational verb ("composed of"); not
# a noun-internal char in patent claim diction. Empirical attestation:
# CN112271269B c10 over-captured `交联网状结构由可交联配体` because regex
# spanned 由. Compound nouns containing 由 (缘由/自由/由来/理由) are
# non-patent-relevant; safe to add as boundary.
_NOUN_CHARS_CN = r"[^\s，。；：、及与和之的该将能须应皆被于以并且其而还另时在由]{2,12}"
# R62 (2026-05-05): post-match paren-numeral closure helper. Mirrors
# the TW walker fix: when the captured noun ends with `(<alphanumeric>`
# (open paren + 1-5 digits/letters, no closing paren), the {2,12}
# length cap truncated inside an open paren-numeral. Walker emit-loop
# extends the noun by 1 char if claim.text[match_end] is `)` or `）`.
_PAREN_NUM_TRAIL_RE_CN = re.compile(r"[(（][0-9A-Za-z]{1,5}$")

# R68d (2026-05-06) TW parity: mid-能 noun capture extension. CN walker
# excludes 能 from _NOUN_CHARS_CN to prevent aux-verb 能 over-capture,
# but cuts compound nouns (功能/性能/智能/换能器/官能基) mid-word. See
# tw_claims.py R68d comment for full rationale + precursor whitelist.
# CN-side mining (supplement_v2): 52 CN walker_fp where context_after
# starts at 能 — confirms the over-cut class.
_NENG_PRECURSORS_CN = (
    "功", "性", "效", "智", "动", "机", "官",
    "才", "本", "势", "万", "全", "异", "燃", "换",
)
_NOUN_EXT_RE_CN = re.compile(
    r"[^\s，。；：、及与和之的该将能须应皆被于以并且其而还另时在由]+"
)


def _extend_neng_compound_cn(
    raw_noun: str, raw_noun_end: int, claim_text: str
) -> tuple[str, int]:
    """Mirror of _extend_neng_compound_tw with Simplified precursors.

    能量 / 能源 follow-gate (parity mirror of TW issue #75): 能 followed
    by 量 or 源 is unambiguously the noun "energy" / "energy source" —
    extend by exactly that 3-char compound (no greedy continuation).
    """
    if not raw_noun:
        return raw_noun, raw_noun_end
    if raw_noun_end >= len(claim_text) or claim_text[raw_noun_end] != "能":
        return raw_noun, raw_noun_end
    follow = claim_text[raw_noun_end + 1: raw_noun_end + 2]
    if follow in ("量", "源"):
        return raw_noun + "能" + follow, raw_noun_end + 2
    if raw_noun[-1] not in _NENG_PRECURSORS_CN:
        return raw_noun, raw_noun_end
    raw_noun = raw_noun + "能"
    raw_noun_end += 1
    if raw_noun_end < len(claim_text):
        ext_m = _NOUN_EXT_RE_CN.match(claim_text, raw_noun_end)
        if ext_m:
            extra = ext_m.group()
            room = 12 - len(raw_noun)
            if room > 0:
                added = extra[:room]
                raw_noun = raw_noun + added
                raw_noun_end += len(added)
    return raw_noun, raw_noun_end

# R66 (revised 2026-05-05) TW parity: state-modifier capture extension.
# Mirror of TW R66 capture-time fix — gated on Simplified state suffixes
# 状/形. When raw_noun ends in such a suffix and `的<head>` follows,
# extend the captured reference so the displayed reference_form is the
# full `所述<state>的<head>` phrase rather than the bare adjective
# `所述<state>`. See tw_claims.py R66 comment for full rationale.
_STATE_MODIFIER_SUFFIXES_CN = ("状", "形")
_DE_HEAD_NOUN_RE_CN = re.compile(
    r"的(?P<head>[^\s，。；：、及与和之的该将能须应皆被于以并且其而还另时在由]{2,12})"
)

# R64 (2026-05-05) TW parity: display-side ordinal restoration. Walker
# normalizes 第1 → 第一 (Arabic→CJK) for matching; UI display preserves
# drafter's original ordinal style.
_ARABIC_TO_CJK_ORDINAL_CN = (
    ("一", "1"), ("二", "2"), ("三", "3"), ("四", "4"), ("五", "5"),
    ("六", "6"), ("七", "7"), ("八", "8"), ("九", "9"), ("十", "10"),
)


def _restore_original_ordinals_cn(normalized: str, raw: str) -> str:
    """Mirror of TW _restore_original_ordinals; preserves Arabic ordinals
    in displayed reference_form when drafter wrote them that way."""
    out = normalized
    for cjk, ar in _ARABIC_TO_CJK_ORDINAL_CN:
        if f"第{cjk}" in normalized and f"第{ar}" in raw:
            out = out.replace(f"第{cjk}", f"第{ar}")
    return out

# Introduction multi-char quantifiers (TC→SC glyph swap).
_INTRO_MULTI_QUANTIFIERS_CN = (
    "一或多个",
    r"至少[一二三四五六七八九十百千\d]+个?",
    "两个",
    r"两(?![端侧])",
    r"[二三四五六七八九十]+个",
    "一个", "一种", "一对",
    "复数个", "多个", "数个",
    "复数",
)

# Weight/molar composition intro (TC→SC).
_WEIGHT_UNITS_CN = r"(?:重量份|重量百分比|摩尔|wt%|mol%)"
_WEIGHT_COMPOSITION_PREFIX_CN = (
    r"\d+(?:\.\d+)?" + _WEIGHT_UNITS_CN
    + r"(?:至\d+(?:\.\d+)?" + _WEIGHT_UNITS_CN + r")?的"
)

# Definitional intro (mechanical TC→SC swap per v2 § 4).
# R30 mechanism #10 (2026-05-03): extended definitional prefixes.
# Common CN patent drafting introduces a term via 定义为/称为/记为/表示为
# already; corpus shows additional shapes: 此处称为, 此处定义为, 简称为
# (abbreviation marker), 命名为 (named as), 标记为 (marked as), 视为
# (deemed/treated as), 等同于 (equivalent to). Anti-pattern guard: the
# `一?` allows optional 一 prefix (drafter writes either form).
_DEFINITIONAL_PREFIX_CN = r"(?:定义为|称为|记为|表示为|此处称为|此处定义为|简称为|命名为|标记为|视为|等同于|又称为|又称|亦即)一?"

_INTRO_PATTERN_CN = re.compile(
    r"(?:"
    + _WEIGHT_COMPOSITION_PREFIX_CN
    + r"|" + _DEFINITIONAL_PREFIX_CN
    + r"|(?:" + "|".join(_INTRO_MULTI_QUANTIFIERS_CN) + r"|(?<!第)一(?![同体])))"
    + f"({_NOUN_CHARS_CN})"
)

# Reference prefixes — Q1 strips 该等/该些 from CN tuples entirely.
# The TC-contamination prefixes live only in check_antecedent_basis_cn
# (see the Q1 tw_contamination rejection branch); no module-level
# constant names them.
_REFERENCE_PREFIXES_CN = ("所述", "前述", "该")
# Negative lookahead on bare 该: suppress matches on 该等/该些 so the
# Q1 tw_contamination rejection (in check_antecedent_basis_cn) is the
# sole handler of those forms. 所述/前述 have no collision.
_REF_PATTERN_CAPTURE_CN = re.compile(
    r"(?P<prefix>所述|前述|该(?![等些]))"
    + f"(?P<noun>{_NOUN_CHARS_CN})"
)

# Trailing-verb denylist (mechanical TC→SC swap; historical rationale in
# tw_claims.py lines 869–990).
_TRAILING_VERB_DENYLIST_CN: tuple[str, ...] = tuple(sorted(
    (
        "包含", "包括", "含有", "具有", "系", "为", "是", "设有", "具备",
        "通过", "经由", "借由", "基于", "透过", "根据", "依据",
        "还包含", "还包括",
        "并且", "以及",
        "并", "且", "其", "其中", "还", "另",
        "包", "通", "经", "借",
        "所", "前",
        "到", "出",
        # 从: coverb "from" — cross-jurisdiction mirror of the TW #75
        # fix (PR #83). `<noun>从` over-capture; 从 is a coverb in suffix
        # position, never a noun terminus (从动 carries 从 at PREFIX).
        # Corpus-clean: CN phase-8c harness delta 0 vs pristine baseline.
        "从",
        "介",
        "位",
        "或",
        # R62 (2026-05-05) ATTEMPTED but REVERTED — trailing 和/与/及 strip
        # caused 2 protect:true label silencing + 6 unresolved_removed in
        # the CN harness. The risk audit underestimated noun compounds
        # ending in 和 (e.g., 总和 sum, 平和 balance, 缓和 mitigation) —
        # these ARE element-name candidates in chemistry/measurement
        # claims. Held off pending finer-grained guard (e.g., minimum
        # residual length + protected-suffix list) before re-attempting.
        "中",
        "后",
        "用",
        "上",
        "内",
        "分别", "皆",
        "处",
        "至",
        "依序",
        "撷取",
        # Stage 4 R1 D4a — ADR-100 pattern, CN-specific extensions
        "相关", "有关",
        # Phase 8c close-out R-CO-2 WQ1a — multi-char trailing verbs
        # Walker false positives where capture trails into a verb phrase.
        # Length-desc strip order: 联合训练 / 恢复运行 fire before bare 训练 / 运行.
        "联合训练", "恢复运行",
        "存储有",
        "进行", "接收", "发送", "输入", "来自", "需要",
        "运行", "执行", "确定", "提供", "匹配", "表征",
        "生成", "获取", "获得",
        "向",
        # Phase 8c R9 — additional trailing verbs from re-sampling analysis
        "针对", "支持", "调用", "采用", "作为",
        "对",
        # Phase 8c R22 — single-char preposition residues from BYD-style
        # paren-numeral terms (从动凸轮(320)由, 凹部(322)沿, 辅助层沿).
        "由", "沿",
        # Phase 8c R23 — multi-char trailing verbs from over_capture pool
        # (77-active stratification). Compound-noun risk audited per token
        # against full corpus V+CJK matches; all dominated by particle/
        # determiner suffixes (所/时/的/方) that don't form noun compounds.
        "录入", "推荐", "导入", "提取", "转动", "重复",
        "体外培养", "胰蛋白酶消化", "铰接", "选自", "代替", "交联",
        "检查", "查询", "保存", "固定", "回复", "消化",
        "恢复",
        # Phase 8c R24 — single-char trailing residues from over_capture
        # pool (16 active labels post-R23). Compound-noun risk audited:
        # all noun compounds (作用/不良/相应/均匀/得到) appear at PREFIX
        # position in corpus; suffix-position usage is uniformly verb/
        # particle. All 16 emit-terms ending in these chars match the
        # 16 targets exactly (zero collateral).
        "作", "不", "相", "均", "得",
        # === Phase 8c R7-port (2026-04-30) — TW Round 7 cross-port ===
        # 较 (comparative verb), 厚膜化 (process verb-suffix). CN parity
        # for TW additions; CNIPA semiconductor drafters use these
        # identically. 0 active CN-label collisions; 比较/较量 etc.
        # protected via the existing residual ≥ 1 floor (2-char compounds
        # with 较 at position [-1] strip to 1 char, blocked).
        "较", "厚膜化",
        # === R29 (2026-05-03) — round-1 corpus over-capture extensions ===
        # Conservative extension only. Excludes verbs that double as common
        # noun endings (处理, 配置, 形成, 驱动, 存储, 传输, 连接, 选择,
        # 标识, 识别) — those silenced legacy `处理器配置` protect:true
        # label on tw_contamination_simple synthetic. Kept additions are
        # clearly-verb multi-char phrases without noun-suffix ambiguity.
        "围绕", "代表", "连同", "表示", "移动",
        "检测", "测量", "收集", "输送",
        "释放", "操控", "扫描",
        "覆盖", "分离", "比较", "判断", "决定", "分析",
        "包括以下", "执行以下", "进行以下",
        "执行以下操作", "执行以下操",
        # === R63 (2026-05-05) — TW parity port (神秘黑屏哥.docx audit) ===
        # `不同`/`仅` parity from TW. Pure adjective/adverb in both scripts.
        # CJK `不同` is identical between Simplified and Traditional;
        # `仅` is the SC form of TW `僅` (same meaning, "only/merely").
        # Risk audit:
        # - 不同 trailing: pure adjective, never noun-position-suffix.
        # - 仅 trailing: adverb, never part of noun. 僅供/僅限 are
        #   adverb+verb, not nouns.
        # Min residual via R32 emit-time len < 2 filter.
        "不同", "仅",
        # === R32 (2026-05-04) — passive trailing residue ===
        # 被: passive marker (`<noun>被<verb>`). Compound nouns ending in
        #   `被` are vanishingly rare in CN patent claims (棉被/被服 are
        #   household items, not patent terms). Empirically: walker emits
        #   `单元被`/`子单元被` from CN114357105B c12/c15 spec-support FPs
        #   where bare `单元`/`子单元` is the canonical intro.
        #
        # NOT included: 通信/通讯. Initially considered, but corpus audit
        # showed compound NOUNS like `侧链路中继通信` / `无线通信` use
        # 通信 as HEAD noun at suffix position; symmetric strip would
        # bridge legit-flagged refs to bare `侧链路中继` and silence 7
        # protect:false legit-drafting-error labels in CN115398975B c1-8
        # (LLM ensemble Phase 2c verified). Reserved for a context-aware
        # mechanism (verb-mode vs noun-mode) outside R32 scope.
        '被',
        # === R32 (2026-05-04) — verb-suffix trailing residues (CN parity) ===
        # Cluster-mined from round-1 CN corpus.
        '延伸',  # 51 walker_fp / 0 legit. (Risk audited per TW.)
        '指示',  # 42 walker_fp / 0 legit. Verb form ("indicate").
                # NOTE: 指示牌 / 指示灯 noun compounds at PREFIX position.
        # === R30 (2026-05-03) — sample-derived adverbial / adjectival trims
        # 进一步: adverbial ("further"), fragment of 进一步包括/进一步具有.
        #   Multi-char so safe against noun compounds (第一步/一步走 unaffected).
        # 相关联: adjectival ("related/associated"), fragment of <noun>相关联的.
        #   Existing 相关 + 有关 catch 2-char form; 3-char form needs explicit.
        "进一步", "相关联",
        # === R-batch-r3 (2026-06-01) — locative/positional verb trims
        # 相邻: adjectival ("adjacent"). Never a noun-suffix in CN patent
        #   diction — appears at PREFIX position in legitimate compounds
        #   (相邻边缘 / 相邻区域 / 相邻通道). Closes tw_contamination
        #   over-capture `限位导槽分别相邻` → `限位导槽` (issue #171).
        "相邻",
        # === R41 (2026-06-24) — examiner/gold-mined trailing-verb over-capture
        # batch. Mined from CN gold walker_fp over-capture cluster (2,129
        # no-intro over-captures; these verbs over-ran the head noun, e.g.
        # `换挡拨叉接合`/`开关断开`/`第一光束移动`). All are unambiguous VERBS in
        # trailing position; noun-sense compounds carry a suffix (插入件/对接器/
        # 联接器/穿刺针) so the bare 2-char verb only appears verb-mode at the
        # tail. The FN-guard (silenced_legit==0 over the CN gold) vets each;
        # gray noun-sense verbs (接触/存储/垂直/平行) were HELD OUT, and the
        # FN-guard further removed 布置/接合/插入/对接/联接/卡合/贴合 — each
        # carries a real NOUN sense (布置=layout, 接合=joint, 插入=insertion,
        # 对接/联接=coupling/docking) that the LLM gold flagged as a legit head
        # noun, so stripping them silenced real defects (direct + intro-side
        # cascade). The surviving set is verb-only at the noun tail.
        "穿过", "断开", "切换", "前进", "对准", "穿刺", "嵌入",
        # === R42 (2026-06-24) — second examiner/gold-mined trailing-verb
        # over-capture batch (CN gold walker_fp, 2-char trailing cluster, each
        # legit==0 in the ensemble gold). Same discipline as R41: noun-sense
        # compounds carry a distinguishing suffix so the bare verb only appears
        # verb-mode at the tail — 套设 (sleeve-FIT; the noun is 套筒/套件),
        # 靠近/接近 (approach; the noun 接近度 carries 度), 加入 (add/join),
        # 实施 (implement; the noun 实施例 carries 例), 指定 (designate).
        # Strong independent-NOUN-sense verbs were HELD OUT pre-guard on
        # noun-sense judgment (DR-1), even though the gold flags them clean:
        # 偏移 (offset — a bare noun in 位置偏移), 关联 (association —
        # 关联关系/关联性), 结合 (combination/junction — 结合部). And the
        # FN-guard AUTO-NARROWED 混合 (mix): although no gold-legit reference
        # term ENDS in 混合, stripping it turned the intro-side `与氧源混合`
        # ("mixed with an oxygen source") into a false bare-noun intro of 氧源,
        # which silenced 4 real `所述氧源` §112 defects in CN1384805A
        # (intro-cascade FN). The surviving set is verb-only at the noun tail
        # AND cascade-clean over the CN gold.
        "套设", "靠近", "接近", "加入", "实施", "指定",
    ),
    key=len,
    reverse=True,
))

# Noun-like single-char trailing suffixes with residual ≥ 3 guard.
# R22 adds 由/沿; R24 adds 作/不/相/均/得 with relaxed-residual subset
# participation below.
_NOUNLIKE_SINGLE_CHAR_SUFFIXES_CN: frozenset[str] = frozenset(
    {"所", "位", "中", "后", "用", "上", "内", "撷取", "对", "由", "沿",
     "作", "不", "相", "均", "得",
     # === R7-port (2026-04-30) — TW R7 parity ===
     # 使 (causative particle / verb fragment): residual ≥ 3 protects
     # 大使/天使/特使/使用 (all 2-char compounds, residual 1 < 3).
     "使",
     # === R68 (2026-05-06) — supplement_v2 mining (TW parity) ===
     # 来: verb tail particle in `所述<noun>来自X` constructions.
     # 27 CN walker_fp findings end in 来 across supplement_v2.
     # See tw_claims.py R68 comment for full rationale.
     "来",
     # 向: TW parity (CN 0 walker_fp this round but pre-emptive — CN
     # drafters share the same `<noun>向X` preposition pattern).
     # GUARDED below by _DIRECTION_STEM_BEFORE_XIANG_CN: 向 is a bound noun
     # suffix in 方向/轴向/径向/… (direction nouns), NOT a strippable
     # preposition. Without the guard, `所述圆周方向` truncates to `圆周方`
     # (CN117837052A c32, a real corpus walker_fp). WS-B1 (2026-06-24).
     "向",
     # 自: TW parity (CN had 1 walker_fp, low signal — pre-emptive).
     "自"}
)

# WS-B1 (2026-06-24) — direction-noun stems that bind 向 as a NOUN suffix
# (方向/轴向/径向/横向/纵向/周向/切向/法向/侧向/竖向/斜向/单向/双向/同向/反向/
# 正向/逆向/定向/指向/取向/转向/导向). When a captured term ends in `<stem>向`,
# the 向 is part of the head noun and must NOT be stripped. Over-inclusion is
# FN-safe: at worst it leaves a pre-existing over-capture (FP-direction), it can
# never over-silence a real defect. Grounded by the 圆周方向→圆周方 corpus FP.
_DIRECTION_STEM_BEFORE_XIANG_CN: frozenset[str] = frozenset(
    "方径轴横纵周切法侧竖斜单双同反正逆定指取转导"
)

# Relaxed-guard subset (residual ≥ 2 instead of ≥ 3).
# Stage 4 R1 D4a — relaxed residual ≥ 2 guard for 2-char-stem residue strip.
# R22 adds 由/沿; R24 adds 作/不/相/均/得 (mirrors trailing-verb registration).
# R68 (2026-05-06) adds 来 (TW parity).
_NOUNLIKE_RELAXED_SUFFIXES_CN: frozenset[str] = frozenset(
    {"上", "内", "后", "中", "用", "对", "由", "沿",
     "作", "不", "相", "均", "得", "来"}
)

# Phase 8c R22 — `中` very-relaxed (residual ≥ 1) for 2-char locative
# phrases like 组中. The post-strip 1-char residual is then filtered by
# the `len(normalized_term) == 1` emit guard. Empirically scoped: only
# 2 corpus terms (组中 ×2 in CN115952274B) hit this path.
_NOUNLIKE_VERY_RELAXED_SUFFIXES_CN: frozenset[str] = frozenset({"中"})

# Phase 8c R10 — char-exclusion residue map.
# Keys: residue chars left at end of terms because _NOUN_CHARS_CN excludes
# the following char (于→基, 能→功, 应→响).  Values: minimum residual
# length after stripping the residue char.
_CHAR_EXCLUSION_RESIDUE_CN: dict[str, int] = {
    '\u57fa': 3,  # 基 (from 基于) — guard ≥3 protects 培养基
    '\u54cd': 2,  # 响 (from 响应)
    '\u529f': 2,  # 功 (from 功能)
    '\u8f93': 2,  # 输 (from 输出 where 出 is in trailing denylist)
}

# Chemistry chars that legitimately precede 基 (functional-group suffix).
# When the char before 基 is in this set, 基 is a noun, not a verb residue.
_CHEMISTRY_BEFORE_JI_CN: frozenset[str] = frozenset(
    '性酸碱甲乙丙丁养氨羟羧磷烷烯烃硫氧氮氯氢苯胺酮醛酯醇酚'
)

# Leading quantifier denylist (TC→SC).
_LEADING_QUANTIFIER_DENYLIST_CN: tuple[str, ...] = tuple(sorted(
    (
        "一或多个",
        "至少一个", "至少一",
        "一个", "一种", "一对",
        "复数个", "多个", "数个",
        "复数",
        "一",
        # Cross-jurisdiction parity with TW R6 (ce91d2b): 各 distributive
        # quantifier ("each"). CNIPA drafters use 前述各X / 所述各X / 该各X
        # for "each X" references when a parent claim introduces an indexed
        # family. Reference-side normalization must strip 各 so the bare
        # head noun matches the upstream intro. Symmetric strip on the
        # intro side is harmless because 各X intros are unattested at
        # claim-body level (the indexed family is introduced as bare noun,
        # then references add the distributive 各 prefix). Audit confirmed
        # 0 active CN labels collide; 3 resolved entries have mid-string
        # 各 (compound noun usage like 各样本数据) which startswith() leaves
        # untouched.
        "各",
        # === R30 (2026-05-03) — extended plural-quantifier bridging ===
        # Phase 2c Refinement C: when a parent claim introduces `多个X` /
        # `若干X` and a dependent references `所述X` (singular), bridging via
        # symmetric strip is the right move per CN drafting practice. The
        # original set covered 复数/多个/数个; this round adds the rest of
        # the common CNIPA quantifier vocabulary. All multi-char so safe
        # against compound nouns (无 single-char additions).
        "若干个", "若干",
        "一些", "某些",
        "多种", "多类", "多组", "多对",
        "至少两个", "至少两", "两个", "两种",
    ),
    key=len,
    reverse=True,
))

# Reference-form prefixes stripped from reference terms only (Q1: 该等/
# 该些 excluded per Step 1 exception 4 of the port prompt).
_REFERENCE_FORM_PREFIXES_CN: tuple[str, ...] = tuple(sorted(
    ("所述", "前述", "该"),
    key=len,
    reverse=True,
))

# Plural reference-form prefixes — Q1 excludes 该等/该些 from CN;
# the strict_plural_reference_matching escape hatch fires on the
# remaining 前述/所述 plural markers.
_PLURAL_REFERENCE_PREFIXES_CN: tuple[str, ...] = tuple(sorted(
    ("前述复数", "所述复数", "所述多个"),
    key=len,
    reverse=True,
))

# Interior-boundary tokens (mechanical TC→SC swap). See tw_claims.py
# lines 1138–1331 for the historical risk-review rationale per verb.
_INTERIOR_VERB_BOUNDARIES_CN: tuple[str, ...] = tuple(sorted(
    (
        "设有", "包含", "包括", "具有", "含有", "具备",
        "系为", "系于", "为", "是", "系",
        "所述", "前述", "该等", "该些",
        "传送接收到", "传送一显示影像资", "输出一解锁指令至",
        "通讯连接时", "电性连接", "被带动而向", "分别定义",
        "无法存取", "设置有", "拔除时",
        "连接一第一电子装", "撷取一使用者",
        "电性连", "所施予", "将带动", "被带动",
        "对应", "相对", "相反", "响应", "解锁",
        "读取", "写入", "计算", "处理", "感测",
        "侦测", "监控", "监测", "调整", "修改",
        "更新", "删除", "增加", "减少", "选择",
        "决定", "判别", "辨识", "驱动",
        "定义", "启始", "判断", "持续", "涵盖", "放大", "存取",
        "构成", "设置",
        "透过", "通过", "经由", "借由",
        "基于", "根据", "依据",
        "染色",
        "识别", "传送", "接收",
        "到", "形成", "锁合", "传输",
        "连接", "旋转", "带动", "筛选",
        "区分",
        "显示", "上传", "浏览",
        "产生", "各地",
        "依序",
        "相互", "朝向",
        # Stage 4 R2' D1a — 调出 cuts after 处理器指令 prefix (Huawei c3)
        "调出",
        # Phase 8c R8 — 进行 (carry out) appears mid-term in overcaptures
        # like 第一设备进行第一信号 → should split to 第一设备.
        "进行",
        # Phase 8c R12 — additional interior verb overcaptures
        "需要", "发出", "符合",
        # Phase 8c R23 — interior verb cuts from over_capture pool
        # (像素界定层限定有X, 处理单元周期性地或非周期, 滑块(230)可移动地设,
        # 初始地理预训练模型按照预, 处理器核运行客户端进程, 目标预训练模型采用预训练,
        # 实线边表征不同节点). Compound-noun risk audited per token.
        "限定有", "周期性地", "可移动地", "按照", "运行", "采用", "表征",
        # === Phase 8c R7-port (2026-04-30) — TW Round 7 cross-port ===
        # Process verbs that split mid-string captures cleanly in
        # semiconductor / mechanical claims. CN parity for the TW
        # additions in R7; same drafter conventions across jurisdictions.
        # Compound-noun risk: 夹持器/覆盖层/露出口 absent from CN corpus
        # per grep (verbs only, no compound-noun collision).
        "夹持", "覆盖", "露出",
    ),
    key=len,
    reverse=True,
))

# Stage 4 R2' D3 — 1-char noun prefixes get a relaxed position gate
# (>= 1 instead of > 1) so interior-verb cuts can fire at idx 1. Without
# this, captures like 边包括实线边 / L具有选自 can never be truncated.
_ONE_CHAR_NOUN_PREFIXES_CN: frozenset[str] = frozenset(
    {"边", "面", "体", "键", "L", "X", "Y", "Z", "M", "N", "R"}
)

# Interior-cut exception set — mechanical TC→SC swap per v2 swap table;
# compound-level re-seeding deferred to Stage 4.
_INTERIOR_CUT_EXCEPTIONS_CN: frozenset[str] = frozenset({
    "连接器", "连接部", "连接端口", "连接点", "连接线",
    "第一连接部", "第二连接部", "第三连接部",
    "电连接器", "电性连接部",
    "编码器", "解码器", "旋转编码器", "光学编码器",
    "识别码", "识别资料", "识别信息", "识别号", "识别子",
    "通讯模块", "通讯端口", "通讯单元", "通讯接口",
    "行动通讯模块", "无线通讯模块", "有线通讯模块",
    "第一通讯模块", "第二通讯模块",
    "第一无线通讯模块", "第二无线通讯模块", "第三无线通讯模块",
    "传送器", "接收器", "发射器", "发送器", "收发器",
    "认证单元", "认证模块", "认证装置", "认证功能单元",
    "衔接部", "第一衔接部", "第二衔接部", "第三衔接部",
    "扣接部", "第一扣接部", "第二扣接部",
    "后轮", "前轮", "传动轮", "从动轮", "主动轮",
    "曲柄", "踏板", "弧面", "第一弧面", "第二弧面",
    "轮轴", "传动件",
    "上端边缘", "下端边缘", "外侧边缘", "内侧边缘",
    "容纳部", "容置部", "容置杯体", "杯体",
    "环形压接部", "压接部", "压接环",
    "开口部", "封闭部",
    "顶壁", "底壁", "侧壁", "顶部", "底部", "侧部",
    "数位内容", "适地性数位内容", "主题标签",
    "浏览程式", "伺服器", "用户界面",
    "放大器",
    "染色墨水",
    "带动轮",
    "显示器", "显示装置", "显示单元",
    "浏览器",
    "波产生器",
    "连接面", "第一连接面", "第二连接面",
    # Stage 4 R2' D1a — Huawei CN113939805B 处理器指令 compound
    "第一处理器指令", "第二处理器指令",
})


# ── Walker normalization functions ───────────────────────────────────────


def clean_noun_phrase_cn(text: str) -> str:
    """Strip trailing verbs and conjunction fragments from a CN reference term.

    Two-phase cleanup mirroring ``clean_noun_phrase_tw``:
      1. Interior-verb truncation with prefix-aware exception protection.
      2. Trailing-verb stripping (iterative, with residual guards).

    See tw_claims.py::clean_noun_phrase_tw for the full rationale.
    """
    if not text:
        return text

    def _longest_protected_prefix(s: str) -> int:
        for i in range(len(s), 1, -1):
            if s[:i] in _INTERIOR_CUT_EXCEPTIONS_CN:
                return i
        return 0

    protected_prefix_len = _longest_protected_prefix(text)
    search_text = text[protected_prefix_len:]
    search_offset = protected_prefix_len

    # Stage 4 R2' D3 (ADR-112): 1-char noun prefixes (边/L/etc.) relax the
    # position gate from > 1 to >= 1 so interior-verb cuts at idx 1 can
    # fire. Without this, a capture like 边包括实线边 cannot be truncated
    # because 包括 sits at idx 1 and the original gate blocks it.
    is_one_char_noun_prefix = (
        len(text) > 0
        and text[0] in _ONE_CHAR_NOUN_PREFIXES_CN
        and protected_prefix_len == 0
    )
    min_absolute_idx = 1 if is_one_char_noun_prefix else 2

    # R31 (2026-05-03) tight noun-suffix guard for compound nouns where
    # the verb is part of a real noun compound (verb + noun-suffix). Mirror
    # of TW R31. Restricted by:
    #   1. verb in high-collision whitelist (decision/sense/identify class)
    #   2. char immediately after verb is a noun-suffix
    #   3. TOTAL TEXT LENGTH ≤ 8 chars (typical compound noun max)
    _R31_NOUN_COMPOUND_VERBS_CN = {
        '决定', '感测', '侦测', '监测', '辨识', '识别', '解析',
        '处理', '控制', '驱动', '检出', '判定', '计算', '生成',
        '输出', '输入', '存储', '存取', '读取', '写入',
    }
    earliest_idx: int | None = None
    for verb in _INTERIOR_VERB_BOUNDARIES_CN:
        idx = search_text.find(verb)
        if idx >= 0 and (idx + search_offset) >= min_absolute_idx:
            absolute_idx = idx + search_offset
            # R31 noun-compound guard (length-bounded): skip cut if verb is
            # in whitelist, char after is noun-suffix, total len ≤ 8.
            if (verb in _R31_NOUN_COMPOUND_VERBS_CN
                    and len(text) <= 8):
                next_char_pos = absolute_idx + len(verb)
                if (next_char_pos < len(text)
                        and text[next_char_pos] in _F10_SINGLE_CHAR_SUFFIXES_CN):
                    continue  # 对象决定+部 etc. (text length ≤ 8)
            if earliest_idx is None or absolute_idx < earliest_idx:
                earliest_idx = absolute_idx

    current = text[:earliest_idx] if earliest_idx is not None else text

    for _ in range(16):
        stripped = False
        for verb in _TRAILING_VERB_DENYLIST_CN:
            if not current.endswith(verb):
                continue
            if len(current) <= len(verb):
                continue
            # WS-B1: 向 binds as a noun suffix in direction nouns (方向/轴向/…).
            if verb == "向" and current[-2] in _DIRECTION_STEM_BEFORE_XIANG_CN:
                continue
            if verb in _NOUNLIKE_SINGLE_CHAR_SUFFIXES_CN:
                if verb in _NOUNLIKE_VERY_RELAXED_SUFFIXES_CN:
                    min_residual = 1
                elif verb in _NOUNLIKE_RELAXED_SUFFIXES_CN:
                    min_residual = 2
                else:
                    min_residual = 3
                if (len(current) - len(verb)) < min_residual:
                    continue
            current = current[: -len(verb)]
            stripped = True
            break
        if not stripped:
            break

    # Phase 8c R10 — char-exclusion residue repair.
    # _NOUN_CHARS_CN excludes 于/能/应 etc., leaving half-compound residues
    # at the end of captured terms (e.g., 第一设备基 from 基于, 第一功 from
    # 功能, 第N响 from 响应).  Strip the residue char when it is NOT part
    # of a legitimate chemistry suffix (培养基, 酸解离性基, 碱基 …).
    if len(current) >= 3 and current[-1] in _CHAR_EXCLUSION_RESIDUE_CN:
        guard = _CHAR_EXCLUSION_RESIDUE_CN[current[-1]]
        if len(current) - 1 >= guard:
            if current[-1] != '\u57fa' or current[-2] not in _CHEMISTRY_BEFORE_JI_CN:
                current = current[:-1]

    # R54 (2026-05-05): regex-based verb-phrase trailing strip.
    # Catches over-capture patterns the literal allowlist doesn't cover:
    #   `\u9501\u626d\u6574\u4f53\u5448\u5706\u67f1\u5f62` \u2192 `\u9501\u626d` (\u6574\u4f53\u5448X = "overall is X" descriptor)
    #   `\u7ea4\u7ef4\u6750\u6599\u8f74\u5411\u5730\u6392\u5217` \u2192 `\u7ea4\u7ef4\u6750\u6599` (XY\u5730ZW = adverbial-verb suffix)
    # Both confirmed walker over-capture per user 2026-05-05 phone-judge
    # (CN103443870A c19, CN106654630B c10).
    #
    # Adverbial regex constrains the pre-\u5730 portion to 2-3 chars (typical
    # CN adverbials: \u8f74\u5411, \u5e73\u7a33, \u5782\u76f4, \u81ea\u52a8). Wider {1,4} bracket consumed
    # head-noun chars greedily (`\u7ea4\u7ef4\u6750\u6599\u8f74\u5411\u5730\u6392\u5217` \u2192 `\u7ea4\u7ef4`); narrower
    # {2,3} leaves head noun intact (`\u7ea4\u7ef4\u6750\u6599`).
    #
    # Verb portion 1-3 chars (\u6392\u5217, \u8fd0\u52a8, \u5f62\u6210).
    # Head-noun group \u22652 chars (residual guard).
    _R54_OVERALL_DESC = re.compile(
        r'^([\u4e00-\u9fff]{2,})\u6574\u4f53\u5448[\u4e00-\u9fff]{1,8}$'
    )
    _R54_ADVERBIAL_VERB = re.compile(
        r'^([\u4e00-\u9fff]{2,})[\u4e00-\u9fff]{2,3}\u5730[\u4e00-\u9fff]{1,3}$'
    )
    for _ in range(4):
        before = current
        m = _R54_OVERALL_DESC.match(current)
        if m:
            current = m.group(1)
        m = _R54_ADVERBIAL_VERB.match(current)
        if m:
            current = m.group(1)
        if current == before:
            break

    return current


# R32 (2026-05-04): regex-based at-least-N strip + 其-possessive strip
# (CN parity with TW R32). Existing _LEADING_QUANTIFIER_DENYLIST_CN
# covers 至少一/至少一个/至少两/至少两个 only; 至少三个X / 至少100个X
# stranded. 其X (its X) possessive captured by F-anchor patterns when
# the canonical intro is bare X (introduced as feature of prior subject).
_AT_LEAST_N_PREFIX_RE_CN: re.Pattern[str] = re.compile(
    r'^至少[一二三四五六七八九十百0-9]+个'
)
_POSSESSIVE_其_PREFIX_RE_CN: re.Pattern[str] = re.compile(
    r'^其(?=[一-鿿]{2,})'
)


# R32 (2026-05-04): leading conjunction-residue strip. CN drafters use
# `和/或X` (and/or X) constructions in lists. Walker captures `/或X` as
# leading residue when the conjunction-split mechanism fails on the
# slash. Empirical: `/或第二功能模块` from CN115485995B c12 spec-support FP
# where canonical intro is `第二功能模块`.
_LEADING_CONJ_RESIDUE_RE_CN: re.Pattern[str] = re.compile(
    r'^(?:/或|/和|和/或|或/|/)'
)


def strip_leading_quantifier_cn(text: str) -> str:
    """Strip one matching leading quantifier (ADR-095 Rule 2).

    R32 (2026-05-04): regex-based 至少N个 strip applied first; 其-possessive
    strip applied last with ≥2 CJK lookahead so 其余 (2 chars) is protected.
    """
    if not text:
        return text
    # R32: leading conjunction residue (`/或`, `和/或`) strip
    m = _LEADING_CONJ_RESIDUE_RE_CN.match(text)
    if m and len(text) - m.end() >= 2:
        text = text[m.end():]
    m = _AT_LEAST_N_PREFIX_RE_CN.match(text)
    if m and len(text) - m.end() >= 2:
        text = text[m.end():]
    for q in _LEADING_QUANTIFIER_DENYLIST_CN:
        if text.startswith(q) and len(text) > len(q):
            text = text[len(q):]
            break
    m = _POSSESSIVE_其_PREFIX_RE_CN.match(text)
    if m:
        text = text[m.end():]
    return text


def strip_reference_form_prefix_cn(text: str) -> str:
    """Strip one matching reference-form prefix (该/所述/前述)."""
    if not text:
        return text
    for prefix in _REFERENCE_FORM_PREFIXES_CN:
        if text.startswith(prefix) and len(text) > len(prefix):
            return text[len(prefix):]
    return text


# Leading qualifier strip (relational + position qualifiers with
# quantifier lookahead). See tw_claims.py lines 1580–1666 for rationale.
_LEADING_RELATIONAL_QUALIFIERS_CN: tuple[str, ...] = (
    "对应地", "对应的", "对应",
    "相应地", "相应的", "相应",
    "相对地", "相对的", "相对",
    "相关地", "相关的", "相关",
)

_LEADING_POSITION_QUALIFIERS_CN: tuple[str, ...] = ("前", "后")
_QUANTIFIER_AFTER_POSITION_CN: tuple[str, ...] = (
    "一或多个",
    "一", "二", "三", "四", "五", "六", "七", "八", "九", "十",
    "1", "2", "3", "4", "5", "6", "7", "8", "9",
    "复数", "多个", "数个", "至少",
)


def strip_leading_qualifier_cn(
    text: str,
    *,
    strict_qualifier_matching: bool = False,
) -> str:
    """Strip leading qualifier modifiers from a normalized reference term.

    Relational qualifiers stripped unconditionally; position qualifiers
    (前/后) only when followed by a quantifier. Strict mode disables
    the strip entirely. See tw_claims.py::strip_leading_qualifier.
    """
    if strict_qualifier_matching or not text:
        return text

    for q in _LEADING_RELATIONAL_QUALIFIERS_CN:
        if text.startswith(q) and len(text) > len(q):
            return text[len(q):]

    for q in _LEADING_POSITION_QUALIFIERS_CN:
        if text.startswith(q) and len(text) > len(q):
            remainder = text[len(q):]
            for quant in _QUANTIFIER_AFTER_POSITION_CN:
                if remainder.startswith(quant):
                    return remainder

    return text


def normalize_reference_term_cn(
    text: str,
    *,
    strict_qualifier_matching: bool = False,
) -> str:
    """Normalize a flagged reference term for antecedent matching.

    R7 (2026-04-30): + strip_leading_verb_cn for `所述形成p型源极／漏极`
    style references that carry a leading verb prefix (符号见 ADR-095
    addendum / TW R7 commit).

    R33 (2026-05-04): + normalize_arabic_ordinal_to_cjk at the head so
    JP-translated drafts using `第1` / `第2` collapse with canonical
    `第一` / `第二` intros for matching purposes.
    """
    t = normalize_arabic_ordinal_to_cjk(text)
    t = strip_reference_form_prefix_cn(t)
    t = strip_leading_qualifier_cn(t, strict_qualifier_matching=strict_qualifier_matching)
    t = clean_noun_phrase_cn(t)
    t = strip_leading_quantifier_cn(t)
    t = strip_leading_verb_cn(t)
    # R31 (2026-05-03): re-run reference-prefix strip after verb strip,
    # because the new 有 prefix entry can expose a hidden 所述/该/前述
    # underneath (e.g., 有所述高亮度区域 → 所述高亮度区域 after 有 strip
    # → 高亮度区域 after re-prefix-strip). Without this, spec_support
    # mid-phrase recovery test failed.
    t = strip_reference_form_prefix_cn(t)
    t = strip_leading_qualifier_cn(t, strict_qualifier_matching=strict_qualifier_matching)
    return t


def normalize_candidate_intro_cn(
    text: str,
    *,
    strict_qualifier_matching: bool = False,
) -> str:
    """Normalize an introduction candidate for antecedent matching.

    Symmetric with normalize_reference_term_cn per ADR-098; the trailing
    strip_reference_form_prefix_cn is load-bearing for intros where
    the _INTRO_PATTERN_CN captures a reference-prefix artifact as part
    of the bare noun group.
    """
    t = normalize_arabic_ordinal_to_cjk(text)
    t = strip_leading_qualifier_cn(t, strict_qualifier_matching=strict_qualifier_matching)
    t = clean_noun_phrase_cn(t)
    t = strip_leading_quantifier_cn(t)
    t = strip_reference_form_prefix_cn(t)
    t = strip_leading_verb_cn(t)
    return t


def detect_plural_reference_cn(text: str) -> bool:
    """Return True iff text starts with a plural reference-form prefix."""
    return any(text.startswith(p) for p in _PLURAL_REFERENCE_PREFIXES_CN)


def get_ancestor_chain_cn(claim: Claim, all_claims: list[Claim]) -> list[Claim]:
    """Return [claim, ...ancestors] walking the full multi-parent BFS.

    Per ADR-092, the walker uses the FULL ancestor chain. Stage 1.5
    invariant: trusts ``parse_cn_claims_docx`` dependency shape verbatim
    — no self-ref stripping, no spec expansion. Both already handled
    upstream at claims_cn.py:40-59 and claims_cn.py:90.
    """
    claims_by_id = {c.id: c for c in all_claims}
    chain: list[Claim] = [claim]
    visited: set[int] = {claim.id}
    # Chain uses dependencies ONLY. Claim.quoted_references is populated
    # by the parser for body cross-refs (`如权利要求N所述的X`) but extending
    # the chain blanket-grants antecedent for ALL of claim N's intros —
    # broader than CNIPA 审查指南 § 3.3 cross-reference doctrine, which
    # says the body cross-ref provides antecedent only for the named
    # element X. Element-scoped chain traversal is a future ADR.
    # See analysis/claims.py:_chain — same design choice.
    queue: list[int] = list(claim.dependencies)
    while queue:
        parent_id = queue.pop(0)
        if parent_id in visited:
            continue
        visited.add(parent_id)
        parent = claims_by_id.get(parent_id)
        if parent is None:
            continue
        chain.append(parent)
        queue.extend(parent.dependencies)
    return chain


# Q4 (defensive): 独 added to the CN predecessor set. Confirm in Stage 4
# corpus tuning whether it surfaces 独一X patterns as word-internal.
_WORD_INTERNAL_YI_PREDECESSORS_CN = frozenset("第另任某唯同单统独")

_SPLIT_YI_NOUN_RE_CN = re.compile(r"一(" + _NOUN_CHARS_CN + r")")


def _postprocess_intro_capture_cn(
    bare_noun: str,
    match: re.Match,  # type: ignore[type-arg]
    claim_text: str,
) -> list[str]:
    """Post-process a greedy _INTRO_PATTERN_CN capture to repair over-captures.

    Same three-rule repair pipeline as the TW walker's
    ``_postprocess_intro_capture``: ref-marker check + truncation,
    embedded 一 splitting, re-scan for discarded spans.
    """
    # Rule 1a
    for prefix in _REFERENCE_FORM_PREFIXES_CN:
        if bare_noun.startswith(prefix):
            recovered = _rescan_for_yi_cn(
                match.group(0), match.start(), claim_text,
            )
            if recovered:
                return recovered
            remainder = bare_noun[len(prefix):]
            return [remainder] if remainder else []

    # Rule 1b
    for prefix in _REFERENCE_FORM_PREFIXES_CN:
        idx = bare_noun.find(prefix)
        if idx > 0:
            bare_noun = bare_noun[:idx]
            break

    # Rule 2: embedded 一 splitting
    candidates: list[str] = []
    yi_positions = [i for i, ch in enumerate(bare_noun) if ch == "一" and i > 0]

    if not yi_positions:
        return [bare_noun]

    split_pos: int | None = None
    for pos in yi_positions:
        preceding_char = bare_noun[pos - 1]
        if preceding_char not in _WORD_INTERNAL_YI_PREDECESSORS_CN:
            split_pos = pos
            break

    if split_pos is None:
        return [bare_noun]

    leading_part = bare_noun[:split_pos]
    if leading_part:
        candidates.append(leading_part)

    abs_start = match.start() + (len(match.group(0)) - len(match.group(1))) + split_pos
    remaining_text = claim_text[abs_start:]
    yi_match = _SPLIT_YI_NOUN_RE_CN.match(remaining_text)
    if yi_match:
        candidates.append(yi_match.group(1))
    elif split_pos + 1 < len(bare_noun):
        candidates.append(bare_noun[split_pos + 1:])

    return candidates


def _rescan_for_yi_cn(
    full_span: str,
    span_start: int,
    claim_text: str,
) -> list[str]:
    """Re-scan a full matched span for 一 intro sites."""
    candidates: list[str] = []
    for i, ch in enumerate(full_span):
        if ch != "一":
            continue
        if i == 0:
            continue
        if full_span[i - 1] in _WORD_INTERNAL_YI_PREDECESSORS_CN:
            continue
        abs_pos = span_start + i
        remaining = claim_text[abs_pos:]
        yi_match = _SPLIT_YI_NOUN_RE_CN.match(remaining)
        if yi_match:
            candidates.append(yi_match.group(1))
    return candidates


# ── Supplementary bare-noun intro patterns (F5/F6/F7b/F7c/F7d/F11/F12/F13) ─
#
# F7a/F8/F9 removed 2026-04-16: the R14 investigation confirmed zero matches
# across the 10-fixture corpus. Their shapes (形成于X的Y, 相配合的Y, 透过Y连接)
# are TW-specific drafting patterns; CN tends toward 位于/设于 (now covered
# by F13) and 包括/包含 (covered by F11). If future fixtures surface any of
# these shapes, re-add with empirical grounding.

# CJK char class excluding 的 (U+7684); jurisdiction-invariant.
_CJK_NO_DE_CN = r'[\u4e00-\u7683\u7685-\u9fff]'
# F6-specific: also excludes 之 (U+4E4B) to prevent captures extending into
# temporal markers like 之后/之前. Removes the need for (?![的之]) lookahead
# which caused backtracking truncation before 的.
_CJK_NO_DE_ZHI_CN = r'[\u4e00-\u4e4a\u4e4c-\u7683\u7685-\u9fff]'

_PARTICIPIAL_YI_DE_PATTERN_CN = re.compile(
    r'一[\u4e00-\u9fff]+?的(' + _CJK_NO_DE_CN + r'{2,}(?:\([A-Za-z0-9]+\))?)'
)

_POST_DE_ORDINAL_PATTERN_CN = re.compile(
    r'的(第[一二三四五六七八九十\d]+' + _CJK_NO_DE_CN + r'+(?:\([A-Za-z0-9]+\))?)'
)

# Phase 8c R14c.2 — F6 bare-noun relax.
# Adds a third capture arm: bare NP (≥3 CJK chars, no ordinal, no paren).
# Gated by:
#   - negative lookahead against _F12_ADJ_REJECTS_CN (rejects predicate-
#     adjective / verb-phrase heads like 经/可/具有/能够/用于/基于)
#   - negative lookahead against 第/所述/该/前述 (arm1 or ref-prefix)
#   - per-CJK-char negative lookahead against F6 verbs, so arm3's greedy
#     CJK{3,20} stops at the next F6-verb start rather than consuming
#     across `进行处理得到第N信号` and blocking arm1 at 得到第N信号.
# See docs/8c/r14c2-f6-bare-noun.md.
_F6_VERB_ALT_CN = (
    r'具有|包含|包括|含有|设有'
    r'|设置|配置|安装|装设'
    r'|形成|构成'
    r'|提供|连接|连结'
    r'|获取|获得|得到|生成|产生|发出'
    r'|发送|接收|输出|输入|传送|存储|确定|涉及'
    r'|进行|调用|运行|调整|建立|构建|制得|根据|存在|使用'
)

_BARE_AFTER_VERB_PATTERN_CN = re.compile(
    r'(?:' + _F6_VERB_ALT_CN + r')'
    r'('
    r'第[一二三四五六七八九十\d]+' + _CJK_NO_DE_ZHI_CN + r'+(?:\([A-Za-z0-9]+\))?'
    r'|' + _CJK_NO_DE_ZHI_CN + r'+\([A-Za-z0-9]+\)'
    r'|'
    r'(?!第|所述|该|前述)'
    + r'(?:(?!(?:' + _F6_VERB_ALT_CN + r'))' + _CJK_NO_DE_ZHI_CN + r'){3,20}'
    r')'
)

# F11: colon-anchored list-after-包括/包含/含有 (WQ8 / R3).
# R31 (2026-05-03): F11 anchor verb set extended to cover broader Pattern B
# trigger vocabulary observed in round-1 corpus. CNIPA drafters use 具有
# /具备/设有/设置/包括以下/还包括/进一步包括/还具有 as Pattern B intro
# anchors, not just 包括/包含/含有. Each addition gated separately against
# protect:true labels.
_F11_COLON_LIST_ANCHOR_CN: re.Pattern[str] = re.compile(
    r'(?:包括以下|还包括|还包含|进一步包括|进一步包含|包括|包含|含有|具有|具备|设有)[：:]\s*([^。]+)'
)
# R29 (2026-05-03): regex no longer excludes `；` so the capture spans the
# whole list (bounded by `。`). Caller in _extract_supplementary_intros_cn
# splits the captured text on `；` and processes each segment as its own
# F11 list-element source. Pattern B claims like `<system>包括: A; B; 以及 C`
# previously dropped B and C because the capture stopped at first `；`.
_F11_LIST_SPLIT_CN: re.Pattern[str] = re.compile(r'[、，,和与及]')

# Phase 8c R14e — F11 no-colon extension. Matches no-colon enum lists
# `(?:包括|包含|含有)(Y(?:、Y)+)` where ≥2 `、`-separated CJK elements
# follow the verb directly. Mutually exclusive with the colon anchor
# because the character after the verb must be CJK (not `：:`), and
# requires the enum-list shape so single-noun `包括Y` doesn't fire
# (that case belongs to F6 / elsewhere).
_F11_NO_COLON_LIST_ANCHOR_CN: re.Pattern[str] = re.compile(
    # R31 (2026-05-03): mirror of F11_COLON anchor verb extension.
    r'(?:包括以下|还包括|还包含|进一步包括|进一步包含|包括|包含|含有|具有|具备|设有)'
    r'([\u4e00-\u7683\u7685-\u9fff]{2,}(?:、[\u4e00-\u7683\u7685-\u9fff]{2,})+)'
)

# Phase 8c R14f — conjunction-split pass. Splits captured intros on
# 和/与/及/以及 with ≥2 CJK chars each side, registering each element as
# its own intro so downstream `所述X` / `所述Y` references can resolve
# when the drafting captured the intro as `X和Y`. Applied as a final
# pass over _extract_supplementary_intros_cn results after the uniform
# trailing-verb cleanup.
_CONJ_SPLIT_RE_CN: re.Pattern[str] = re.compile(r'(.+?)(?:以及|和|与|及)(.+)')

# F13: locative-verb + bare noun (+ optional locative suffix). Phase 8c R14a.
# Registers Y from `X应用于Y侧` / `X位于Y` as an intro, stripping a trailing
# locative suffix (侧/端/方/处/面/内/外/上/下/中) when present. The locative
# strip is required because walker resolution is reference.startswith(intro);
# a reference to `第一设备` cannot resolve to a longer intro `第一设备侧`.
_F13_LOCATIVE_VERB_PATTERN_CN: re.Pattern[str] = re.compile(
    r'(?:应用于|作用于|位于|置于|设于|布置于|设置于|固定于)'
    r'([\u4e00-\u7683\u7685-\u9fff]{2,12}(?:\([A-Za-z0-9]+\))?)'
)
_F13_LOCATIVE_SUFFIXES_CN: tuple[str, ...] = (
    '侧', '端', '方', '处', '面', '内', '外', '上', '下', '中',
)

# F14: V+有 noun-of-existence intro (Phase 9 #61).
# Registers Y from `X形成有Y` / `X安装有Y` / `X存储有Y` as an intro. Gated on
# a narrow verb set with empirically-clean captures — broader verbs (设置,
# 包含) add compound-noun FPs that the ADJ_REJECTS filter does not cover.
# Reuses _F12_ADJ_REJECTS_CN (rejects 可/由/能 etc.) + _REF_PREFIX_SET_CN +
# _BARE_ORDINAL_RE_CN + leading-conjunction reject (与/和/或).
_F14_V_YOU_PATTERN_CN: re.Pattern[str] = re.compile(
    r'(?:形成|安装|存储)有'
    r'([\u4e00-\u7683\u7685-\u9fff]{2,12}(?:\([A-Za-z0-9]+\))?)'
)
_F14_LEADING_CONJ_CN: frozenset[str] = frozenset({'与', '和', '或'})

# F12: copula + 基于/来自 intro family. Phase 8c R14d.
# Three tiers to balance coverage vs. predicate-adjective false positives:
#  - Tier A (unconditional): 转变为|变为|转为|划分为|分为 — always register RHS
#    as intro. Risk is minimal — these verbs are only used for noun transitions.
#  - Tier B (noun-gated): 基于|来自 — register RHS if ≥2 CJK and doesn't start
#    with an adjectival/verb-phrase prefix (_F12_ADJ_REJECTS_CN).
#  - Tier C (two-branch 为|是): (1) ordinal-prefix or paren-numeral RHS
#    (unconditional); (2) bare-noun RHS ≥4 CJK with the same ADJ reject filter.
#    Splits because `A为可光照交联` (adjectival predicate) and `A是经过...`
#    (verb phrase) must be rejected; ordinal-prefix RHS is safe regardless.
_F12_TIER_A_RE_CN: re.Pattern[str] = re.compile(
    r'(?:转变为|变为|转为|划分为|分为)'
    r'([\u4e00-\u7683\u7685-\u9fff]{2,12}(?:\([A-Za-z0-9]+\))?)'
)
_F12_TIER_B_RE_CN: re.Pattern[str] = re.compile(
    r'(?:基于|来自)'
    r'([\u4e00-\u7683\u7685-\u9fff]{2,12}(?:\([A-Za-z0-9]+\))?)'
)
_F12_TIER_C_ORDINAL_RE_CN: re.Pattern[str] = re.compile(
    r'(?:为|是)'
    r'(第[一二三四五六七八九十\d]+[\u4e00-\u7683\u7685-\u9fff]{1,10}'
    r'(?:\([A-Za-z0-9]+\))?'
    r'|[\u4e00-\u7683\u7685-\u9fff]{2,10}\([A-Za-z0-9]+\))'
)
_F12_TIER_C_BARE_RE_CN: re.Pattern[str] = re.compile(
    r'(?:为|是)'
    r'([\u4e00-\u7683\u7685-\u9fff]{4,12}(?:\([A-Za-z0-9]+\))?)'
)
_F12_ADJ_REJECTS_CN: tuple[str, ...] = (
    '可', '具有', '具', '经过', '由', '属于', '用于', '来自',
    '能够', '能', '会',
    '进行', '获得', '获取', '接收', '存储', '输出', '输入',
    '基于', '根据',
    # === Phase 8c R7-port (2026-04-30) — TW R7 parity ===
    # Copula / preposition / verb-prefix rejects for F6 bare-NP arm 3
    # and F12 Tier B emit. CN equivalents of TW's 係/是/為/較/對/在/將/
    # 藉/蝕. Mirror set with TW _F12_ADJ_REJECTS_TW so semiconductor /
    # process-method drafts surface clean noun heads on CN side.
    '系', '是', '为',
    '较', '对', '在',
    '将', '借', '蚀',
)

# F7d: participial `<tail>的Y` intro family. Phase 8c R14b.
# Stative-participle tails that introduce a new noun Y after 的. Intentionally
# narrow allowlist — DE_POSSESSIVE is heterogeneous and a broad `V的Y` regex
# would over-fire. Post-capture cleanup via clean_noun_phrase_cn handles
# trailing-verb overcaptures (e.g., 训练目标进行训练 → 训练目标 via interior-verb
# truncation at 进行 from R8).
_F7D_PARTICIPIAL_TAILS_CN: tuple[str, ...] = (
    '所对应', '按照预设', '相对应', '接收到',
    '预设', '所需', '相关', '对应', '匹配',
    '得到', '制得', '执行', '制造', '相连',
    '生成', '连接', '形成', '组成',
    # === R30 (2026-05-03) — extended participial tails from corpus ===
    # Round-1 corpus walker_fps include patterns like
    # `<X>覆盖的Y`, `<X>构成的Y`, `<X>设置的Y`, `<X>包含的Y` that the
    # original F7d allowlist doesn't catch. Adding them is safe because:
    # (a) each is clearly a participial verb (not a noun), (b) the trailing
    # 的 ensures Y is an attribute of X — registering Y as intro is correct
    # under §112(b) when X is in the chain.
    '覆盖', '构成', '设置', '配置', '安装',
    '提供', '获取', '获得', '产生',
    '所述包括', '所述包含', '所述具有',
    '附加', '增加', '减少', '改变', '修改',
    '包括', '包含', '具有',
)
_F7D_PATTERN_CN: re.Pattern[str] = re.compile(
    r'(?:' + '|'.join(re.escape(t) for t in _F7D_PARTICIPIAL_TAILS_CN) + r')'
    r'的([\u4e00-\u7683\u7685-\u9fff]{2,12}(?:\([A-Za-z0-9]+\))?)'
)
# Reuses _F12_ADJ_REJECTS_CN.

# F5a ref-prefix set (Q1: 该等/该些 excluded).
_REF_PREFIX_SET_CN = ('所述', '该', '前述')

_REF_POSSESSIVE_WITH_NUM_CN = re.compile(
    r'(?:所述|该|前述)'
    r'[\u4e00-\u7683\u7685-\u9fff]{2,}\([A-Za-z0-9]+\)'
    r'的'
    r'([\u4e00-\u7683\u7685-\u9fff]{2,}(?:\([A-Za-z0-9]+\))?)'
)
_REF_POSSESSIVE_NO_NUM_CN = re.compile(
    r'(?:所述|该|前述)'
    r'[\u4e00-\u7683\u7685-\u9fff]{2,4}'
    r'的'
    r'([\u4e00-\u7683\u7685-\u9fff]{2,}(?:\([A-Za-z0-9]+\))?)'
)

_YI_NOUN_PAREN_DE_PATTERN_CN = re.compile(
    r'一[\u4e00-\u7683\u7685-\u9fff]{2,}\([A-Za-z0-9]+\)'
    r'的'
    r'([\u4e00-\u7683\u7685-\u9fff]{2,}(?:\([A-Za-z0-9]+\))?)'
)

_POSSESSIVE_VERB_DENYLIST_CN = {
    '包括', '包含', '具有', '是', '为', '大于', '小于', '等于',
    '设置', '形成', '连接', '连结',
}


# ── R7-port (2026-04-30) — CN architectural buildout for F14/F16/F17/F19/F20 ──
# Mirror of TW R7's bare-modifier intro infrastructure. CN drafters use the
# same structural patterns (locative left-side, verb-X-之/的-Y, instrumental
# clauses) as TIPO drafters; the architectural divergence between CN and
# TW walkers prior to R7 meant CN had no equivalent of these mechanisms.
# This block adds them in advance — without waiting for a CN-side report —
# so CNIPA semiconductor / process-method drafts get the same protection.

# Component-suffix tail set for bare-noun intro emit gates. Mirrors TW
# _F10_COMPONENT_SUFFIXES with CN-specific items (域 region, 极 electrode).
# Single-char only — multi-char composites contribute their tail char which
# is already covered.
_F10_COMPONENT_SUFFIXES_CN: tuple[str, ...] = (
    '部', '件', '体', '器', '阀', '板', '模', '组', '块', '片',
    '环', '壳', '膜', '座', '盘', '筒', '轴', '杆', '轮', '带',
    '管', '架', '框', '壁', '面', '层', '材', '口', '道', '头',
    '侧', '孔', '缝', '边', '顶', '底', '角', '心', '核', '机',
    '柜', '室', '槽', '线', '路', '池', '枢', '盖', '套', '罩',
    '网', '柱', '锥', '球',
    # R7 (2026-04-30) — semiconductor + electronic claim element suffixes:
    # 域 (region: n型区域, p型区域, 主动区域); 极 (electrode pole: 栅极,
    # 源极, 漏极, 集极, 射极)
    '域', '极',
)

# Single-char component-suffix set for walk-back logic. F10's narrow
# endswith gate uses _F10_COMPONENT_SUFFIXES_CN; walk-back uses this
# wider set which includes 法 (method-claim head — `制造方法`).
_F10_SINGLE_CHAR_SUFFIXES_CN: frozenset[str] = frozenset(
    _F10_COMPONENT_SUFFIXES_CN
) | {
    # Walk-back-only: 法 lets `之制造方法` register as `制造方法` (then
    # strip_leading_verb_cn produces `方法`). F10's narrow gate excludes
    # 法 to avoid 想法/做法/算法 misfire on `一种的方法`-style synthetic.
    '法',
}

# Walk-back's discarded-suffix gate — only allow walk-back when the
# discarded portion starts with one of these verb-tail-head characters
# AND has length ≥ 2. Mirrors TW _F14_WALKBACK_VERB_HEADS_TW. CN
# zh-Hans equivalents: 制 (制成, 所制), 经 (经由 — also covers traditional
# 經 in mixed-script).
_F14_WALKBACK_VERB_HEADS_CN: tuple[str, ...] = (
    '所', '露', '形', '构', '组', '制', '经',
    # R7 extension (2026-04-30): 获 covers `X获得Y` / `X获取Y` walk-back
    # in CN process-method drafts. Mirror TW addition; 获利 is rare in
    # claim text, 获得/获取 dominant as verbs.
    '获',
)

# Mixed-script noun class for CN F14/F16/F17/F19/F20. Admits ASCII
# letters/digits + ／ (paired-element separator). Excludes 之 (U+4E4B)
# and 的 (U+7684) so captures don't span possessive markers.
_F14_NOUN_CLASS_CN = r'[A-Za-z0-9／一-乊乌-皃皅-鿿]'

# ADJ/verb heads that must not start a bare-modifier noun capture.
# Mirrors TW _F10_NOUN_REJECTS plus CN-specific copula / preposition /
# verb-prefix rejects.
_F10_NOUN_REJECTS_CN: tuple[str, ...] = (
    '可', '具有', '具', '经过', '由', '属于', '用于', '来自',
    '能够', '能', '会', '进行', '获得', '获取', '接收', '存储',
    '输出', '输入', '基于', '根据',
    '单一', '唯一',
    # R7 — copula / preposition / verb-prefix rejects (zh-Hans equivalents
    # of TW's 系/是/为/较/对/在/将/借/蚀)
    '系', '是', '为',
    '较', '对', '在',
    '将', '借', '蚀',
)

# Leading-verb prefix strip (`形成X`/`制造X` → `X`). Symmetric on intro
# and reference sides per ADR-095. Residual ≥ 2 protects 形成器/形成物
# (3 chars, residual 1 < 2) while admitting 制造方法 (4 chars, residual 2).
# R31 (2026-05-03): added 有 prefix. F-family captures of `设置有X` style
# Pattern B intros leave `有X` after 设置 strip; the leading 有 should be
# stripped to surface bare X. Residual ≥ 2 protects compound nouns
# starting with 有 (有限/有机/有效) — those are 2-char with residual 0/1
# after strip, so still protected.
_LEADING_VERB_PREFIXES_CN: tuple[str, ...] = tuple(sorted(
    (
        '形成', '制造', '有',
        # R32 (2026-05-04): connective-verb prefixes — TW parity.
        # Empirical: `即根据各数字内容` / `使得各数字内容关联` shape leaks
        # into spec-support via shared extract_introductions_cn helper.
        # Multi-char longest-first.
        '即根据', '即基于', '即依据', '即依照',
        '根据', '基于', '依据', '依照',
        '为了', '借以', '借由', '通过',
        '使得', '使其', '从而', '进而', '并且',
        '用以', '用于',
        # R67 (2026-05-05) sweep: 具有 — possession verb ("X has Y").
        # Drafters write `所述具有酸解离性基的结构单元` where the actual
        # antecedent is `结构单元` (or `酸解离性基`), not `具有酸解离性基`.
        # Residual ≥ 2 protects 具有 + 1-char compounds (none expected
        # in patent diction) while admitting 具有 + 2+-char nouns.
        # Attestation: CN120266060A c8 captured `具有酸解离性基`.
        '具有',
    ),
    key=len,
    reverse=True,
))
_LEADING_VERB_RESIDUAL_FLOOR_CN: int = 2


def strip_leading_verb_cn(text: str) -> str:
    """R7 (2026-04-30): strip leading verb prefix (形成/制造) when followed
    by a sufficient noun residual. Used in normalize_*_cn pipelines so
    `所述形成p型源极／漏极` references resolve against bare-noun
    `p型源极／漏极` intros.
    """
    if not text:
        return text
    for prefix in _LEADING_VERB_PREFIXES_CN:
        if (
            text.startswith(prefix)
            and len(text) - len(prefix) >= _LEADING_VERB_RESIDUAL_FLOOR_CN
        ):
            return text[len(prefix):]
    return text


def _trim_capture_to_clean_noun_cn(text: str) -> str | None:
    """R7 (2026-04-30): walk back from end of `text` to the last component-
    suffix character and truncate; return ``None`` if hygiene gates fail.
    Mirror of _trim_capture_to_clean_noun_tw — see that function for full
    contract documentation.
    """
    if not text or len(text) < 2:
        return None
    if text[-1] in _F10_SINGLE_CHAR_SUFFIXES_CN:
        truncated = text
    else:
        clean_end = None
        for i in range(min(len(text), 12), 0, -1):
            if text[i - 1] in _F10_SINGLE_CHAR_SUFFIXES_CN:
                clean_end = i
                break
        if clean_end is None:
            return None
        discarded = text[clean_end:]
        if len(discarded) < 2 or not discarded.startswith(
            _F14_WALKBACK_VERB_HEADS_CN
        ):
            return None
        truncated = text[:clean_end]
    if len(truncated) < 2:
        return None
    for prefix in _REFERENCE_FORM_PREFIXES_CN:
        if prefix in truncated:
            return None
    if truncated.startswith(_F10_NOUN_REJECTS_CN):
        return None
    return truncated


# F14 — bare-modifier `之NOUN` intro (formal-register parallel to F10's
# `的NOUN`). Less common in modern CN claims but appears in formal-register
# / JP-translated CN drafts. Mixed-script noun class for semiconductor.
_F14_BARE_ZHI_NOUN_RE_CN = re.compile(
    r'之'
    r'(?P<noun>' + _F14_NOUN_CLASS_CN + r'{2,12}'
    r'(?:\([A-Za-z0-9]+\))?)'
    r'(?!' + _F14_NOUN_CLASS_CN + r')'
)

# F16 — locative left-side intro `(?:于|在)X[之的]Y`. Captures left-side X
# (the new claim element introduced via locative phrase). CN uses both
# 之 (formal) and 的 (modern) for the possessive marker.
_F16_LOC_LEFT_INTRO_RE_CN = re.compile(
    r'(?:于|在)'
    r'(?P<noun>' + _F14_NOUN_CLASS_CN + r'{2,8}'
    r'(?:\([A-Za-z0-9]+\))?)'
    r'[之的]'
)

# F17 — locative-internal `在X之间` / `在X之间` intro (zh-Hans uses 间).
_F17_LOC_INTERNAL_INTRO_RE_CN = re.compile(
    r'在'
    r'(?P<noun>' + _F14_NOUN_CLASS_CN + r'{2,8}'
    r'(?:\([A-Za-z0-9]+\))?)'
    r'之间'
)

# F19 — `verb + X + [之的] + Y` left-side intro. F6 rejects this shape
# via its `(?![的之])` trailing lookahead; F19 explicitly catches it.
_F19_VERB_NP_ZHI_RE_CN = re.compile(
    r'(?:夹持|包含|包括|具有|含有|具备|设有|设置|配置|安装|装设|形成|构成|连接|连结|提供|构建)'
    r'(?P<noun>' + _F14_NOUN_CLASS_CN + r'{2,8}'
    r'(?:\([A-Za-z0-9]+\))?)'
    r'[之的]'
)

# F20 — `(以|借由|透过|经由|将) X (verb)` instrumental/object intro.
# `以` excluded when followed by `及` (conjunction `以及`).
# R41 (2026-05-04): added `将` (instrumental object marker, very
# common in CN claims for `将<noun><verb>` constructions like
# `将第一激发光输出`/`将信号发送`/`将数据传输`). Extended trailing-
# verb list with output/send/transmit/etc. to cover the most common
# 将-shape cases. Phase A on post-R36 corpus showed CN `发光` cluster
# 48 wfp / 0 legit (top: `第二激发光` 14, `第一激发光` 13) — parent
# claim 1 introduces 第一激发光 via `将第一激发光输出` shape that
# F20 didn't recognize.
_F20_PREP_NP_VERB_RE_CN = re.compile(
    r'(?:以(?!及)|借由|透过|经由|将)'
    r'(?P<noun>' + _F14_NOUN_CLASS_CN + r'{2,8}'
    r'(?:\([A-Za-z0-9]+\))?)'
    r'(?:夹持|覆盖|包含|包括|具有|含有|具备|设有|设置|配置|形成|构成|连接|连结|提供|分隔|划分|实施|分为|构建|测量|蚀刻|除去|装设|安装|输出|输入|发送|接收|传输|传送|生成|获取|获得|确定|存储|读取|写入|执行|处理|计算)'
)


def _extract_supplementary_intros_cn(text: str) -> list[tuple[str, str]]:
    """Extract bare-noun introductions from supplementary CN patterns.

    Returns (original_span, normalized_term) pairs. Active families:
    F5a/F5b, F6, F7b/F7c/F7d, F11 (colon + no-colon), F12, F13. Uniform
    ``clean_noun_phrase_cn`` cleanup. See tw_claims.py lines 1982–2099
    for per-family rationale. F7a/F8/F9 removed after zero-coverage
    R14 investigation confirmed CN corpus never exercises them.
    """
    results: list[tuple[str, str]] = []

    # F7d (R64, 2026-05-05) TW parity: bare locative `于X的Y` — captures X.
    # Same scoping as TW F7d:
    #   1. 于 must follow a clause boundary or claim start
    #   2. X must be ≥ 3 CJK chars
    #   3. X must not start with reference prefix (前述/所述/该/该等/该些)
    # Conservative: CN drafters use 在X上 / 在X中 more than 于X的, so
    # this pattern's hit rate may be low — but adding for cross-jurisdiction
    # symmetry with TW F7d (which surfaced the user-reported 半导体基板
    # missed-intro on 神秘黑屏哥.docx).
    _BARE_YU_X_DE_RE_CN = re.compile(
        r"(?:^|[，、。；\n　])"
        r"于([^\s，。；：、及与和之的该将能须应皆被于以并且其而还另时在前所]{3,12})"
        r"的"
    )
    for m in _BARE_YU_X_DE_RE_CN.finditer(text):
        candidate = m.group(1)
        if any(candidate.startswith(p) for p in _REFERENCE_FORM_PREFIXES_CN):
            continue
        cjk_len = sum(1 for c in candidate if '一' <= c <= '鿿')
        if cjk_len < 3:
            continue
        results.append((m.group(0), candidate))

    # F7b: 一V的Y — participial
    for m in _PARTICIPIAL_YI_DE_PATTERN_CN.finditer(text):
        noun = m.group(1)
        normalized = re.sub(r'\([A-Za-z0-9]+\)', '', noun)
        has_numeral = '(' in noun
        has_ordinal = normalized.startswith('第')
        cjk_len = sum(1 for c in normalized if '\u4e00' <= c <= '\u9fff')
        if not (has_ordinal or has_numeral or cjk_len >= 3):
            continue
        results.append((m.group(0), normalized))

    # F7c: 的第Y — post-的 ordinal noun
    for m in _POST_DE_ORDINAL_PATTERN_CN.finditer(text):
        noun = m.group(1)
        normalized = re.sub(r'\([A-Za-z0-9]+\)', '', noun)
        results.append((m.group(0), normalized))

    # F6: verb + Y — bare-after-verb
    for m in _BARE_AFTER_VERB_PATTERN_CN.finditer(text):
        noun = m.group(1)
        # R14c.2: bare-NP arm (no ordinal, no paren) is gated by
        # _F12_ADJ_REJECTS_CN startswith to suppress predicate-adjective
        # and verb-phrase heads like 可/经过/具有/能够/用于/基于/根据.
        if (not noun.startswith('第')
                and '(' not in noun
                and noun.startswith(_F12_ADJ_REJECTS_CN)):
            continue
        normalized = re.sub(r'\([A-Za-z0-9]+\)', '', noun)
        results.append((m.group(0), normalized))
        # Also split conjunctions (和/与/及/、) into individual intros
        parts = _F11_LIST_SPLIT_CN.split(normalized)
        if len(parts) > 1:
            for part in parts:
                part = part.strip()
                if part:
                    results.append((m.group(0), part))

    # F5a: ref-prefix possessive (two variants)
    for pattern in (_REF_POSSESSIVE_WITH_NUM_CN, _REF_POSSESSIVE_NO_NUM_CN):
        for m in pattern.finditer(text):
            noun = m.group(1)
            normalized = re.sub(r'\([A-Za-z0-9]+\)', '', noun)
            cjk_len = sum(1 for c in normalized if '\u4e00' <= c <= '\u9fff')
            if cjk_len < 2:
                continue
            if normalized.startswith(_REF_PREFIX_SET_CN):
                continue
            end_pos = m.end()
            follower = text[end_pos:end_pos + 2]
            if follower in _POSSESSIVE_VERB_DENYLIST_CN:
                continue
            results.append((m.group(0), normalized))

    # F5b: 一X(N)的Y — intro with paren-numeral possessive
    for m in _YI_NOUN_PAREN_DE_PATTERN_CN.finditer(text):
        noun = m.group(1)
        normalized = re.sub(r'\([A-Za-z0-9]+\)', '', noun)
        cjk_len = sum(1 for c in normalized if '\u4e00' <= c <= '\u9fff')
        if cjk_len < 2:
            continue
        if normalized.startswith(_REF_PREFIX_SET_CN):
            continue
        end_pos = m.end()
        follower = text[end_pos:end_pos + 2]
        if follower in _POSSESSIVE_VERB_DENYLIST_CN:
            continue
        results.append((m.group(0), normalized))

    # F11: list-after-包括 — colon-anchored preamble lists register each
    # element as a bare-noun intro. WQ8 / Phase 8c close-out R3.
    # R14e extends with a no-colon sibling pattern gated on ≥2 `、`-
    # separated elements.
    for anchor_re in (_F11_COLON_LIST_ANCHOR_CN, _F11_NO_COLON_LIST_ANCHOR_CN):
        for m in anchor_re.finditer(text):
            # R29 (2026-05-03): iterate ；-segments instead of truncating
            # at first; strip leading 以及/及 from each segment.
            full_list = m.group(1).split('。')[0]
            for segment in full_list.split('；'):
                segment = segment.strip()
                if not segment:
                    continue
                segment = re.sub(r'^(?:以及|及)\s*', '', segment)
                if not segment:
                    continue
                for element in _F11_LIST_SPLIT_CN.split(segment):
                    element = element.strip()
                    if not element:
                        continue
                    normalized = re.sub(r'\([A-Za-z0-9]+\)', '', element)
                    cjk_len = sum(1 for c in normalized if '\u4e00' <= c <= '\u9fff')
                    if cjk_len < 2:
                        continue
                    if normalized.startswith(_REF_PREFIX_SET_CN):
                        continue
                    results.append((element, normalized))
                    # R30 mechanism #4 (2026-05-03): sub-noun extraction from
                    # `<verb>X\u7684Y` shape inside the captured element. Pattern B
                    # often introduces multiple terms via possessive constructs:
                    # `\u5904\u7406\u672b\u7aef\u6267\u884c\u5668\u7684\u6240\u6709\u4efb\u52a1` should register both `\u672b\u7aef\u6267\u884c\u5668`
                    # and `\u6240\u6709\u4efb\u52a1`. Find the FIRST \u7684 (avoid deep nesting),
                    # split into head/tail, register each if valid noun phrase.
                    de_idx = normalized.find('\u7684')  # \u7684
                    if 0 < de_idx < len(normalized) - 1:
                        head = normalized[:de_idx]
                        tail = normalized[de_idx + 1:]
                        for sub in (head, tail):
                            sub_cjk = sum(1 for c in sub if '\u4e00' <= c <= '\u9fff')
                            if sub_cjk < 2:
                                continue
                            if sub.startswith(_REF_PREFIX_SET_CN):
                                continue
                            if sub.startswith(_F12_ADJ_REJECTS_CN):
                                continue
                            # Strip leading verb prefix (creation-verb subset)
                            # to unwrap `<verb><noun>` head into bare noun.
                            stripped = sub
                            for verb in ('\u63d0\u4f9b', '\u914d\u7f6e', '\u8bbe\u7f6e', '\u5f62\u6210', '\u6784\u6210',
                                          '\u6784\u5efa', '\u83b7\u53d6', '\u83b7\u5f97', '\u5f97\u5230', '\u751f\u6210',
                                          '\u4ea7\u751f', '\u8fde\u63a5', '\u8fde\u7ed3', '\u5b89\u88c5', '\u88c5\u8bbe',
                                          '\u5904\u7406'):
                                if stripped.startswith(verb) and len(stripped) > len(verb) + 1:
                                    rest = stripped[len(verb):]
                                    rest_cjk = sum(1 for c in rest if '\u4e00' <= c <= '\u9fff')
                                    if rest_cjk >= 2:
                                        stripped = rest
                                        break
                            if stripped != sub:
                                results.append((element, stripped))
                            results.append((element, sub))

    # F13: locative-verb + bare noun (+ optional locative suffix). R14a.
    for m in _F13_LOCATIVE_VERB_PATTERN_CN.finditer(text):
        raw = m.group(1)
        if raw.startswith(_REF_PREFIX_SET_CN):
            continue
        normalized = re.sub(r'\([A-Za-z0-9]+\)', '', raw)
        if (
            normalized
            and normalized[-1] in _F13_LOCATIVE_SUFFIXES_CN
            and len(normalized) >= 3
        ):
            normalized = normalized[:-1]
        if len(normalized) < 2:
            continue
        if normalized.startswith(_REF_PREFIX_SET_CN):
            continue
        results.append((m.group(0), normalized))

    # F14: V+有 noun-of-existence intro. Phase 9 #61.
    for m in _F14_V_YOU_PATTERN_CN.finditer(text):
        raw = m.group(1)
        if raw.startswith(_REF_PREFIX_SET_CN):
            continue
        if raw.startswith(_F12_ADJ_REJECTS_CN):
            continue
        if raw and raw[0] in _F14_LEADING_CONJ_CN:
            continue
        if _BARE_ORDINAL_RE_CN.match(raw):
            continue
        normalized = re.sub(r'\([A-Za-z0-9]+\)', '', raw)
        if len(normalized) < 2:
            continue
        results.append((m.group(0), normalized))

    # F12: copula + 基于/来自 intro family. R14d.
    for m in _F12_TIER_A_RE_CN.finditer(text):
        raw = m.group(1)
        if raw.startswith(_REF_PREFIX_SET_CN):
            continue
        normalized = re.sub(r'\([A-Za-z0-9]+\)', '', raw)
        if len(normalized) < 2:
            continue
        results.append((m.group(0), normalized))

    for m in _F12_TIER_B_RE_CN.finditer(text):
        raw = m.group(1)
        if raw.startswith(_REF_PREFIX_SET_CN):
            continue
        if raw.startswith(_F12_ADJ_REJECTS_CN):
            continue
        normalized = re.sub(r'\([A-Za-z0-9]+\)', '', raw)
        if len(normalized) < 2:
            continue
        results.append((m.group(0), normalized))

    for m in _F12_TIER_C_ORDINAL_RE_CN.finditer(text):
        raw = m.group(1)
        if raw.startswith(_REF_PREFIX_SET_CN):
            continue
        normalized = re.sub(r'\([A-Za-z0-9]+\)', '', raw)
        if len(normalized) < 2:
            continue
        results.append((m.group(0), normalized))

    for m in _F12_TIER_C_BARE_RE_CN.finditer(text):
        raw = m.group(1)
        if raw.startswith(_REF_PREFIX_SET_CN):
            continue
        if raw.startswith(_F12_ADJ_REJECTS_CN):
            continue
        normalized = re.sub(r'\([A-Za-z0-9]+\)', '', raw)
        if len(normalized) < 4:
            continue
        results.append((m.group(0), normalized))

    # F7d: participial <tail>的Y. R14b.
    for m in _F7D_PATTERN_CN.finditer(text):
        raw = m.group(1)
        if raw.startswith(_REF_PREFIX_SET_CN):
            continue
        if raw.startswith(_F12_ADJ_REJECTS_CN):
            continue
        normalized = re.sub(r'\([A-Za-z0-9]+\)', '', raw)
        if len(normalized) < 2:
            continue
        results.append((m.group(0), normalized))

    # === Phase 8c R7-port (2026-04-30) — TW R7 architectural buildout ===
    # F14 (V之Y), F16 (locative left-side), F17 (locative-internal),
    # F19 (verb-X-之/的), F20 (instrumental). Mirror of TW R7 mechanisms.
    # All use _trim_capture_to_clean_noun_cn for hygiene.

    # F14: bare-modifier `之NOUN` intro (formal-register parallel to F10).
    for m in _F14_BARE_ZHI_NOUN_RE_CN.finditer(text):
        noun = m.group('noun')
        normalized = re.sub(r'\([A-Za-z0-9]+\)', '', noun)
        trimmed = _trim_capture_to_clean_noun_cn(normalized)
        if trimmed is None:
            continue
        results.append((m.group(0), trimmed))

    # F16: locative left-side intro `(于|在)X[之的]`.
    for m in _F16_LOC_LEFT_INTRO_RE_CN.finditer(text):
        noun = m.group('noun')
        normalized = re.sub(r'\([A-Za-z0-9]+\)', '', noun)
        trimmed = _trim_capture_to_clean_noun_cn(normalized)
        if trimmed is None:
            continue
        results.append((m.group(0), trimmed))

    # F17: locative-internal `在X之间`.
    for m in _F17_LOC_INTERNAL_INTRO_RE_CN.finditer(text):
        noun = m.group('noun')
        normalized = re.sub(r'\([A-Za-z0-9]+\)', '', noun)
        trimmed = _trim_capture_to_clean_noun_cn(normalized)
        if trimmed is None:
            continue
        results.append((m.group(0), trimmed))

    # F19: `verb + X + [之的] + Y` left-side intro.
    for m in _F19_VERB_NP_ZHI_RE_CN.finditer(text):
        noun = m.group('noun')
        normalized = re.sub(r'\([A-Za-z0-9]+\)', '', noun)
        trimmed = _trim_capture_to_clean_noun_cn(normalized)
        if trimmed is None:
            continue
        results.append((m.group(0), trimmed))

    # F20: `(以|借由|透过|经由) X (verb)` instrumental intro.
    for m in _F20_PREP_NP_VERB_RE_CN.finditer(text):
        noun = m.group('noun')
        normalized = re.sub(r'\([A-Za-z0-9]+\)', '', noun)
        trimmed = _trim_capture_to_clean_noun_cn(normalized)
        if trimmed is None:
            continue
        results.append((m.group(0), trimmed))

    # Uniform trailing-verb cleanup
    cleaned: list[tuple[str, str]] = []
    for orig, norm in results:
        cleaned_norm = clean_noun_phrase_cn(norm)
        if not cleaned_norm or len(cleaned_norm) < 2:
            continue
        if cleaned_norm.startswith('第') and len(cleaned_norm) < 4:
            continue
        cleaned.append((orig, cleaned_norm))

    # R14f conjunction-split: for each cleaned intro containing 和/与/及/以及
    # with ≥2 CJK chars on each side, register each element as its own intro.
    seen_norms = {norm for _, norm in cleaned}
    extras: list[tuple[str, str]] = []
    for _, norm in cleaned:
        m = _CONJ_SPLIT_RE_CN.match(norm)
        if not m:
            continue
        for piece in (m.group(1), m.group(2)):
            piece_clean = clean_noun_phrase_cn(piece)
            if not piece_clean or len(piece_clean) < 2:
                continue
            cjk = sum(1 for c in piece_clean if '\u4e00' <= c <= '\u9fff')
            if cjk < 2:
                continue
            if piece_clean.startswith(_REF_PREFIX_SET_CN):
                continue
            if piece_clean in seen_norms:
                continue
            seen_norms.add(piece_clean)
            extras.append((piece_clean, piece_clean))

    # R31 (2026-05-03): generic 的-substring sub-noun extraction across ALL
    # captured intros. R30's F11 sub-noun was F11-only; round-1 mining
    # showed F12/F13/F14 captures also benefit (e.g., F13 locative-verb
    # intros like `位於連接器之間的耦合介面` should register both 連接器
    # and 耦合介面). Apply post-pass over `cleaned` (which contains all
    # F-family results after trim). Single-的 split only.
    # Anti-pattern: skip if both halves < 2 CJK chars OR start with reject prefix.
    cleaned_subs = []
    for orig, norm in cleaned:
        de_idx = norm.find('的')  # 的
        if 0 < de_idx < len(norm) - 1:
            head = norm[:de_idx]
            tail = norm[de_idx + 1:]
            for sub in (head, tail):
                sub_cjk = sum(1 for c in sub if '\u4e00' <= c <= '\u9fff')
                if sub_cjk < 2:
                    continue
                if sub.startswith(_REF_PREFIX_SET_CN):
                    continue
                if sub.startswith(_F12_ADJ_REJECTS_CN):
                    continue
                if sub in seen_norms:
                    continue
                seen_norms.add(sub)
                cleaned_subs.append((orig, sub))
    cleaned.extend(cleaned_subs)

    # R31 second 的-split pass — handles X的Y的Z three-way splits.
    cleaned_subs2 = []
    for orig, norm in cleaned_subs:  # only re-split the newly added ones
        de_idx = norm.find('的')
        if 0 < de_idx < len(norm) - 1:
            head = norm[:de_idx]
            tail = norm[de_idx + 1:]
            for sub in (head, tail):
                sub_cjk = sum(1 for c in sub if '\u4e00' <= c <= '\u9fff')
                if sub_cjk < 2:
                    continue
                if sub.startswith(_REF_PREFIX_SET_CN):
                    continue
                if sub in seen_norms:
                    continue
                seen_norms.add(sub)
                cleaned_subs2.append((orig, sub))
    cleaned.extend(cleaned_subs2)

    # R30 mechanism #11 (2026-05-03): step-label colon intros for method claims.
    # Pattern: `；以及<step-name>:<step-content>` or `；<step-name>:<content>`
    # where the step-name (multi-char CJK before colon) is the new claim element.
    # Common in CN method claims: `；以及印刷步骤：在所述陶瓷块...`. Anti-pattern:
    # the noun must NOT start with reference-prefix or 第N (those are existing
    # references / ordinals, not new step labels).
    _STEP_LABEL_RE_R30 = re.compile(
        r'[；;]\s*(?:以及|及)?\s*([\u4e00-\u9fff]{2,12})\s*[：:]'
    )
    for sl_m in _STEP_LABEL_RE_R30.finditer(text):
        noun = sl_m.group(1)
        if not noun or len(noun) < 2:
            continue
        if noun.startswith(_REF_PREFIX_SET_CN):
            continue
        if noun.startswith('第'):
            continue
        if noun.startswith(_F12_ADJ_REJECTS_CN):
            continue
        if noun in seen_norms:
            continue
        seen_norms.add(noun)
        extras.append((sl_m.group(0), noun))

    # R30 mechanism #7 (2026-05-03): F6c Latin/short-CJK term floor.
    # F6 arms 1-3 require CJK-only nouns. Walker_fps on Latin acronyms
    # (UE, DCI, LHT, CU-CP) and Latin-CJK mixed terms (PWM信号, DCI格式,
    # RAM控制器) need an explicit arm. Pattern: <F6 verb>(<Latin-noun>)
    # where Latin-noun is uppercase Latin chars optionally followed by CJK
    # suffix. Anti-pattern: must be at a clear boundary (followed by
    # punctuation, conjunction, or end-of-clause) to avoid mid-word matches.
    _F6C_VERB_ALT = (
        r'具有|包含|包括|含有|设有|设置|配置|安装|装设|形成|构成|提供|连接|连结'
        r'|获取|获得|得到|生成|产生|发出|发送|接收|输出|输入|传送|存储|确定|涉及'
        r'|进行|调用|运行|调整|建立|构建|制得|根据|存在|使用'
    )
    _F6C_LATIN_RE = re.compile(
        r'(?:' + _F6C_VERB_ALT + r')'
        r'(?P<noun>[A-Z][A-Za-z0-9\-]{1,15}[\u4e00-\u9fff]{0,8})'
        r'(?=[，,。；;、 \t\n或与和及])'
    )
    for fc_m in _F6C_LATIN_RE.finditer(text):
        noun = fc_m.group('noun')
        if not noun or len(noun) < 2:
            continue
        if noun in seen_norms:
            continue
        seen_norms.add(noun)
        extras.append((fc_m.group(0), noun))

    # R30 mechanism #6 (2026-05-03): parenthetical abbreviation bridging.
    # Pattern B intros like `<full term>(<Abbr>)` should register both
    # full and abbrev so later `所述<Abbr>` references resolve.
    # Phase 2c Refinement B (Christopher: LHT/VH-region pattern is common).
    # CN form: `中心单元-控制面(CU-CP)`, `超参数自适应选择策略单元(HASS)`.
    # R34 (2026-05-04): mirror of TW R34 widening \u2014 accept full-width
    # \u5168\u89d2 parens AND lowercase-full-form-then-uppercase-abbrev shape
    # (`\u7528\u6237\u8bbe\u5907(user equipment, UE)`). Cross-jurisdiction parity.
    _PAREN_ABBREV_RE_R30 = re.compile(
        r'([\u4e00-\u9fff]{2,12})'
        r'[(\uff08]\s*'
        r'(?:[a-z][A-Za-z0-9\- ]{0,40}[,;\uff0c\uff1b]\s*)?'
        r'([A-Z][A-Za-z0-9\-]{0,15})'
        r'\s*[)\uff09]'
    )
    for pa_m in _PAREN_ABBREV_RE_R30.finditer(text):
        full_noun = pa_m.group(1)
        abbrev = pa_m.group(2)
        if abbrev not in seen_norms and len(abbrev) >= 2:
            seen_norms.add(abbrev)
            extras.append((pa_m.group(0), abbrev))
        if full_noun not in seen_norms:
            seen_norms.add(full_noun)
            extras.append((pa_m.group(0), full_noun))

    # R50 (2026-05-05): Chinese-name-Latin-abbrev juxtaposition (no parens).
    # Drafters introduce telecom/protocol acronyms via Chinese-then-Latin
    # format with NO parens between them: `所述IGP报文包括类型长度值TLV`
    # introduces both 类型长度值 (the descriptor) AND TLV (the acronym).
    # Phase 1 cluster `SHAPE|CN|ASCII_UPPER:SHORT` (81 wfp / 0 legit on
    # supplement_v2 corpus, 2026-05-05).
    #
    # Trigger: must be preceded by Pattern B-style introducer
    # (`包括`/`包含`/`为`/`是`) so we don't over-extract from random
    # Chinese-Latin neighbor pairs.
    #
    # Boundary check after the Latin abbrev: punctuation, common
    # particles, sentence end. Prevents the regex from greedily eating
    # into mixed-script compound nouns where Latin and Chinese are
    # genuinely distinct tokens.
    #
    # Both the Chinese descriptor and Latin acronym register as intros;
    # the walker's normal exact-match resolves `所述TLV` references
    # against the Latin form.
    _CN_LATIN_ABBREV_RE = re.compile(
        r'(?:包括|包含|为|是)\s*'
        r'([一-鿿]{2,12})'
        r'([A-Z][A-Za-z0-9]{1,4})'
        r'(?=[，。；,;:、(（]|的|所述|实施|是|为|具有|$|\s)'
    )
    for la_m in _CN_LATIN_ABBREV_RE.finditer(text):
        chinese = la_m.group(1)
        latin = la_m.group(2)
        if latin not in seen_norms and len(latin) >= 2:
            seen_norms.add(latin)
            extras.append((la_m.group(0), latin))
        if chinese not in seen_norms:
            seen_norms.add(chinese)
            extras.append((la_m.group(0), chinese))

    # R50b (2026-05-05): AF-style Pattern A preamble juxtaposition.
    # Drafters embed acronyms in Pattern A preambles via function-role
    # suffix anchoring:
    #
    #   `一种由与通信网络相关联的应用功能AF实施的方法`
    #            └──── 应用功能AF: 应用功能 = "application function" descriptor,
    #                              AF = "Application Function" acronym
    #
    # Phase 1 supplement_v2 cluster SHAPE|CN|ASCII_UPPER:SHORT residual
    # 52 wfp after R50 (R50 only handles 包括/包含-triggered shapes).
    #
    # Anchor: well-known telecom/protocol function-role suffixes that
    # ALWAYS signal "<noun phrase><suffix><acronym>" pattern. Narrow
    # allowlist so we don't over-extract from random Chinese-Latin
    # neighbor pairs. Drafters universally use these CJK suffixes for
    # functional/network entities — high precision.
    _CN_FUNCTION_SUFFIXES = (
        r'功能|服务|系统|网络|设备|单元|协议|平面|层|消息|报文|网元|节点'
    )
    _CN_FUNCTION_LATIN_ABBREV_RE = re.compile(
        r'([一-鿿]{1,8}(?:' + _CN_FUNCTION_SUFFIXES + r'))'
        r'([A-Z][A-Za-z0-9]{1,4})'
        r'(?=[，。；,;:、(（]|的|所述|实施|是|为|具有|包括|包含|$|\s)'
    )
    for la_m in _CN_FUNCTION_LATIN_ABBREV_RE.finditer(text):
        chinese = la_m.group(1)
        latin = la_m.group(2)
        if latin not in seen_norms and len(latin) >= 2:
            seen_norms.add(latin)
            extras.append((la_m.group(0), latin))
        if chinese not in seen_norms:
            seen_norms.add(chinese)
            extras.append((la_m.group(0), chinese))

    # R51 (2026-05-05): facilitate-verb verbal-noun introduction.
    # CN method-claim drafters introduce verbal nouns via constructions
    # like `便于操作的执行` ("facilitates operation's execution") where
    # 操作 (the operation) is intended as a noun-introduction. Subsequent
    # `所述操作` references should resolve.
    #
    # Phase 1 supplement_v2 cluster `TAIL|CN|操作` + `HEAD|CN|操作`
    # (65 wfp / 0 legit, 13 distinct drafts).
    #
    # Trigger verbs limited to clear "facilitate/realize" semantics. NOT
    # 用于 (for-use-of, much broader and risks over-extraction). NOT
    # 使 / 让 (causative, too generic).
    #
    # Pattern: <facilitate-verb> <X> 的 <Y>
    #   register X as intro (Y is captured by other extractors)
    _CN_FACILITATE_VERBS = r'便于|促进|完成|实现|执行|支持|有助于'
    _CN_FACILITATE_X_DE_Y_RE = re.compile(
        r'(?:' + _CN_FACILITATE_VERBS + r')'
        r'([一-鿿]{2,8})'
        r'的[一-鿿]{1,8}'
    )
    for fv_m in _CN_FACILITATE_X_DE_Y_RE.finditer(text):
        x_term = fv_m.group(1)
        if x_term not in seen_norms and len(x_term) >= 2:
            seen_norms.add(x_term)
            extras.append((fv_m.group(0), x_term))

    # R37 (2026-05-04): mirror of TW R37 F22 — list-item bare-noun
    # extraction WITHOUT colon trigger. CN parity: parent claim
    # introduces multiple components in `<verb><N1>、<N2>以及<N3>`
    # comma-list shape:
    #   `导电端子包括差分信号端子、第一接地端子以及第二接地端子`
    # Trigger verbs limited to `包括`/`包含` (most reliable list verbs).
    # Each item must be 2-12 pure CJK chars (filters out fragments
    # with embedded Latin/digit/punctuation). Reference-prefix items
    # are skipped (they're not new intros).
    # R44 (2026-05-04): expand triggers to 具有/具备/设有/含有 BUT only
    # when the captured list has >=2 commas (3+ items) — single-comma
    # lists with these triggers were too noisy on R37/R38 gate-3
    # spec-support test. 3+ items strongly signal a list (not a
    # possessive or modifier sequence).
    _F22_NO_COLON_LIST_CN = re.compile(
        r'(?:包括|包含)'
        r'((?:[一-鿿]{2,12}[、，])+'
        r'(?:[一-鿿]{2,12}(?:以及|及|和|或))?'
        r'[一-鿿]{2,12})'
        r'|'
        r'(?:具有|具备|设有|含有)'
        r'((?:[一-鿿]{2,12}[、，]){2,}'
        r'(?:[一-鿿]{2,12}(?:以及|及|和|或))?'
        r'[一-鿿]{2,12})'
    )
    _F22_LIST_SPLIT_CN = re.compile(r'[、，]|以及|及|和|或')
    for fl_m in _F22_NO_COLON_LIST_CN.finditer(text):
        # Either group 1 (包括/包含 with >=1 comma) or group 2
        # (具有/具备/设有/含有 with >=2 commas) captures the list.
        list_text = fl_m.group(1) or fl_m.group(2)
        if not list_text:
            continue
        for item_raw in _F22_LIST_SPLIT_CN.split(list_text):
            item = item_raw.strip()
            if not item or len(item) < 2:
                continue
            if item.startswith(_REF_PREFIX_SET_CN):
                continue
            if not all('一' <= ch <= '鿿' for ch in item):
                continue
            if item in seen_norms:
                continue
            seen_norms.add(item)
            extras.append((fl_m.group(0), item))

    return cleaned + extras


def extract_introductions_cn(
    claim: Claim,
    *,
    strict_qualifier_matching: bool = False,
) -> list[tuple[str, str]]:
    """Extract introductions from a CN claim as (original, normalized) pairs."""
    pairs: list[tuple[str, str]] = []
    seen: set[str] = set()
    for m in _INTRO_PATTERN_CN.finditer(claim.text):
        original = m.group(0)
        bare_noun = m.group(1)
        candidates = _postprocess_intro_capture_cn(bare_noun, m, claim.text)
        for candidate in candidates:
            normalized = normalize_candidate_intro_cn(
                candidate,
                strict_qualifier_matching=strict_qualifier_matching,
            )
            if not normalized:
                continue
            if normalized not in seen:
                seen.add(normalized)
                pairs.append((original, normalized))

        # R67 (2026-05-08) — symmetric state-modifier+head-noun lookahead.
        # CN parity with the TW R67 intro-side extension. Mirrors the
        # walker reference-side R66 logic so consistent intro+ref pairs
        # like `一岛状的纳米片积层体` ↔ `所述岛状的纳米片积层体` resolve
        # without spurious walker_fp. Also drops the bare state-modifier
        # form (e.g. `岛状`) from inventory once the extended form is
        # captured — bare 岛状 alone is the modifier, not a claim noun.
        if (
            bare_noun.endswith(_STATE_MODIFIER_SUFFIXES_CN)
            and not bare_noun.startswith("第")
        ):
            m_de = _DE_HEAD_NOUN_RE_CN.match(claim.text, m.end())
            if m_de:
                head_raw = m_de.group("head")
                extended_bare = bare_noun + "的" + head_raw
                extended_normalized = normalize_candidate_intro_cn(
                    extended_bare,
                    strict_qualifier_matching=strict_qualifier_matching,
                )
                if extended_normalized:
                    bare_norms_to_drop: set[str] = set()
                    for cand in candidates:
                        cand_norm = normalize_candidate_intro_cn(
                            cand,
                            strict_qualifier_matching=strict_qualifier_matching,
                        )
                        if (
                            cand_norm
                            and cand_norm != extended_normalized
                            and cand_norm.endswith(_STATE_MODIFIER_SUFFIXES_CN)
                        ):
                            bare_norms_to_drop.add(cand_norm)
                    if bare_norms_to_drop:
                        seen -= bare_norms_to_drop
                        pairs[:] = [
                            (o, n) for (o, n) in pairs
                            if n not in bare_norms_to_drop
                        ]
                    if extended_normalized not in seen:
                        seen.add(extended_normalized)
                        extended_original = original + "的" + head_raw
                        pairs.append((extended_original, extended_normalized))

    # R7 (2026-04-30): also apply strip_leading_verb_cn to supplementary
    # intros so a captured `制造方法` (from F14 on `之制造方法`) registers
    # as `方法` after stripping the leading 制造 verb prefix — matching
    # the canonical method-claim head-noun reference `所述方法`.
    supplementary = _extract_supplementary_intros_cn(claim.text)
    for orig, norm in supplementary:
        # R63 (2026-05-05) parity with TW — apply Arabic→CJK ordinal
        # normalize so claim 1 supplementary intro `第1间隔件` registers
        # as `第一间隔件`, matching dep claim references that go through
        # `normalize_reference_term_cn` which already applies the convert.
        # Without this the asymmetry produces spurious walker_fp findings
        # on CN drafts using Arabic-ordinal element naming.
        norm = normalize_arabic_ordinal_to_cjk(norm)
        norm = strip_leading_verb_cn(norm)
        if not norm or norm in seen:
            continue
        # R32 (2026-05-04): TW parity — drop intros with newline/colon
        # (capture crossed paragraph or label boundary). Spec-support
        # reads intros directly so guard at extraction time.
        if '\n' in norm or '：' in norm or ':' in norm:
            continue
        seen.add(norm)
        pairs.append((orig, norm))

    # R32 (2026-05-04): F-head-indep — capture rightmost head noun from
    # `一种<modifier>的<HEAD>，` independent-claim preambles. CN parity
    # with TW R32. Default `_INTRO_PATTERN_CN` excludes `的` from the
    # noun class, so a long preamble like `用于X的Y的装置` only captures
    # fragment intros, leaving the canonical head `装置` unregistered
    # for downstream `所述装置` references in dependent claims.
    #
    # Conflict guard: skip registration when claim text contains a
    # `<head><positional-suffix>` form (装置侧, 处理器端) that would be
    # a distinct §112 entity. Without this, prefix-match resolves
    # `所述装置侧` → `装置` and masks legit drafting errors (CN115485995B
    # c121 protect:true label).
    for m in _F_HEAD_INDEP_RE_CN.finditer(claim.text):
        head = m.group('head')
        if not head or head in seen:
            continue
        if _f_head_indep_conflict_cn(head, claim.text):
            continue
        seen.add(head)
        pairs.append((m.group(0), head))

    return pairs


# R32 (2026-05-04): F-head-indep regex (CN parity with TW). Captures
# rightmost head noun in `一种<modifier>的<HEAD>，` preambles.
# Conflict guard applied at registration time (not in regex): the head
# is rejected if `<head><1-3 CJK>` appears elsewhere in the claim text,
# since prefix-match resolution would over-resolve longer references
# onto the captured head (CN115485995B c121: `装置 + 装置侧` collision
# masks legit drafting error). The narrower regex (lookahead trailing
# verbs) was tried but lost ~95 walker_fp silences in CN, ~135 in TW;
# the conflict-guard approach preserves silence yield while protecting
# protect:true labels.
_F_HEAD_INDEP_RE_CN: re.Pattern[str] = re.compile(
    r'一种(?:[^，。；,;:：]{4,80})的'
    r'(?P<head>[一-鿿]{2,12})'
    r'(?=[，,。；;:：])'
)


_F_HEAD_POSITIONAL_SUFFIX_RE_CN: re.Pattern[str] = re.compile(
    r'(?:侧|端|部|面|段|层|区|际|际面|底|顶|前|后|左|右|内|外|上|下|侧面|端面|端部|底部|顶部|前面|后面|左面|右面|内部|外部|上部|下部|内侧|外侧|内端|外端|内层|外层|内面|外面)'
)


def _f_head_indep_conflict_cn(head: str, claim_text: str) -> bool:
    """True if registering `head` would cause prefix-match over-resolution.

    R32 (2026-05-04): scan for `<head><positional-suffix>` patterns where
    the suffix indicates a DIFFERENT entity (装置侧 vs 装置, 处理器端 vs
    处理器). Positional suffixes (侧/端/部/面/段/底/顶/前/后/左/右/内/外/上/下
    + compounds) frequently create distinct claim elements; prefix-match
    would wrongly resolve them. Compound-noun patterns (装置中的, 装置包括)
    don't trigger because they require additional non-suffix CJK after.
    """
    pattern = re.compile(re.escape(head) + r'(?:' + _F_HEAD_POSITIONAL_SUFFIX_RE_CN.pattern + r')(?:[，,。；;:： \t]|$)')
    return bool(pattern.search(claim_text))


def full_ref_starts_with_plural_cn(text: str) -> bool:
    """True iff text begins with a plural quantifier marker."""
    return text.startswith(("复数", "多个", "数个", "复数个"))


_BARE_GENUS_NOUNS_CN: frozenset[str] = frozenset({
    "方法", "装置", "系统", "设备", "组件",
    "模块", "单元", "电路", "部件", "芯片",
})

_GENUS_PREAMBLE_RE_CN: re.Pattern[str] = re.compile(
    r"(?:(?:如|根据)权利要求[^，。\n]*?" + _CN_DEP_CONNECTIVE + r"[^，。\n]*?|一种[^，。\n]*?)"
    r"(?:方法|装置|系统|设备|组件|模块|单元|电路|部件|芯片)[，,\s]"
)


# Phase 8c R22 — chemistry formula reference like 式(1) / 式(L-4) / 式(I).
# These are bibliographic-style references to formulae defined elsewhere in
# the spec, not noun terms; missing-antecedent doesn't apply.
_FORMULA_REFERENCE_RE_CN: re.Pattern[str] = re.compile(r"^式\([^)]+\)$")

# Phase 8c R22 — verb-predicate term suppression. Walker captured a bare
# verbal idiom (e.g., 安装有 from 使得安装有X的Y); the trailing-strip already
# eliminated the noun head, leaving the pure predicate as the term.
# R23 extends with cascade-product predicates from over_capture round
# (加入胰蛋白酶消化 → 加入; 加热沸腾提取 → 加热沸腾).
_VERB_PREDICATE_TERMS_CN: frozenset[str] = frozenset({
    "安装有", "存储有", "形成有", "设置有",
    "加入", "加热沸腾",
    # R68 (2026-05-06) — TW parity. Pure-action verbs from supplement_v2
    # walker_fp mining (n=6289 CN walker_fp): 确定 ~15, 进行 ~3, 获得,
    # 判断, 执行, 完成. Safe-suppress: drafters never use as standalone
    # noun antecedents; appear only in compounds (确定值/获得结果 etc.).
    "确定", "进行", "获得", "判断", "执行", "完成",
})


_FORMULA_ORDINAL_RE_CN: re.Pattern[str] = re.compile(r"^第[A-Za-z]")
_BARE_ORDINAL_RE_CN: re.Pattern[str] = re.compile(
    r"^第[一二三四五六七八九十\d]+$"
)


# Phase 8c R21 — DYM quality gate. Audit (docs/8c/suggested-match-audit.md,
# Phase 9 #57) showed 85% of corpus DYMs have substring-relationship with
# the reference; ~30% of those are over-captured garbage the walker's intro
# extraction pool emitted as legitimate intros. These filters reject DYM
# candidates the Jaccard loop already picked, without changing the finding
# pool. Non-shifting — `suggested_match` is terminal-only.
_DYM_LEADING_REJECTS_CN: tuple[str, ...] = (
    "能够由", "响应于", "针对", "基于",
    "对", "从", "向", "为", "在",
    "与", "和", "以", "于", "且", "还", "由", "被",
)

_DYM_STOP_PARTICLES_CN: tuple[str, ...] = (
    "的", "于", "在", "为", "对", "从", "向",
    "与", "和", "以", "且", "还", "由", "被",
    "所述", "前述", "该",
    "能够由", "响应于", "针对", "基于",
    "初始化时", "之前", "之后",
)


def _dym_quality_reject_cn(ref: str, dym: str) -> bool:
    """True if DYM should be suppressed.

    Three filters:
      1. `len(dym) > 2 * len(ref)` — disproportionate expansion.
      2. DYM starts with a token in `_DYM_LEADING_REJECTS_CN` — walker
         captured a prep/particle-headed fragment, not a clean NP.
      3. `ref in dym` strict substring AND the wrapping chars contain any
         stop-particle — walker captured the ref + noise.
    """
    if len(dym) > 2 * len(ref):
        return True
    for prefix in _DYM_LEADING_REJECTS_CN:
        if dym.startswith(prefix):
            return True
    if len(ref) < len(dym) and ref in dym:
        idx = dym.index(ref)
        before = dym[:idx]
        after = dym[idx + len(ref):]
        if any(p in before or p in after for p in _DYM_STOP_PARTICLES_CN):
            return True
    return False


def _is_bare_genus_self_reference_cn(term: str, claim_text: str) -> bool:
    """Suppress bare-genus self-references in claim preambles (WQ5).

    When the claim's preamble declares the genus as its subject — either
    the dependent form ``(如|根据)权利要求N所述的<genus>`` or the independent
    form ``一种...<genus>，`` — a bare ``所述<genus>`` later in the body is
    a trivial self-reference, not a missing antecedent. Phase 8c close-out
    R1.
    """
    if term not in _BARE_GENUS_NOUNS_CN:
        return False
    return bool(_GENUS_PREAMBLE_RE_CN.search(claim_text))


# R35 (2026-05-23) — bare-noun-introduction rescue (CN mirror of TW R7
# has_bare_noun_introduction_tw and US R4 utils.has_bare_noun_introduction).
#
# A multi-character noun first mentioned article-less -- as a verb or
# coverb object (接收输入信号 / 基于超宽频连接) or a clause / enumeration
# item -- establishes antecedent basis under the same MPEP s 2173.05(e)
# reasonable-ascertainability standard CNIPA 审查指南 applies (清楚 /
# 明确). The intro extractors register only quantified / framed intros
# plus F10 de-NOUN gated to component-suffix nouns, so article-less data
# / attribute nouns slip through.
#
# Two CJK-aware guards (the two bugs that halted the naive TW R5 port):
#   (a) whole-compound-boundary -- an occurrence whose neighbour char is
#       a noun-compounding CJK ideograph is the tail / head of a longer
#       compound, not a standalone mention.
#   (b) possessive guard -- an occurrence headed by 的 or 之 is never
#       counted: <noun>的X is surface-identical to a <verb-phrase>的X
#       relative clause. The F10 extractor already handles the safely-
#       disambiguable subset (component-suffix nouns); the rescue defers
#       to F10 there and rejects 的 / 之 outright.
_BARE_NOUN_INTRO_VERBS_CN: tuple[str, ...] = tuple(
    sorted(
        {v for v in _F6_VERB_ALT_CN.split("|") if v}
        | {"基于", "来自", "通过", "经由", "利用", "依据", "依"}
        # R36 (2026-05-29): include F11 locative verbs as bare-noun-intro
        # contexts. Issues #141 / #142 — drafter wrote
        # `限位于第三位置或第四位置二者之一` (constrained to be at position 3 or
        # position 4, one of the two). The `endswith(verb)` left-clean
        # check missed because `位于` / `设于` / `置于` etc. are the
        # canonical locative verbs in CN claim diction yet weren't in the
        # bare-noun verb set. Already known to other arms (F11 at line
        # 2194). MPEP-equivalent: 审查指南 第二部分第二章 §3.2.5
        # (clear/明确 standard).
        | {"位于", "置于", "设于", "应用于", "作用于", "布置于", "固定于"},
        key=len,
        reverse=True,
    )
)
# Noun-compounding CJK ideographs = CJK range minus the _NOUN_CHARS_CN
# exclusion set (clause stops, conjunctions, possessive markers, modals).
_BARE_NOUN_BOUNDARY_CN: frozenset[str] = frozenset(
    set(_NOUN_CHARS_CN[_NOUN_CHARS_CN.index("s") + 1 : _NOUN_CHARS_CN.index("]")])
    # R36 (2026-05-29): 或 (or) is a Markush enumerator that separates
    # bare noun mentions in claim diction; never part of a noun's name.
    # Issues #141 / #142 — drafter wrote `限位于第三位置或第四位置二者之一`;
    # without 或 in the boundary set, `_bare_noun_right_clean_cn`
    # treated `第三位置或...` as a longer compound and rejected the
    # bare intro.
    | {"或"}
    # R39 (2026-06-11): 至 (goal-preposition "to") terminates a verb-object
    # bare-noun introduction. Issues #221/#222/#223 — drafter wrote
    # `通过该主机发送控制指令至该显示器`; the object `控制指令` is a complete
    # bare-noun intro, but without 至 in the boundary set
    # `_bare_noun_right_clean_cn` treated `控制指令至...` as a longer
    # compound and rejected it, so `该控制指令` was flagged as lacking
    # antecedent. 至 is a goal-preposition, never a noun-compound interior
    # char (夏至/冬至 END in 至; it is not a continuation char after a
    # noun). Corpus-neutral: ephemeral sim showed 0 delta across all 16
    # CN fixtures (the verb-object-至 pattern is not in the corpus pool).
    | {"至"}
)
_BARE_NOUN_CJK_RE_CN: re.Pattern[str] = re.compile(r"[一-鿿]")
_BARE_NOUN_MIN_LEN_CN = 4


def _bare_noun_compound_char_cn(c: str) -> bool:
    """True if c is a CJK ideograph that compounds into a noun phrase."""
    return bool(_BARE_NOUN_CJK_RE_CN.match(c)) and c not in _BARE_NOUN_BOUNDARY_CN


def _bare_noun_left_clean_cn(text: str, i: int) -> bool:
    """True if the occurrence at i is a fresh, article-less left boundary."""
    if i == 0:
        return True
    if text[i - 1] in ("该", "一"):
        return False  # reference / quantifier
    if i >= 2 and text[i - 2:i] in ("所述", "前述"):
        return False
    # Verb-object / coverb-object: the run before the term ends with a
    # verb. Checked first -- coverbs (基于) end in a boundary char (于).
    if any(text[:i].endswith(v) for v in _BARE_NOUN_INTRO_VERBS_CN):
        return True
    c = text[i - 1]
    if c.isspace() or unicodedata.category(c)[0] == "P":
        return True  # clause boundary / enumeration item
    # R36 (2026-05-29): CJK noun-enumeration conjunctions ({或, 及, 与, 和})
    # are clause boundaries — they introduce the next noun in a Markush
    # `A或B`, `A、B及C`, etc. enumeration. Issues #141 / #142 — drafter
    # wrote `限位于第三位置或第四位置二者之一`; the second mention `第四位置`
    # is preceded by `或` (CJK letter, not Unicode punctuation), so the
    # Unicode-category check above missed it.
    #
    # Critical narrowing: this set MUST NOT include 的 / 之 / 其 / 被 / 由
    # even though they're in `_BARE_NOUN_BOUNDARY_CN`. They're possessive /
    # pronoun / passive markers that head relative clauses (e.g.
    # `所述X相关的Y` = "the Y related to X"), where Y is NOT a fresh bare
    # intro — that's exactly the guard (b) the function docstring describes.
    # Accepting them would silence real §112(b) defects like
    # CN115485995B c82/c124's `第一训练信号` (R20 parallel-invention
    # drafter-error protect:true labels).
    if c in _BARE_NOUN_ENUMERATORS_CN:
        return True
    # CJK ideograph not preceded by a verb -- compound tail (guard a),
    # 的 / 之 possessive marker (guard b), or a conjunction / modal not
    # verb-led. All rejected conservatively.
    return False


_BARE_NOUN_MARKUSH_CLOSERS_CN: tuple[str, ...] = ("二者", "三者", "四者", "任一", "任意")

# R36 (2026-05-29): CJK noun-enumeration conjunctions accepted as left
# boundaries in `_bare_noun_left_clean_cn`. Strict subset of
# `_BARE_NOUN_BOUNDARY_CN` — explicitly excludes 的 / 之 / 其 / 被 / 由
# (possessive / pronoun / passive markers) which head relative clauses
# and must remain rejected per guard (b).
_BARE_NOUN_ENUMERATORS_CN: frozenset[str] = frozenset({"或", "及", "与", "和"})


def _bare_noun_right_clean_cn(text: str, j: int) -> bool:
    """True if the term is not the head of a longer noun compound (guard a)."""
    if j >= len(text):
        return True
    # R36 (2026-05-29): Markush closers `N者` / `任一` mark the end of an
    # `X或Y二者之一` enumeration — the term is the last enumeration item,
    # not the head of a longer compound. Issues #141 / #142 — drafter
    # wrote `第三位置或第四位置二者之一`; without this carve-out the right
    # side of `第四位置` was `二` (CJK char, not a boundary), so the bare
    # intro was rejected. The closers are unambiguous Markush idioms;
    # `第二X` wouldn't end a term that starts mid-compound just before
    # `第二` (drafters separate enumeration items with 或 / 、).
    if any(text[j:].startswith(closer) for closer in _BARE_NOUN_MARKUSH_CLOSERS_CN):
        return True
    return not _bare_noun_compound_char_cn(text[j])


def has_possessive_introduction_cn(
    claim_text: str, chain: list, term: str, ref_offset: int
) -> bool:
    """R37 (2026-06-01) — TW R9 parity (issue #134 generalization).

    True if ``term`` appears earlier in possessive position
    ``(所述|前述|该)<X>(的|之)<term>``, where the genitive owner X is
    itself referenced. Y (the term) gets antecedent basis from this
    first article-less possessive mention.

    CN-specific notes:
    - Accepts BOTH 的 (modern CNIPA standard) and 之 (classical /
      JP-translation variant) as genitive markers. TW uses 之
      predominantly; CN drafters split between 的 and 之.
    - Markers ``所述`` / ``前述`` / ``该`` (CN simplified — TW equivalent
      is ``該``).

    Differs from ``has_bare_noun_introduction_cn``:
    - NO 4-char min-len gate (the structural pattern is unambiguous so
      short locative attributes 顶面/底面/侧面/端面/顶端/底端 qualify).
    - Accepts ``的``/``之``-headed left context. Guard (b) in
      ``has_bare_noun_introduction_cn`` blanket-rejects these to defend
      against verb-phrase relative-clause ambiguity. That defense
      doesn't apply when the required ``所述/前述/该<X>(的|之)`` prefix
      anchors the construction as definite genitive.

    Statute pin: CNIPA 审查指南 第二部分第二章 §3.2 "清楚" / "明确"
    antecedent standard; MPEP § 2173.05(e) equivalent.
    """
    t = (term or "").strip()
    if not t or len(t) < 2:
        return False
    if any(ch.isdigit() for ch in t) or "(" in t:
        return False
    # CN R37 narrowing: ordinal-led terms (第一X / 第二X / ...) are
    # EXCLUDED. Doctrine is ambiguous — `所述X的第一Y` may be either
    # (a) a definitional intro of "the first Y of X" in possessive
    # position, OR (b) a definite reference to a previously-introduced
    # "first Y" that strict §112(b) requires to have its own clean
    # intro. The R20 corpus maintainer chose reading (b) (e.g.,
    # CN115485995B c82/c124's `所述第三信号相关的第一训练信号` is
    # marked protect:true as a real §112(b) defect). To preserve that
    # protect AND still cover the unambiguous locative-attribute
    # pattern (顶面/底面/侧面/端面 — non-ordinal short nouns that R9 was
    # designed for), exclude terms starting with the 第 ordinal prefix.
    if t.startswith("第"):
        return False

    def _scan(text: str, limit: int | None) -> bool:
        start = 0
        while True:
            idx = text.find(t, start)
            if idx < 0:
                return False
            if limit is not None and idx >= limit:
                return False
            # Possessive intro shape: text[idx-1] is 的 OR 之 AND the
            # 15-char window before that marker contains 所述/前述/该.
            if idx >= 1 and text[idx - 1] in ("的", "之"):
                look_back = text[max(0, idx - 16):idx - 1]
                if any(marker in look_back for marker in ("所述", "前述", "该")):
                    # Right-clean intentionally skipped (same rationale as
                    # has_possessive_introduction_tw — verb-start chars
                    # would block legitimate intros of short locatives).
                    return True
            start = idx + 1

    if _scan(claim_text or "", ref_offset):
        return True
    for ancestor in chain[1:]:
        if _scan(getattr(ancestor, "text", "") or "", None):
            return True
    return False


def has_bare_noun_introduction_cn(
    claim_text: str, chain: list, term: str, ref_offset: int
) -> bool:
    """True if multi-character noun ``term`` is introduced earlier article-less.

    "Introduced earlier" = a whole-phrase, article-less occurrence of
    ``term`` preceding the reference in document order: in ``claim_text``
    before ``ref_offset``, or anywhere in an ancestor claim (``chain[1:]``
    -- every ancestor is wholly earlier). Gated multi-character
    (>= 4 CJK chars). Digit / paren-numeral terms are excluded -- those
    resolve via the paren-asymmetry path. See the constant block above
    for the (a) compound-boundary and (b) possessive guards.
    """
    t = (term or "").strip()
    if len(t) < _BARE_NOUN_MIN_LEN_CN:
        return False
    if any(ch.isdigit() for ch in t) or "(" in t:
        return False
    n = len(t)

    def _scan(text: str, limit: int | None) -> bool:
        start = 0
        while True:
            idx = text.find(t, start)
            if idx < 0:
                return False
            if limit is not None and idx >= limit:
                return False
            if _bare_noun_left_clean_cn(text, idx) and _bare_noun_right_clean_cn(
                text, idx + n
            ):
                return True
            start = idx + 1

    if _scan(claim_text or "", ref_offset):
        return True
    for ancestor in chain[1:]:
        if _scan(getattr(ancestor, "text", "") or "", None):
            return True
    return False


def check_antecedent_basis_cn(
    doc: CnPatentDocument,
    *,
    strict_plural_reference_matching: bool = False,
    strict_qualifier_matching: bool = False,
) -> list[dict]:
    """CN antecedent-basis BFS walker (Phase 8c Stage 2).

    Mirrors the TW walker's resolution algorithm (tw_claims.py
    ``check_antecedent_basis``) with the Q1/Q3 divergences:

      * Q1: references using the TC-contamination prefixes 该等 / 该些
        are rejected with a ``category: "tw_contamination"`` finding
        and bypass normal resolution.
      * Q3: dedup key is the tuple
        ``(normalized_term, normalized_reference_form)`` from day 1
        (ADR-107). TW uses single-key dedup pending Phase 9 parity.

    Returns a list of dicts, 6-field ``{claim_id, term, reference_form,
    claim_text, suggested_match, cross_ref}`` for normal findings; the
    ``category`` key is added only on the Q1 path.
    """
    claims = doc.claims
    if not claims:
        return []

    issues: list[dict] = []

    for claim in claims:
        chain = get_ancestor_chain_cn(claim, claims)

        # R64 (2026-05-05) TW parity: suppress walker emit when chain
        # doesn't terminate at an independent claim (broken chain via
        # self-loop / cycle / dangling parent ref upstream). The
        # structural defect surfaces separately via selfDependent /
        # circularDependency checks; cascading antecedent findings are
        # confusing UX.
        if chain and chain[-1].dependencies:
            continue

        intros_by_term: dict[str, tuple[int, int]] = {}
        for depth, ancestor in enumerate(chain):
            for _, normalized in extract_introductions_cn(
                ancestor,
                strict_qualifier_matching=strict_qualifier_matching,
            ):
                intros_by_term.setdefault(normalized, (ancestor.id, depth))

        # R32 (2026-05-04): Path A equivalent for CN — chain-level
        # ordinal-prefix bridging. Mirror of TW R32. Two guards:
        #   1. Multi-modifier ambiguity (no other 第N+suffix in chain).
        #   2. Prefix-conflict (suffix not followed by 1-3 CJK in claim
        #      text outside the ordinal-prefixed source intro itself).
        _R32_ORDINAL_RE_CN = re.compile(r'^第[一二三四五六七八九十百0-9]+')
        suffix_count_chain_cn: dict[str, int] = {}
        suffix_anchor_chain_cn: dict[str, tuple[int, int]] = {}
        for norm, (ancestor_id, depth) in intros_by_term.items():
            mo = _R32_ORDINAL_RE_CN.match(norm)
            if not mo:
                continue
            suffix = norm[mo.end():]
            if len(suffix) < 2:
                continue
            suffix_count_chain_cn[suffix] = suffix_count_chain_cn.get(suffix, 0) + 1
            existing = suffix_anchor_chain_cn.get(suffix)
            if existing is None or depth < existing[1]:
                suffix_anchor_chain_cn[suffix] = (ancestor_id, depth)
        for suffix, count in suffix_count_chain_cn.items():
            if count > 1:
                continue
            if suffix in intros_by_term:
                continue
            conflict_re = re.compile(re.escape(suffix) + r'[一-鿿]{1,3}')
            has_conflict = False
            for ancestor in chain:
                full_re = re.compile(r'第[一二三四五六七八九十百0-9]+' + re.escape(suffix))
                consumed = full_re.sub('', ancestor.text)
                if conflict_re.search(consumed):
                    has_conflict = True
                    break
            if has_conflict:
                continue
            intros_by_term[suffix] = suffix_anchor_chain_cn[suffix]

        # R52-CN (2026-05-05): head-noun-suffix bridging for compound nouns.
        # CN parity of TW R52 (commit 930ad0c). When a chain intro is
        # `<modifier><HEAD>` where HEAD is a known compound head-noun
        # suffix (Simplified script), register `<HEAD>` separately so dep
        # claims using the bare head can resolve.
        #
        # Phase 1 supplement_v2 cluster `TAIL|CN|导体层` (31 wfp / 0 legit)
        # and similar patterns. CN drafters of chemistry/materials claims
        # use Pattern A on full compound (e.g. `半导体导体层`) but back-
        # reference using just the head (`所述导体层`).
        #
        # Architectural mirror of R32 ordinal bridge + R52 TW:
        #   1. Multi-modifier ambiguity guard
        #   2. Conflict guard (HEAD already an intro)
        #   3. Suffix allowlist — Simplified-script equivalents of TW R52
        _R52_HEAD_SUFFIXES_CN = (
            # Pharma/chemistry (R52-CN original)
            "组合物", "化合物", "溶液", "溶剂", "配方",
            "混合物", "复合物", "产物", "药剂", "抗体",
            "导体层", "聚合物",
            # R56-CN (2026-05-05): electronic/circuit head nouns
            # (Simplified parity of R56 TW). Phase 1 supplement_v2.
            "电路系统", "晶体管", "区块链", "管理功能",
            "参考电压", "定位辅助", "操作单元",
            "指令集", "传送信息",
        )
        head_count_cn: dict[str, int] = {}
        head_anchor_cn: dict[str, tuple[int, int]] = {}
        for norm, (ancestor_id, depth) in intros_by_term.items():
            for suffix in _R52_HEAD_SUFFIXES_CN:
                if (
                    norm.endswith(suffix)
                    and len(norm) > len(suffix)
                ):
                    head_count_cn[suffix] = head_count_cn.get(suffix, 0) + 1
                    existing = head_anchor_cn.get(suffix)
                    if existing is None or depth < existing[1]:
                        head_anchor_cn[suffix] = (ancestor_id, depth)
                    break
        for suffix, count in head_count_cn.items():
            if count > 1:
                continue
            if suffix in intros_by_term:
                continue
            intros_by_term[suffix] = head_anchor_cn[suffix]


        # Q1 tw_contamination rejection pre-pass. The TC-plural prefixes
        # 该等 / 该些 are not valid in CN drafting (CNIPA审查指南 uses 所述).
        # Their detection regex is local to this function so the only
        # module occurrence of these literals is this rejection apparatus.
        _tw_contamination_re = re.compile(
            r"(?P<prefix>该等|该些)" + f"(?P<noun>{_NOUN_CHARS_CN})"
        )
        for m in _tw_contamination_re.finditer(claim.text):
            prefix = m.group("prefix")
            raw_noun = m.group("noun")
            if not raw_noun:
                continue
            # Run the captured tail through the same cleanup pipeline as
            # the normal path (strip_reference_form_prefix →
            # strip_leading_qualifier → clean_noun_phrase →
            # strip_leading_quantifier), skipping resolution. The Q1
            # regex already split prefix (该等/该些) from noun, so we
            # normalize raw_noun directly.
            normalized_term = normalize_reference_term_cn(
                raw_noun,
                strict_qualifier_matching=strict_qualifier_matching,
            )
            finding: dict = {
                "claim_id": claim.id,
                "term": normalized_term or raw_noun,
                "reference_form": prefix,
                "claim_text": claim.text,
                "suggested_match": None,
                "cross_ref": None,
                "category": "tw_contamination",
                "document_dedup_key": make_document_dedup_key(
                    normalized_term or raw_noun, prefix
                ),
                # Q1 path is a rule-based detection of TC-plural prefixes
                # (该等/该些) on a CN doc. Not pattern-based — the prefix
                # alone is the violation under CNIPA审查指南 guidance to
                # use 所述. Very rarely a false positive in practice;
                # ship a fixed high confidence so the tier-display knob
                # treats these as high-confidence by default.
                "confidence_score": 90,
            }
            if not normalized_term:
                finding["note"] = "cleanup_empty"
            issues.append(finding)

        # Q3 tuple dedup (ADR-107): the key is the pair
        # (normalized_term, normalized_reference_form). See the
        # module-header ADR-107 comment for the parity rationale.
        seen_terms: set[tuple[str, str]] = set()
        for m in _REF_PATTERN_CAPTURE_CN.finditer(claim.text):
            prefix = m.group("prefix")
            raw_noun = m.group("noun")
            if not raw_noun:
                continue

            # R62 (2026-05-05) paren-numeral closure (parallel of TW fix).
            # When the regex {2,12} length cap truncates inside an open
            # paren-numeral, look ahead for the closing paren and extend.
            raw_noun_end = m.end()
            if _PAREN_NUM_TRAIL_RE_CN.search(raw_noun):
                if (
                    raw_noun_end < len(claim.text)
                    and claim.text[raw_noun_end] in (")", "）")
                ):
                    raw_noun = raw_noun + claim.text[raw_noun_end]
                    raw_noun_end += 1

            # R68d (2026-05-06) TW parity: mid-能 noun extension.
            raw_noun, raw_noun_end = _extend_neng_compound_cn(
                raw_noun, raw_noun_end, claim.text
            )

            # R66 (revised 2026-05-05): TW parity — state-modifier capture
            # extension. When raw_noun ends in 状/形 and `的<head>` follows,
            # extend capture so the displayed reference_form is the full
            # `所述<state>的<head>` phrase rather than the bare adjective.
            # See tw_claims.py R66 comment for the full rationale.
            if (
                raw_noun.endswith(_STATE_MODIFIER_SUFFIXES_CN)
                and not raw_noun.startswith("第")
                and raw_noun_end < len(claim.text)
            ):
                m_de = _DE_HEAD_NOUN_RE_CN.match(claim.text, raw_noun_end)
                if m_de:
                    head_raw = m_de.group("head")
                    raw_noun = raw_noun + "的" + head_raw
                    raw_noun_end = raw_noun_end + 1 + len(head_raw)

            full_ref = f"{prefix}{raw_noun}"
            normalized_term = normalize_reference_term_cn(
                full_ref,
                strict_qualifier_matching=strict_qualifier_matching,
            )
            if not normalized_term:
                continue

            normalized_reference_form = f"{prefix}{normalized_term}"
            dedup_key = (normalized_term, normalized_reference_form)
            if dedup_key in seen_terms:
                continue
            seen_terms.add(dedup_key)

            # R64 (2026-05-05) TW parity: dedup uses CJK-normalized
            # reference_form (matching parity); displayed reference_form
            # restores drafter's original Arabic ordinals.
            display_term = _restore_original_ordinals_cn(normalized_term, raw_noun)
            reference_form = f"{prefix}{display_term}"

            resolved_intro: str | None = None
            if normalized_term in intros_by_term:
                resolved_intro = normalized_term
            elif not re.search(r"\([^)]+\)$", normalized_term):
                for intro in intros_by_term:
                    stripped_intro = re.sub(r"\([^)]+\)$", "", intro)
                    if stripped_intro != intro and stripped_intro == normalized_term:
                        resolved_intro = intro
                        break
            if resolved_intro is None:
                best_len = 0
                for intro in intros_by_term:
                    if (
                        len(intro) >= 2
                        and len(intro) > best_len
                        and normalized_term.startswith(intro)
                    ):
                        best_len = len(intro)
                        resolved_intro = intro

            # R46 (2026-05-04): mirror of TW R46 — ordinal-prefix-to-
            # Latin-abbrev bridge. Reference `第N<X>` where X is short
            # uppercase Latin abbrev (2-5 chars) and `<X>` is registered
            # as an intro -> bridge. Common in CN 5G/wireless drafts.
            if resolved_intro is None:
                m_ord = re.match(r'^第[一二三四五六七八九十百0-9]+', normalized_term)
                if m_ord:
                    bare = normalized_term[m_ord.end():]
                    if (
                        bare and 2 <= len(bare) <= 5
                        and bare.isupper() and bare.isascii()
                        and bare in intros_by_term
                    ):
                        resolved_intro = bare

            # R29 (2026-05-03) — Resolution-side architectural mechanisms
            # (forward-prefix with boundary, symmetric clean, cross-branch
            # sibling, substring) all silenced protect:true legit_drafting
            # _error labels (parallel-invention drafter errors on
            # CN115485995B / CN113939805B / CN110276410B). §112(b) is
            # strict: references must resolve to SAME-CHAIN antecedents,
            # not sibling-claim intros or substring matches. Round 29
            # restricted to the capture-side fix (F11 ;-segment continuation
            # in _extract_supplementary_intros_cn) plus conservative trim-
            # verb extensions, both of which respect the chain invariant.

            # R35 (2026-05-23): bare-noun-introduction rescue (CN mirror of
            # TW R7). A multi-character noun first mentioned article-less
            # (verb / coverb object, clause item) has antecedent basis by
            # implication (审查指南 第二部分 第二章 §3.2 清楚 / 明确).
            # The intro extractors miss article-less data / attribute
            # nouns; this closes the gap. See has_bare_noun_introduction_cn.
            if resolved_intro is None and has_possessive_introduction_cn(
                claim.text, chain, normalized_term, m.start()
            ):
                continue

            if resolved_intro is None and has_bare_noun_introduction_cn(
                claim.text, chain, normalized_term, m.start()
            ):
                continue

            if resolved_intro is not None:
                if not strict_plural_reference_matching:
                    continue
                if not detect_plural_reference_cn(full_ref):
                    continue
                ancestor_id, _ = intros_by_term[resolved_intro]
                ancestor_claim = next(
                    (c for c in chain if c.id == ancestor_id), None
                )
                intro_was_plural = False
                if ancestor_claim is not None:
                    for original, normalized in extract_introductions_cn(
                        ancestor_claim,
                        strict_qualifier_matching=strict_qualifier_matching,
                    ):
                        if normalized != resolved_intro:
                            continue
                        if full_ref_starts_with_plural_cn(original):
                            intro_was_plural = True
                            break
                if intro_was_plural:
                    continue

            suggested_match: dict | None = None
            if resolved_intro is None:
                ref_tokens = tokenize_cn(normalized_term)
                best_score = 0.0
                best_depth: int | None = None
                for intro_term, (ancestor_id, depth) in intros_by_term.items():
                    if ordinal_guard(normalized_term, intro_term):
                        continue
                    score = jaccard(ref_tokens, tokenize_cn(intro_term))
                    if score < _DIDYOUMEAN_THRESHOLD_CN:
                        continue
                    if (
                        score > best_score
                        or (
                            score == best_score
                            and (best_depth is None or depth < best_depth)
                        )
                    ):
                        best_score = score
                        best_depth = depth
                        suggested_match = {
                            "term": intro_term,
                            "claim_id": ancestor_id,
                        }

            if (
                suggested_match is not None
                and suggested_match["term"] == normalized_term
            ):
                suggested_match = None

            # Phase 8c R21 — DYM quality gate
            if (
                suggested_match is not None
                and _dym_quality_reject_cn(
                    normalized_term, suggested_match["term"]
                )
            ):
                suggested_match = None

            if _is_bare_genus_self_reference_cn(normalized_term, claim.text):
                continue

            if "权利要求" in normalized_term:
                continue

            # R32 (2026-05-04): TW parity — citation boilerplate filter
            # (任一项 stranded after `权利要求` substring removal would
            # otherwise pass — but multi-dep refs like `任一项所述的X`
            # produce term=`任一项` directly when the dep regex misses).
            if "任一项" in normalized_term or "申请专利范围" in normalized_term:
                continue

            if len(normalized_term) == 1:
                continue

            # R32 (2026-05-04): TW parity — newline/colon filter. F-anchor
            # captures crossing paragraph or label boundaries leak garbage
            # into spec-support too via shared extract_introductions_cn.
            if '\n' in normalized_term or '：' in normalized_term or ':' in normalized_term:
                continue

            if _FORMULA_ORDINAL_RE_CN.match(normalized_term):
                continue

            if _BARE_ORDINAL_RE_CN.match(normalized_term):
                continue

            # Phase 8c R22 — chemistry formula reference + verb-predicate suppression
            if _FORMULA_REFERENCE_RE_CN.match(normalized_term):
                continue

            if normalized_term in _VERB_PREDICATE_TERMS_CN:
                continue

            # R62 (2026-05-05): bare-quantifier emit suppression (CN parity
            # with TW). Drafters universally use 多个/复数/数个/至少 as
            # quantifier prefixes (多个X, 复数X), NEVER as standalone nouns.
            # Walker capture without proper leading-quantifier strip leaves
            # the bare quantifier as the term. Mirror of TW
            # _BARE_QUANTIFIER_TERMS_TW filter. Surfaced via supplement_v2
            # hand-verification — `多个` flagged on CN121219509A c10.
            if normalized_term in {
                "多个", "复数", "数个", "至少", "若干", "一些",
                "多个个", "复数个",
            }:
                continue
            # R62: short residual structural fragments — single CJK char
            # or 1-char Latin terms that escape the prefix-strip cascade.
            if len(normalized_term) < 2:
                continue

            # Structural fingerprint (ADR-145) — mirror of TW walker.
            # No claim content; counts + booleans only.
            diagnostics = {
                "prefix_charlen": len(prefix),
                "term_charlen": len(normalized_term),
                "intros_pool_size": len(intros_by_term),
                "has_suggested_match": suggested_match is not None,
                "suggested_cross_branch": bool(
                    suggested_match and suggested_match.get("cross_branch")
                ) if suggested_match else False,
            }
            confidence_score = compute_confidence_score(
                term=normalized_term,
                prefix=prefix,
                intros_pool_size=len(intros_by_term),
                has_suggested_match=suggested_match is not None,
                suggested_cross_branch=bool(
                    suggested_match and suggested_match.get("cross_branch")
                ),
                suggested_jaccard=best_score if suggested_match else None,
                suggested_same_claim=bool(
                    suggested_match
                    and suggested_match.get("claim_id") == claim.id
                ),
                reference_form=reference_form,
                jurisdiction="CN",
            )
            # Parent-claim diagnostic enrichment (US/TW parity, 2026-06-09):
            # does the flagged term appear verbatim in an ancestor claim?
            # If so the introduction exists but in a shape the intro
            # extractor missed (walker FP); if not, a genuine §112 gap.
            # `ancestor_match_text` stays in-process — the extractor windows
            # it. Brings CN to parity with the US/TW antecedent walkers so
            # CN child-claim reports (#222/#223/#226) self-classify from the
            # payload via `term_in_ancestor_text`.
            anc_match_id, anc_match_text = first_ancestor_with_term(
                chain, normalized_term
            )
            issues.append(
                {
                    "claim_id": claim.id,
                    "term": normalized_term,
                    "reference_form": reference_form,
                    "claim_text": claim.text,
                    "suggested_match": suggested_match,
                    "cross_ref": None,
                    "diagnostics": diagnostics,
                    "document_dedup_key": make_document_dedup_key(
                        normalized_term, reference_form
                    ),
                    "confidence_score": confidence_score,
                    "ancestor_claim_ids": [c.id for c in chain[1:]],
                    "ancestor_match_claim_id": anc_match_id,
                    "ancestor_match_text": anc_match_text,
                }
            )

    issues.sort(key=lambda x: (x["claim_id"], x["term"], x["reference_form"]))
    return issues
