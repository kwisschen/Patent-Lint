# SPDX-License-Identifier: LicenseRef-PolyForm-Strict-1.0.0
# Copyright (c) 2025-2026 Christopher Chen
"""CN claims analysis checks.

Twelve pure functions checking Chinese patent claim formatting
against CNIPA rules (专利法实施细则 and 审查指南).
"""

from __future__ import annotations

import re
import unicodedata
from typing import Any

from patentlint.analysis.cjk_ordinal_guard import (
    normalize_arabic_ordinal_to_cjk,
    ordinal_guard,
)
from patentlint.analysis.cjk_tokenize import jaccard, tokenize_cn
from patentlint.analysis.utils import (
    _dx,
    compute_confidence_score,
    first_ancestor_with_term,
    make_document_dedup_key,
)
from patentlint.analysis.connection_relationships import (
    _CN_CONNECTION_CONFIG,
    check_connection_relationships,
)
from patentlint.models import CheckItem, Claim, CnPatentDocument

# ADR-107 (Phase 8c Stage 2): CN antecedent walker adopts tuple dedup
# (normalized_term, normalized_reference_form) from day 1. TW uses single-key
# dedup pending Phase 9 parity migration. See CLAUDE.md Phase 8c locked
# decision Q3 and Phase 9 follow-up #2.

# Did-you-mean Jaccard threshold (ADR-094). Char-bigram Jaccard at 0.40
# is the calibration v2 sweet spot from the TW walker; inherited for CN.
_DIDYOUMEAN_THRESHOLD_CN = 0.40


def _dedupe_claim_ids(ids: list[int]) -> list[int]:
    """Drop duplicate claim IDs while preserving first-seen order.

    A malformed draft can print two distinct claim bodies under the same
    printed number (e.g., two "44."s in CN115952274B). The parser keeps
    both so ``check_claims_sequential`` can flag the duplication, but
    downstream emit sites should surface each claim ID at most once so
    the report does not render "claims: 44, 44".
    """
    return list(dict.fromkeys(ids))

# ── Check 9 ──────────────────────────────────────────────────────────────


def check_claims_sequential(cn_doc: CnPatentDocument) -> list[CheckItem]:
    """Verify claim IDs are 1, 2, 3, ... N with no gaps."""
    claims = cn_doc.claims
    if not claims:
        return [CheckItem(
            status="pass",
            message="No claims to check.",
            message_key="check.cn.claims.sequential.pass",
            reference="审查指南",
        )]

    for i, claim in enumerate(claims):
        expected = i + 1
        if claim.id != expected:
            return [CheckItem(
                status="amend",
                message=f"Claim numbering is not sequential: expected {expected}, found {claim.id}.",
                message_key="check.cn.claims.sequential.amend",
                details_key="details.cn.claimsSequential",
                details_params={"expected": expected, "found": claim.id},
                reference="审查指南",
                diagnostics=_dx(
                    expected_id=expected,
                    found_id=claim.id,
                    total_claims=len(claims),
                    gap_position=i,
                    is_backward=claim.id < expected,
                    preamble=(claim.text or "")[:80],
                ),
            )]

    return [CheckItem(
        status="pass",
        message="Claim numbers are sequential.",
        message_key="check.cn.claims.sequential.pass",
        reference="审查指南",
    )]


# ── Check 10 ─────────────────────────────────────────────────────────────

# CN dependent-claim preamble connective.
# CNIPA-standard is 所述 (per 专利法实施细则 §25 + CNIPA drafting examples).
# JP-translation variants 所记载/所揭示/所描述 surface in CN patents translated
# from Japanese originals; parse them tolerantly rather than flag them.
# The trailing 的 is optional - CN drafters sometimes write 所述X (without 的)
# when X starts with a measure word or complex noun phrase.
_CN_DEP_CONNECTIVE = r"所(?:述|记载|揭示|描述)的?"

# The introducing verb is NOT constrained: CNIPA drafting commonly uses
# 根据/如/按照/依照/依/依据/基于 + 权利要求N + 所述的, or even the bare
# 权利要求N所述的 form. 审查指南 第二部分第二章 §3.3.1 uses 根据 in its
# canonical example; 如 is equally valid. Requiring a specific verb
# false-positives on nearly all real CN drafts. The actually-enforced
# structure is: 权利要求 + digit + ... + 所述.
_DEP_FORMAT_SINGLE = re.compile(r"权利要求\s*\d+[\s\S]*?" + _CN_DEP_CONNECTIVE)

# Multi-dep alternative-reference forms (per 专利法实施细则 §25 第3款 -
# multi-dep claims must use 择一方式 / alternative reference):
#   (a) `权利要求1或2所述的` - 或 alternative
#   (b) `权利要求1、2或3所述的` - 、 + 或 alternative
#   (c) `权利要求1至3中任一项所述的` - range + 中任一项
#   (d) `权利要求1至3任一项所述的` - range + 任一项 (no 中)
#   (e) `权利要求10至12中任意一项所述的` - range + 中任意一项
#   (f) `权利要求1-3任一项所述的` / `1~3` / `1‑5` (U+2010-U+2015 dashes)
# At least one alternative-reference marker (range-form OR or-form) is required.
_CN_RANGE_SEPARATOR = r"(?:~|至|到|[‐-―\-])"
_CN_ANY_ITEM_QUANTIFIER = r"任\s*(?:意\s*)?(?:一|何)?\s*项"
_DEP_FORMAT_MULTI = re.compile(
    r"权利要求\s*\d+"
    r"(?:"
    #   Range form: `N至M[中[的]任[意][一|何]项]`
    r"\s*" + _CN_RANGE_SEPARATOR + r"\s*(?:权利要求\s*)?\d+"
    r"(?:\s*(?:中(?:\s*的)?\s*)?" + _CN_ANY_ITEM_QUANTIFIER + r")?"
    r"|"
    #   Or/comma form: `或 N`, `、N`, possibly repeated
    r"(?:\s*(?:或|、)\s*(?:权利要求\s*)?\d+)+"
    r"(?:\s*(?:中(?:\s*的)?\s*)?" + _CN_ANY_ITEM_QUANTIFIER + r")?"
    r")"
    r"[\s\S]*?" + _CN_DEP_CONNECTIVE
)


def check_dependency_format(cn_doc: CnPatentDocument) -> list[CheckItem]:
    """Check dependent claims use the 如权利要求N所述的 format."""
    dependents = [c for c in cn_doc.claims if not c.independent]
    if not dependents:
        return [CheckItem(
            status="pass",
            message="No dependent claims to check.",
            message_key="check.cn.claims.dependencyFormat.pass",
            reference="专利法实施细则 §25",
        )]

    bad_claim_ids: list[int] = []
    for claim in dependents:
        if claim.multiple_dependent:
            if not _DEP_FORMAT_MULTI.search(claim.text):
                bad_claim_ids.append(claim.id)
        else:
            if not _DEP_FORMAT_SINGLE.search(claim.text):
                bad_claim_ids.append(claim.id)

    if bad_claim_ids:
        bad_claim_ids = _dedupe_claim_ids(bad_claim_ids)
        claims_str = ", ".join(str(i) for i in bad_claim_ids)
        return [CheckItem(
            status="amend",
            message=f"{len(bad_claim_ids)} dependent claim(s) lack proper dependency format (claims: {claims_str}).",
            message_key="check.cn.claims.dependencyFormat.amend",
            details=f"{len(bad_claim_ids)} claims",
            details_key="details.cn.dependencyFormat",
            details_params={"count": len(bad_claim_ids), "claims": bad_claim_ids},
            reference="专利法实施细则 §25",
            diagnostics=_dx(
                flagged_count=len(bad_claim_ids),
                total_dependents=len(dependents),
                total_claims=len(cn_doc.claims),
                flagged_claim_id=bad_claim_ids[0] if bad_claim_ids else None,
                findings=[
                    {"claim_id": cid, "preamble": (next((c.text for c in cn_doc.claims if c.id == cid), "") or "")[:80]}
                    for cid in bad_claim_ids[:5]
                ],
            ),
        )]

    return [CheckItem(
        status="pass",
        message="All dependent claims use proper dependency format.",
        message_key="check.cn.claims.dependencyFormat.pass",
        reference="专利法实施细则 §25",
    )]


# ── Indefinite / exemplary wording (审查指南 第二部分第二章 §3.2.2 清楚) ──

# CONSERVATIVE list (2026-06-25, corpus-frequency-audited). Mirror of the US
# § 2173.05(b)/(d) check at CJK-appropriate precision. Only the LOW-frequency,
# high-confidence exemplary (例如/诸如) + preferential (较佳/优选) terms are
# flagged. 等 and 约 are DELIBERATELY EXCLUDED - the real-corpus probe showed
# 等 in 16% of CN drafts (often legitimate: 等于/同等/等级/等等) and 约 in 12%
# (measurement tolerances, definite when the spec supplies a standard), so
# flagging them would be noise, not coverage. REVIEW tier - definiteness is
# examiner-judgment-in-context, so the matched word is a flag, not a verdict.
_INDEFINITE_WORDING_CN_RE = re.compile(r"例如|诸如|较佳|优选")


def check_indefinite_wording_cn(cn_doc: CnPatentDocument) -> list[CheckItem]:
    """Flag exemplary / preferential wording in claims (审查指南 §3.2.2 清楚)."""
    flagged: list[int] = []
    phrases: list[dict] = []
    for c in cn_doc.claims:
        found = sorted({m.group(0) for m in _INDEFINITE_WORDING_CN_RE.finditer(c.text)})
        if found:
            flagged.append(c.id)
            phrases.extend({"location": c.id, "token": tok, "kind": "term"} for tok in found)
    if not flagged:
        return [CheckItem(
            status="pass",
            message="未检测到不确定或例示性用语。",
            message_key="check.cn.claims.indefiniteWording.pass",
            reference="审查指南 第二部分第二章 §3.2.2",
        )]
    return [CheckItem(
        status="verify",
        message="检测到不确定或例示性用语，建议核实权利要求是否清楚。",
        message_key="check.cn.claims.indefiniteWording.verify",
        details_key="details.cn.indefiniteWordingClaims",
        details_params={
            "list": str(flagged),
            "claims": ", ".join(str(i) for i in flagged),
            "flagged_phrases": {"items": phrases},
        },
        reference="审查指南 第二部分第二章 §3.2.2",
        diagnostics=_dx(
            flagged_claim_count=len(flagged),
            flagged_phrase_count=len(phrases),
            flagged_claims_sample=flagged[:5],
            flagged_phrases_sample=[
                {"location": p["location"], "token": p["token"], "kind": p["kind"]}
                for p in phrases[:5]
            ],
        ),
    )]


# ── Check 11 ─────────────────────────────────────────────────────────────


def check_excess_claims_count_cn(cn_doc: CnPatentDocument) -> list[CheckItem]:
    """Flag claims that exceed CNIPA fee-free threshold (10 claims).

    CNIPA 实施细则 §93 + 国家发改委 收费标准: the invention-patent
    application base fee includes the first 10 claims; additional
    per-claim fee applies for each claim above 10. Status verify when
    total exceeds 10; PASS otherwise. Threshold uses strict ``>``.

    Specific per-claim amount is intentionally NOT embedded in messages
    so the check stays future-proof against CNIPA fee schedule changes;
    drafters are asked to verify against the current schedule.
    """
    total = len(cn_doc.claims)
    if total <= 10:
        return [CheckItem(
            status="pass",
            message=f"未检测到 CNIPA 超项费触发条件（权利要求总数 {total} 项，实施细则 §93 免费阈值为 10 项以内）。",
            message_key="check.cn.claims.excessClaims.pass",
            reference="专利法实施细则 §93; CNIPA 收费办法",
            diagnostics=_dx(total_count=total),
        )]
    return [CheckItem(
        status="verify",
        message=(
            f"权利要求总数 {total} 项，超过 CNIPA 之 10 项免费阈值 -- "
            f"自第 11 项起每项加收超项费。请对照当前 CNIPA 收费办法核实规费。"
        ),
        message_key="check.cn.claims.excessClaims.verify",
        reference="专利法实施细则 §93; CNIPA 收费办法",
        diagnostics=_dx(total_count=total, excess_count=total - 10),
    )]


def check_self_dependent(cn_doc: CnPatentDocument) -> list[CheckItem]:
    """Check if any claim depends on itself."""
    bad = _dedupe_claim_ids([c.id for c in cn_doc.claims if c.id in c.dependencies])

    if bad:
        claims_str = ", ".join(str(i) for i in bad)
        return [CheckItem(
            status="amend",
            message=f"Self-dependent claims found: {claims_str}.",
            message_key="check.cn.claims.selfDependent.amend",
            details=claims_str,
            details_key="details.cn.selfDependent",
            details_params={"claims": bad},
            reference="专利法实施细则 §25",
            diagnostics=_dx(
                flagged_count=len(bad),
                total_claims=len(cn_doc.claims),
                flagged_claim_id=bad[0] if bad else None,
                findings=[
                    {"claim_id": cid, "preamble": (next((c.text for c in cn_doc.claims if c.id == cid), "") or "")[:80]}
                    for cid in bad[:5]
                ],
            ),
        )]

    return [CheckItem(
        status="pass",
        message="No self-dependent claims.",
        message_key="check.cn.claims.selfDependent.pass",
        details_key="details.cn.pass.selfDependent",
        reference="专利法实施细则 §25",
    )]


# Strip the ``N. `` / ``N．`` / ``N、`` claim-number prefix before checking
# preamble. Mirror of ``parser/claims_cn.py::_CN_CLAIM_NUM`` - keep the
# terminator class in sync.
_CN_CLAIM_NUM_PREFIX = re.compile(r"^[\s　]*\d+\s*[.．。、]\s*")


def check_independent_preamble(cn_doc: CnPatentDocument) -> list[CheckItem]:
    """Advisory: flag independent claims not opening with 「一种」.

    审查指南 第二部分第二章 §3.1.1 uses 一种X as the canonical preamble
    form in its examples, and CNIPA practitioner convention follows this.
    Note: 专利法实施细则 §24 (independent claim format) requires the
    preamble to state the 主题名称 (subject-matter name) but does NOT
    literally mandate 一种 - other preambles that still name the
    subject matter may satisfy the statute.
    Status is therefore VERIFY (advisory), not FIX.

    Dependent-claim opener set (根据/如/按照 etc.) is validated separately
    by ``check_dependency_format``.
    """
    bad: list[int] = []
    for claim in cn_doc.claims:
        if not claim.independent:
            continue
        body = _CN_CLAIM_NUM_PREFIX.sub("", claim.text).lstrip()
        if not body.startswith("一种"):
            bad.append(claim.id)

    if bad:
        bad_sorted = _dedupe_claim_ids(bad)
        claims_str = ", ".join(str(i) for i in bad_sorted)
        return [CheckItem(
            status="verify",
            message=f"Independent claim(s) not opening with 「一种」: {claims_str}.",
            message_key="check.cn.claims.independentPreamble.verify",
            details=claims_str,
            details_key="details.cn.independentPreamble",
            details_params={"count": len(bad_sorted), "claims": bad_sorted},
            reference="审查指南 第二部分第二章 §3.1.1 (canonical example form)",
            diagnostics=_dx(
                flagged_count=len(bad_sorted),
                total_claims=len(cn_doc.claims),
                flagged_claim_id=bad_sorted[0] if bad_sorted else None,
            ),
        )]
    return [CheckItem(
        status="pass",
        message="All independent claims open with 「一种」.",
        message_key="check.cn.claims.independentPreamble.pass",
        reference="审查指南 第二部分第二章 §3.1.1 (canonical example form)",
    )]


# ── Check 12 ─────────────────────────────────────────────────────────────


def check_forward_dependency(cn_doc: CnPatentDocument) -> list[CheckItem]:
    """Check if any claim depends on a higher-numbered claim."""
    bad = _dedupe_claim_ids(
        [c.id for c in cn_doc.claims if any(d > c.id for d in c.dependencies)]
    )

    if bad:
        return [CheckItem(
            status="amend",
            message=f"Forward-referencing claims found: {', '.join(str(i) for i in bad)}.",
            message_key="check.cn.claims.forwardDependency.amend",
            details=", ".join(str(i) for i in bad),
            details_key="details.cn.forwardDependency",
            details_params={"claims": bad},
            reference="专利法实施细则 §25",
            diagnostics=_dx(
                flagged_count=len(bad),
                total_claims=len(cn_doc.claims),
                flagged_claim_id=bad[0] if bad else None,
                findings=[
                    {"claim_id": cid, "preamble": (next((c.text for c in cn_doc.claims if c.id == cid), "") or "")[:80]}
                    for cid in bad[:5]
                ],
            ),
        )]

    return [CheckItem(
        status="pass",
        message="No forward-referencing dependencies.",
        message_key="check.cn.claims.forwardDependency.pass",
        details_key="details.cn.pass.forwardDependency",
        reference="专利法实施细则 §25",
    )]


# ── Check 13 ─────────────────────────────────────────────────────────────


def check_single_sentence(cn_doc: CnPatentDocument) -> list[CheckItem]:
    """Each claim must have exactly one 。 at the end."""
    bad_claim_ids: list[int] = []
    sample_last_cp: int | None = None
    for claim in cn_doc.claims:
        text = claim.text.strip()
        period_count = text.count("。")
        if period_count != 1 or not text.endswith("。"):
            bad_claim_ids.append(claim.id)
            if sample_last_cp is None and text:
                sample_last_cp = ord(text[-1])

    if bad_claim_ids:
        bad_claim_ids = _dedupe_claim_ids(bad_claim_ids)
        claims_str = ", ".join(str(i) for i in bad_claim_ids)
        return [CheckItem(
            status="amend",
            message=f"{len(bad_claim_ids)} claim(s) have invalid sentence structure (claims: {claims_str}).",
            message_key="check.cn.claims.singleSentence.amend",
            details=f"{len(bad_claim_ids)} claims",
            details_key="details.cn.singleSentence",
            details_params={"count": len(bad_claim_ids), "claims": bad_claim_ids},
            reference="审查指南 第二部分第二章",
            diagnostics=_dx(
                flagged_count=len(bad_claim_ids),
                total_claims=len(cn_doc.claims),
                sample_last_codepoint=sample_last_cp,
            ),
        )]

    return [CheckItem(
        status="pass",
        message="All claims are single sentences ending with 。.",
        message_key="check.cn.claims.singleSentence.pass",
        details_key="details.cn.pass.singleSentence",
        reference="审查指南 第二部分第二章",
    )]


# ── Check 14 ─────────────────────────────────────────────────────────────

# CJK char followed by optional space then 2-4 digits, not in parentheses.
# Exclude CJK unit tokens like 重量份, 重量百分比 etc. to avoid chemistry
# false positives (mirror of tw_claims._BARE_NUMERAL CJK unit exclusion).
_CJK_UNIT_TOKENS_CN = (
    # Concentration / ratio (longest first)
    r"重量百分比|重量份|重量比|质量百分比|"
    r"体积百分比|体积比|原子百分比|"
    r"摩尔百分比|摩尔比|摩尔|"
    # Length
    r"毫米|公釐|公分|公尺|公里|"
    r"微米|纳米|奈米|皮米|"
    r"英寸|英吋|英尺|英里|"
    # Mass
    r"毫克|公克|微克|奈克|皮克|纳克|"
    r"公斤|千克|公吨|盎司|磅|"
    # Volume
    r"毫升|公升|微升|奈升|皮升|纳升|"
    r"立方厘米|立方公分|立方米|"
    # Time
    r"毫秒|微秒|纳秒|皮秒|"
    r"分钟|小时|秒钟|"
    # Pressure
    r"千帕|百帕|兆帕|毫帕|微帕|"
    r"大气压|毫巴|"
    # Temperature
    r"摄氏|华氏|开尔文|"
    # Energy / power
    r"千焦|兆焦|毫焦|焦耳|"
    r"千卡|卡路里|"
    r"千瓦|兆瓦|毫瓦|微瓦|"
    r"电子伏特|"
    # Voltage / current
    r"毫伏|微伏|千伏|伏特|"
    r"毫安|微安|千安|安培|"
    # Concentration
    r"毫摩尔|微摩尔|摩尔|"
    r"百万分之|百分之|"
    # Frequency / data
    r"千赫|兆赫|吉赫|赫|"
    r"千比特|兆比特|比特|字节|"
    # Single-char
    r"克|升|份|个|颗|片|秒|天|日|月|年|度|帕|巴|瓦|"
    r"倍率|倍|"
    # Miller-index crystallography suffixes
    r"结晶面|晶面|平面|方向|面"
)
_BARE_NUMERAL = re.compile(
    r"(?<!\()(?<=[\u4e00-\u9fff])\s?\d{2,4}(?!\))"
    r"(?!\d)"  # R67 (2026-05-08): must match full digit run; without this
               # the regex backtracks from `100\u7eb3\u7c73` to `10` (0\u7eb3\u7c73
               # doesn't match the unit list), producing a FP. TW parity.
    r"(?!\s*(?:" + _CJK_UNIT_TOKENS_CN + r"))"
)

# Latin-prefix designators (R1, IC2, LED1) used for circuit / semiconductor
# element references. Same \u5b9e\u65bd\u7ec6\u5219 \u00a721 \u7b2c2\u6b3e / \u00a722 rule \u2014 \u7b26\u53f7 covers
# Latin-prefix too. CJK-anchored to skip standalone citations.
_BARE_LATIN_REF = re.compile(
    r"(?<!\()(?<=[\u4e00-\u9fff])"
    r"\s?[A-Z]{1,5}\d{1,4}[a-zA-Z]?"
    r"(?!\))(?![A-Za-z0-9])"
)


def _ref_numeral_finding_diag_cn(cid: int, claims: list) -> dict:
    """CN parallel of _ref_numeral_finding_diag_tw - adds context_after
    for self-diagnosing reports per R-refnum-1.
    """
    text = next((c.text for c in claims if c.id == cid), "") or ""
    m = _BARE_NUMERAL.search(text)
    if not m:
        m = _BARE_LATIN_REF.search(text)
    if not m:
        return {"claim_id": cid, "first_match": None, "context_after": None}
    return {
        "claim_id": cid,
        "first_match": m.group(0),
        "context_after": text[m.end():m.end() + 8],
    }


def check_reference_numeral_parentheses(cn_doc: CnPatentDocument) -> list[CheckItem]:
    """Find reference numerals in claims not enclosed in parentheses."""
    bad_claim_ids: list[int] = []
    for claim in cn_doc.claims:
        if _BARE_NUMERAL.search(claim.text) or _BARE_LATIN_REF.search(claim.text):
            bad_claim_ids.append(claim.id)

    if bad_claim_ids:
        bad_claim_ids = _dedupe_claim_ids(bad_claim_ids)
        claims_str = ", ".join(str(i) for i in bad_claim_ids)
        return [CheckItem(
            status="verify",
            message=f"{len(bad_claim_ids)} claim(s) have unparenthesized reference numerals (claims: {claims_str}).",
            message_key="check.cn.claims.refNumeralParens.verify",
            details=f"{len(bad_claim_ids)} claims",
            details_key="details.cn.refNumeralParens",
            details_params={"count": len(bad_claim_ids), "claims": bad_claim_ids},
            reference="审查指南",
            diagnostics=_dx(
                flagged_count=len(bad_claim_ids),
                total_claims=len(cn_doc.claims),
                flagged_claim_id=bad_claim_ids[0] if bad_claim_ids else None,
                # R-refnum-1 (2026-04-30): added context_after so future
                # reports of FPs like Miller-index `100面` arrive self-
                # diagnosing without needing the draft. Cross-port from TW.
                findings=[
                    _ref_numeral_finding_diag_cn(cid, cn_doc.claims)
                    for cid in bad_claim_ids[:5]
                ],
            ),
        )]

    return [CheckItem(
        status="pass",
        message="All reference numerals in claims are parenthesized.",
        message_key="check.cn.claims.refNumeralParens.pass",
        reference="审查指南",
    )]


# ── Check 15 ─────────────────────────────────────────────────────────────

# Extract subject matter: text after the last 所述的 (or 的) before 。
_SUBJECT_RE = re.compile(r"所述的(.+?)(?:[，,]|$)")
_LEADING_QUANTIFIER = re.compile(r"^(?:一种|一个|该|所述|所述的)\s*")

# Dependent-claim preamble anchored at start (CN mirror of TW fix): prevents
# body-text 所述的 inside independent claims from hijacking extraction.
# Trailing connective accepts 所(述|记载|揭示|描述)[的] + bare 的 (older form
# 权利要求N的X). JP-translated CN patents keep 所记载 even though CNIPA-standard
# is 所述 - parse the dep preamble tolerantly so subject extraction succeeds.
_DEP_PREAMBLE_CONNECTIVE_CN = r"(?:所(?:述|记载|揭示|描述)的?|的)?"
_DEP_PREFIX_RE_CN = re.compile(
    # TW #328 parity (subject-extractor must agree with the dep parser): add
    # 依据 to the opener set and make the opener OPTIONAL so the bare
    # `权利要求N所述的…` form routes to dep_prefix instead of a spurious
    # subjectConsistency parseUnclear. Advisory-tier check; the structural
    # 权利要求N + connective preamble is still required, so FN-safe. (The wider
    # 按照 / 依照 / 基于 openers stay unrecognized here - no CN report, and one
    # is an intentional parseUnclear test fixture; add on report per DR-1.)
    r"^(?:如|根据|依据|依)?权利要求\s*\d+"
    r"(?:\s*(?:~|至|到)\s*\d+)?"
    r"(?:\s*(?:或|、)\s*\d+)*"
    r"(?:\s*中\s*任一?项)?"
    r"\s*" + _DEP_PREAMBLE_CONNECTIVE_CN
)
_INDEP_PREFIX_RE_CN = re.compile(r"^(?:一种|一个)\s*")
# Subject-end boundary: any clause/sentence terminator stops extraction so
# realistic claim preambles (with trailing 。 or ；) yield a clean subject.
_SUBJECT_END_RE_CN = re.compile(r"(?:[，,；。]|其特征在于|其改良在于|其中)")


def _extract_subject_with_path(claim_text: str) -> tuple[str, str]:
    """Extract subject matter + provenance tag (CN mirror of TW helper).

    Returns (subject_text, extraction_path) where path is one of:
      - ``"dep_prefix"``    - matched `_DEP_PREFIX_RE_CN`
      - ``"indep_prefix"``  - matched `_INDEP_PREFIX_RE_CN`
      - ``"subject_re"``    - legacy body-scan `所述的` match path
      - ``"fallthrough"``   - no recognized preamble, returned raw text

    Subject-consistency callers use the path to split genuine mismatches
    from parse-limit fall-throughs (see ADR-145).
    """
    text = re.sub(r"^\s*\d+\s*[.．]\s*", "", claim_text).strip()
    dep_m = _DEP_PREFIX_RE_CN.match(text)
    if dep_m:
        remainder = text[dep_m.end():]
        end_m = _SUBJECT_END_RE_CN.search(remainder)
        return (
            (remainder[:end_m.start()] if end_m else remainder).strip(),
            "dep_prefix",
        )
    indep_m = _INDEP_PREFIX_RE_CN.match(text)
    if indep_m:
        body = text[indep_m.end():]
        end_m = _SUBJECT_END_RE_CN.search(body)
        return (
            (body[:end_m.start()] if end_m else body).strip(),
            "indep_prefix",
        )
    end_m = _SUBJECT_END_RE_CN.search(text)
    if end_m:
        return text[:end_m.start()].strip(), "fallthrough"
    # Legacy 所述的 body scan for claims that don't match preamble shapes
    match = _SUBJECT_RE.search(claim_text)
    if match:
        return match.group(1).strip(), "subject_re"
    return text.strip(), "fallthrough"


def _extract_subject(claim_text: str) -> str:
    """Back-compat wrapper - returns just the subject text."""
    subject, _path = _extract_subject_with_path(claim_text)
    return subject


def _normalize_subject(subject: str) -> str:
    """Strip leading quantifiers for comparison."""
    return _LEADING_QUANTIFIER.sub("", subject).strip()


def check_subject_name_consistency(cn_doc: CnPatentDocument) -> list[CheckItem]:
    """Check dependent claim subject matter matches parent claim subject matter.

    Extract both subjects with the same ``_extract_subject`` helper so a
    descriptive independent-claim preamble like
    ``一种基于深度学习模型的数据生成方法`` does not spuriously diverge from
    a dependent's short-form ``如权利要求1所述的数据生成方法``. Consistency
    allows equality, or either side being a suffix of the other, since
    CN drafters commonly drop qualifier phrases (``基于...的``) when
    re-referencing the parent subject matter.
    """
    claims_by_id = {c.id: c for c in cn_doc.claims}
    dependents = [c for c in cn_doc.claims if not c.independent]

    if not dependents:
        return [CheckItem(
            status="pass",
            message="No dependent claims to check.",
            message_key="check.cn.claims.subjectConsistency.pass",
            reference="审查指南 第二部分第二章",
        )]

    mismatch_ids: list[int] = []
    unclear_ids: list[int] = []
    mismatch_fp: dict[str, Any] | None = None
    unclear_fp: dict[str, Any] | None = None

    for claim in dependents:
        if not claim.dependencies:
            continue
        parent_id = claim.dependencies[0]
        parent = claims_by_id.get(parent_id)
        if not parent:
            continue

        dep_raw, dep_path = _extract_subject_with_path(claim.text)
        parent_raw, parent_path = _extract_subject_with_path(parent.text)
        dep_subject = _normalize_subject(dep_raw)
        parent_subject = _normalize_subject(parent_raw)

        # Parse-limit category - preamble didn't match a recognized shape.
        # ADR-145: emit parseUnclear instead of verify, so bug reports can
        # distinguish walker gaps from drafter-level mismatches.
        if dep_path == "fallthrough" or parent_path == "fallthrough":
            unclear_ids.append(claim.id)
            if unclear_fp is None:
                unclear_fp = {
                    "dep_path": dep_path,
                    "parent_path": parent_path,
                    "dep_subject_charlen": len(dep_subject),
                    "parent_subject_charlen": len(parent_subject),
                }
            continue

        if not dep_subject or not parent_subject:
            continue
        if dep_subject == parent_subject:
            continue
        if parent_subject.endswith(dep_subject) or dep_subject.endswith(parent_subject):
            continue
        mismatch_ids.append(claim.id)
        if mismatch_fp is None:
            mismatch_fp = {
                "dep_path": dep_path,
                "parent_path": parent_path,
                "dep_subject_charlen": len(dep_subject),
                "parent_subject_charlen": len(parent_subject),
            }

    results: list[CheckItem] = []
    if mismatch_ids:
        mismatch_ids = _dedupe_claim_ids(mismatch_ids)
        claims_str = ", ".join(str(i) for i in mismatch_ids)
        results.append(CheckItem(
            status="verify",
            message=f"{len(mismatch_ids)} dependent claim(s) have inconsistent subject matter (claims: {claims_str}).",
            message_key="check.cn.claims.subjectConsistency.verify",
            details=f"{len(mismatch_ids)} claims",
            details_key="details.cn.subjectConsistency",
            details_params={"count": len(mismatch_ids), "claims": mismatch_ids},
            reference="审查指南 第二部分第二章",
            diagnostics=mismatch_fp,
        ))
    if unclear_ids:
        unclear_ids = _dedupe_claim_ids(unclear_ids)
        claims_str = ", ".join(str(i) for i in unclear_ids)
        results.append(CheckItem(
            status="verify",
            message=f"{len(unclear_ids)} dependent claim(s) with an unrecognized preamble - couldn't verify subject consistency (claims: {claims_str}).",
            message_key="check.cn.claims.subjectConsistencyParseUnclear.verify",
            details=f"{len(unclear_ids)} claims",
            details_key="details.cn.subjectConsistencyParseUnclear",
            details_params={"count": len(unclear_ids), "claims": unclear_ids},
            reference="审查指南 第二部分第二章",
            diagnostics=unclear_fp,
        ))
    if results:
        return results

    return [CheckItem(
        status="pass",
        message="Dependent claim subject matter is consistent.",
        message_key="check.cn.claims.subjectConsistency.pass",
        reference="审查指南 第二部分第二章",
    )]


# ── Check 16 ─────────────────────────────────────────────────────────────

_TRANSITION_PHRASES = re.compile(r"其特征在于|其特征是|其改进在于")


def check_transition_phrase(cn_doc: CnPatentDocument) -> list[CheckItem]:
    """Check independent claims contain a characterizing transition."""
    independents = [c for c in cn_doc.claims if c.independent]
    if not independents:
        return [CheckItem(
            status="pass",
            message="No independent claims to check.",
            message_key="check.cn.claims.transitionPhrase.pass",
            reference="审查指南",
        )]

    bad_claim_ids: list[int] = []
    for claim in independents:
        if not _TRANSITION_PHRASES.search(claim.text):
            bad_claim_ids.append(claim.id)

    if bad_claim_ids:
        bad_claim_ids = _dedupe_claim_ids(bad_claim_ids)
        claims_str = ", ".join(str(i) for i in bad_claim_ids)
        return [CheckItem(
            status="verify",
            message=f"{len(bad_claim_ids)} independent claim(s) lack a transition phrase (claims: {claims_str}).",
            message_key="check.cn.claims.transitionPhrase.verify",
            details=f"{len(bad_claim_ids)} claims",
            details_key="details.cn.transitionPhrase",
            details_params={"count": len(bad_claim_ids), "claims": bad_claim_ids},
            reference="审查指南",
            diagnostics=_dx(
                flagged_count=len(bad_claim_ids),
                total_independent=len(independents),
                total_claims=len(cn_doc.claims),
                flagged_claim_id=bad_claim_ids[0] if bad_claim_ids else None,
                findings=[
                    {"claim_id": cid, "preamble": (next((c.text for c in cn_doc.claims if c.id == cid), "") or "")[:120]}
                    for cid in bad_claim_ids[:5]
                ],
            ),
        )]

    return [CheckItem(
        status="pass",
        message="All independent claims contain a transition phrase.",
        message_key="check.cn.claims.transitionPhrase.pass",
        details_key="details.cn.pass.transitionPhrase",
        reference="审查指南",
    )]


# ── Check 17 ─────────────────────────────────────────────────────────────

_TW_TERMS = re.compile(r"请求项|請求項")


def check_tw_terminology(cn_doc: CnPatentDocument) -> list[CheckItem]:
    """Scan claims for Taiwan-specific terminology."""
    hits: list[tuple[int, str]] = []
    seen: set[tuple[int, str]] = set()
    for claim in cn_doc.claims:
        for m in _TW_TERMS.finditer(claim.text):
            token = m.group(0)
            key = (claim.id, token)
            if key in seen:
                continue
            seen.add(key)
            hits.append((claim.id, token))

    if hits:
        return [CheckItem(
            status="amend",
            message="Taiwan-specific terminology found in claims.",
            message_key="check.cn.claims.twTerminology.amend",
            details_key="details.cn.twTerminology",
            details_params={
                "flagged_phrases": {
                    "items": [{"kind": "term", "token": token, "location": cid} for cid, token in hits]
                },
            },
            reference="",
            diagnostics=_dx(
                flagged_claim_id=hits[0][0],
                hit_count=len(hits),
                total_claims=len(cn_doc.claims),
                findings=[
                    {"claim_id": cid, "token": token}
                    for cid, token in hits[:5]
                ],
            ),
        )]

    return [CheckItem(
        status="pass",
        message="No Taiwan-specific terminology found.",
        message_key="check.cn.claims.twTerminology.pass",
        reference="",
    )]


# ── Check 18 ─────────────────────────────────────────────────────────────

_SPEC_REF = re.compile(r"如说明书|如图|参见说明书|参见图|参照说明书|参照附图")


def check_claims_spec_reference(cn_doc: CnPatentDocument) -> list[CheckItem]:
    """Check if claims reference the specification or drawings for scope."""
    bad_claim_ids: list[int] = []
    ref_hits: list[tuple[int, str]] = []
    seen: set[tuple[int, str]] = set()
    for claim in cn_doc.claims:
        for m in _SPEC_REF.finditer(claim.text):
            token = m.group(0)
            key = (claim.id, token)
            if key in seen:
                continue
            seen.add(key)
            ref_hits.append((claim.id, token))
            if claim.id not in bad_claim_ids:
                bad_claim_ids.append(claim.id)

    if bad_claim_ids:
        bad_claim_ids = _dedupe_claim_ids(bad_claim_ids)
        claims_str = ", ".join(str(i) for i in bad_claim_ids)
        return [CheckItem(
            status="amend",
            message=f"{len(bad_claim_ids)} claim(s) reference the specification or drawings (claims: {claims_str}).",
            message_key="check.cn.claims.specReference.amend",
            details=f"{len(bad_claim_ids)} claims",
            details_key="details.cn.claimsSpecReference",
            details_params={
                "count": len(bad_claim_ids),
                "claims": bad_claim_ids,
                "flagged_phrases": {
                    "items": [{"kind": "reference", "token": token, "location": cid} for cid, token in ref_hits]
                },
            },
            reference="审查指南 第二部分第二章",
            diagnostics=_dx(
                flagged_count=len(bad_claim_ids),
                total_claims=len(cn_doc.claims),
                hit_count=len(ref_hits),
            ),
        )]

    return [CheckItem(
        status="pass",
        message="No claims reference the specification or drawings.",
        message_key="check.cn.claims.specReference.pass",
        reference="审查指南 第二部分第二章",
    )]


# ── Check 19 ─────────────────────────────────────────────────────────────


def check_multi_multi_dependency(cn_doc: CnPatentDocument) -> list[CheckItem]:
    """Find claims that multiply-depend on another multiple-dependent claim."""
    multi_dep_ids = {c.id for c in cn_doc.claims if c.multiple_dependent}
    bad = []
    for claim in cn_doc.claims:
        if claim.multiple_dependent:
            if any(d in multi_dep_ids for d in claim.dependencies):
                bad.append(claim.id)

    if bad:
        bad = _dedupe_claim_ids(bad)
        claims_str = ", ".join(str(i) for i in bad)
        return [CheckItem(
            status="amend",
            message=f"Multiple-dependent claim(s) depend on other multiple-dependent claims: {claims_str}.",
            message_key="check.cn.claims.multiMultiDep.amend",
            details=claims_str,
            details_key="details.cn.multiMultiDep",
            details_params={"claims": bad},
            reference="专利法实施细则 §25",
            diagnostics=_dx(
                flagged_count=len(bad),
                total_multi_dep=len(multi_dep_ids),
                total_claims=len(cn_doc.claims),
                flagged_claim_id=bad[0] if bad else None,
                findings=[
                    {"claim_id": cid, "preamble": (next((c.text for c in cn_doc.claims if c.id == cid), "") or "")[:80]}
                    for cid in bad[:5]
                ],
            ),
        )]

    return [CheckItem(
        status="pass",
        message="No chained multiple dependencies.",
        message_key="check.cn.claims.multiMultiDep.pass",
        details_key="details.cn.pass.multiMultiDep",
        reference="专利法实施细则 §25",
    )]


# ── Check 20 ─────────────────────────────────────────────────────────────


def check_dependent_ordering(cn_doc: CnPatentDocument) -> list[CheckItem]:
    """Check dependents of each independent claim appear consecutively."""
    claims = cn_doc.claims
    if not claims:
        return [CheckItem(
            status="pass",
            message="No claims to check.",
            message_key="check.cn.claims.dependentOrdering.pass",
            reference="审查指南 第二部分第二章",
        )]

    # Build map: for each independent claim, find the last position of
    # any dependent that references it (directly or transitively via chain).
    # Then check no dependent of an earlier independent appears after a later
    # independent.

    # Find independent claim positions
    indep_positions = []
    for i, c in enumerate(claims):
        if c.independent:
            indep_positions.append(i)

    if len(indep_positions) < 2:
        return [CheckItem(
            status="pass",
            message="Dependent claim ordering is correct.",
            message_key="check.cn.claims.dependentOrdering.pass",
            reference="审查指南 第二部分第二章",
        )]

    # For each independent claim, find the "group boundary" - the position
    # of the next independent claim. Any dependent that references the
    # earlier independent but appears after the next independent is out of order.
    claims_by_id = {c.id: c for c in claims}

    def root_independent(claim_id: int, visited: set | None = None) -> int | None:
        """Trace dependency chain to find the root independent claim."""
        if visited is None:
            visited = set()
        if claim_id in visited:
            return None
        visited.add(claim_id)
        c = claims_by_id.get(claim_id)
        if not c:
            return None
        if c.independent:
            return c.id
        if c.dependencies:
            return root_independent(c.dependencies[0], visited)
        return None

    # Check: after each independent claim, all claims until the next
    # independent should depend (transitively) on the current or a
    # preceding independent claim, not on a later one.
    for idx in range(len(indep_positions) - 1):
        current_indep_pos = indep_positions[idx]
        next_indep_pos = indep_positions[idx + 1]

        # Check claims after next_indep_pos to see if any reference
        # the current independent
        current_indep_id = claims[current_indep_pos].id
        for j in range(next_indep_pos + 1, len(claims)):
            c = claims[j]
            if not c.independent:
                root = root_independent(c.id)
                if root == current_indep_id:
                    return [CheckItem(
                        status="amend",
                        message="Dependent claims are not grouped with their independent claim.",
                        message_key="check.cn.claims.dependentOrdering.amend",
                        details_key="details.cn.dependentOrdering",
                        reference="审查指南 第二部分第二章",
                        diagnostics=_dx(
                            total_claims=len(claims),
                            total_independent=len(indep_positions),
                            stranded_claim_id=c.id,
                            expected_after_independent_id=current_indep_id,
                            actual_position=j,
                            stranded_preamble=(c.text or "")[:80],
                        ),
                    )]

    return [CheckItem(
        status="pass",
        message="Dependent claim ordering is correct.",
        message_key="check.cn.claims.dependentOrdering.pass",
        reference="审查指南 第二部分第二章",
    )]


# ── Check 21 (连接关系) ──────────────────────────────────────────────────


def check_connection_relationships_cn(cn_doc: CnPatentDocument) -> list[CheckItem]:
    """Flag independent apparatus claims listing components without a
    connection verb (CNIPA 审查指南 §3.2.1 + 专利法 §26.4).

    Thin wrapper over the shared CN/TW helper. Method, CRM, MPF, and
    composition claims are carved out per ``_CN_CONNECTION_CONFIG``.
    """
    return check_connection_relationships(cn_doc.claims, _CN_CONNECTION_CONFIG)


# ── Check 22 (omnibus / 如说明书所述) ─────────────────────────────────────

# Mirrors US ``_OMNIBUS_LANG``; CN-practitioner phrasings that reference
# the description or drawings instead of reciting features. 审查指南
# 第二部分第二章 §3.3 - claims must recite technical features, not
# reference the specification.
_OMNIBUS_LANG_CN = re.compile(
    r"如说明书(?:及附图)?(?:所述|所描述|所记载)"
    r"|如说明书和附图(?:所述|所描述|所示|所描述的)"
    r"|如(?:附图|图)\s*\d*(?:所示|所述|所描述)"
    r"|基本上如说明书(?:所述|所描述)"
    r"|如(?:前述|前文)(?:所述|所描述)说明书"
)


def detect_omnibus_claims_cn(cn_doc: CnPatentDocument) -> list[int]:
    """Return IDs of CN claims that reference 说明书/附图 without reciting features.

    Mirrors :func:`patentlint.analysis.claims.check_special_claim_formats`
    omnibus branch, with CN practitioner patterns. Length threshold (<40
    CJK chars) guards against false positives on long detailed claims that
    incidentally mention 说明书.
    """
    out: list[int] = []
    for claim in cn_doc.claims:
        text = claim.text or ""
        cjk_count = sum(1 for ch in text if "一" <= ch <= "鿿")
        if cjk_count < 40 and _OMNIBUS_LANG_CN.search(text):
            out.append(claim.id)
    return out


def check_omnibus_claims(cn_doc: CnPatentDocument) -> list[CheckItem]:
    """Emit CheckItem for CN omnibus claims (FIX) - 审查指南 §3.3."""
    ids = detect_omnibus_claims_cn(cn_doc)
    if ids:
        claims_str = ", ".join(str(i) for i in ids)
        return [CheckItem(
            status="amend",
            message=f"Omnibus claim(s) reference the specification or drawings instead of reciting features: {claims_str}.",
            message_key="check.cn.claims.omnibus.amend",
            details=claims_str,
            details_key="details.cn.omnibusClaims",
            details_params={"claims": ids},
            reference="审查指南 第二部分第二章 §3.3",
            diagnostics=_dx(
                flagged_count=len(ids),
                total_claims=len(cn_doc.claims),
                flagged_claim_id=ids[0] if ids else None,
                findings=[
                    {"claim_id": cid, "preamble": (next((c.text for c in cn_doc.claims if c.id == cid), "") or "")[:80]}
                    for cid in ids[:5]
                ],
            ),
        )]
    return [CheckItem(
        status="pass",
        message="No omnibus claims found.",
        message_key="check.cn.claims.omnibus.pass",
        reference="审查指南 第二部分第二章 §3.3",
    )]


# ── Check 23 (Markush group open transition) ─────────────────────────────

# CNIPA 审查指南 第二部分第十章 §9.3 - a Markush claim must use the closed
# transition 组成的 (e.g. 选自由...所组成的群组 / 选自由X、Y、Z组成的群组).
# Open-ended variants (包括/具有/含有) are suspect.
_MARKUSH_OPEN_CN = re.compile(
    r"选自由[^，。；]{0,80}?(包括|具有|含有)"
)
_MARKUSH_CLOSED_CN = re.compile(r"选自由[^，。；]{0,80}?组成")


def detect_markush_open_transition_cn(cn_doc: CnPatentDocument) -> list[tuple[int, str]]:
    """Return (claim_id, open_transition) pairs for Markush claims using 包括/具有/含有."""
    out: list[tuple[int, str]] = []
    for claim in cn_doc.claims:
        text = claim.text or ""
        m = _MARKUSH_OPEN_CN.search(text)
        if m and not _MARKUSH_CLOSED_CN.search(text):
            out.append((claim.id, m.group(1)))
    return out


def check_markush_open_transition(cn_doc: CnPatentDocument) -> list[CheckItem]:
    """Emit CheckItem for CN Markush claims using open transition (FIX).

    Improper Markush is a substantive rejection per 审查指南 第二部分第十章
    §9.3 (Markush requires 选自由...组成的 closed group), not a formal
    correction - open transition triggers an examiner rejection on the
    merits.
    """
    pairs = detect_markush_open_transition_cn(cn_doc)
    if pairs:
        ids = [cid for cid, _ in pairs]
        transitions = sorted({t for _, t in pairs})
        claims_str = ", ".join(str(i) for i in ids)
        return [CheckItem(
            status="amend",
            message=f"Markush claim(s) use open-ended transition instead of 组成的: {claims_str}.",
            message_key="check.cn.claims.markushOpenTransition.amend",
            details=claims_str,
            details_key="details.cn.markushOpenTransition",
            details_params={"claims": ids, "transitions": transitions},
            reference="审查指南 第二部分第十章 §9.3",
            diagnostics=_dx(
                flagged_count=len(ids),
                total_claims=len(cn_doc.claims),
                flagged_claim_id=ids[0] if ids else None,
                transitions=transitions,
                findings=[
                    {
                        "claim_id": cid,
                        "open_transition": tw_word,
                        "preamble": (next((c.text for c in cn_doc.claims if c.id == cid), "") or "")[:120],
                    }
                    for cid, tw_word in pairs[:5]
                ],
            ),
        )]
    return [CheckItem(
        status="pass",
        message="Markush groups use closed transition 组成的.",
        message_key="check.cn.claims.markushOpenTransition.pass",
        reference="审查指南 第二部分第十章 §9.3",
    )]


# ── Check 24 (CRM non-transitory) ────────────────────────────────────────
#
# 专利法 §25 excludes mental activities / abstract methods; 审查指南
# 第二部分第九章 governs computer-implemented inventions. A claim to a
# 计算机可读介质 / 计算机可读存储介质 without the 非暂态 / 非暂时性
# qualifier may be read to cover transitory signals (carrier waves),
# which fall outside patentable subject matter. CN drafters commonly
# write 计算机可读介质 (介质 is CNIPA standard; 媒体 is rarer but
# accepted) - both forms covered. Independent claims only - dep
# claims inherit medium type from the parent.

_CRM_MEDIUM_CN = re.compile(
    r"(?:计算机|机器)\s*可读(?:存储)?(?:介质|媒体)"
    r"|存储介质"
    r"|记录介质"
)
_NON_TRANSITORY_CN = re.compile(r"非暂态|非暂时性|非临时性")


def check_crm_non_transitory_cn(cn_doc: CnPatentDocument) -> list[CheckItem]:
    """Flag CN computer-readable medium claims missing 非暂态/非暂时性.

    专利法 §25 (excluded subject matter) + 审查指南 第二部分第九章
    (computer-implemented inventions). A claim to a 计算机可读介质
    without 非暂态 may cover transitory signals which fall outside
    patentable subject matter.
    """
    bad = [
        c.id for c in cn_doc.claims
        if c.independent
        and _CRM_MEDIUM_CN.search(c.text or "")
        and not _NON_TRANSITORY_CN.search(c.text or "")
    ]
    if bad:
        claims_str = ", ".join(str(i) for i in bad)
        return [CheckItem(
            status="amend",
            message=f"Computer-readable medium claim(s) missing 非暂态/非暂时性: {claims_str}.",
            message_key="check.cn.claims.crmNonTransitory.amend",
            details=claims_str,
            details_key="details.cn.crmNonTransitory",
            details_params={"claims": bad},
            reference="专利法 §25; 审查指南 第二部分第九章",
            diagnostics=_dx(
                flagged_count=len(bad),
                total_claims=len(cn_doc.claims),
                flagged_claim_id=bad[0] if bad else None,
                findings=[
                    {"claim_id": cid, "preamble": (next((c.text for c in cn_doc.claims if c.id == cid), "") or "")[:80]}
                    for cid in bad[:5]
                ],
            ),
        )]
    return [CheckItem(
        status="pass",
        message="No CRM claims missing 非暂态.",
        message_key="check.cn.claims.crmNonTransitory.pass",
        reference="专利法 §25",
    )]


# ─────────────────────────────────────────────────────────────────────────
# Phase 8c Stage 2 - CN antecedent-basis BFS walker
# ─────────────────────────────────────────────────────────────────────────
#
# Mechanical port of the TW walker (tw_claims.py lines 771-2390) with
# TC→SC character swap per v2 swap table. Historical tuning rationale
# lives in tw_claims.py; see ADR-095/096/097/098/099/100/101 for the
# invariants preserved here. Phase 8c audit-locked divergences:
#
#   Q1: 该等 strict-rejected (tw_contamination finding category). The
#       SC reference-prefix tuples omit 该等/该些 entirely - see Step 1
#       exception 4 of the Stage 2 port prompt.
#   Q2: 朝向 retained in _INTERIOR_VERB_BOUNDARIES_CN (carried over by
#       construction - already in TW set at tw_claims.py line 1319).
#   Q3: tuple dedup (normalized_term, normalized_reference_form) from
#       day 1 (ADR-107). TW uses single-key; parity migration is a
#       Phase 9 follow-up.
#   Q4: 独 added to _WORD_INTERNAL_YI_PREDECESSORS_CN defensively.
#
# Constants and functions carry `_CN` / `_cn` suffixes. The walker
# returns list[dict] like TW; _run_cn_pipeline wraps a summary CheckItem.

# ── Walker normalization constants ───────────────────────────────────────

# Noun exclusion class (mechanical TC→SC swap per v2 § 4).
# R67 (2026-05-05) sweep: added 由 - relational verb ("composed of"); not
# a noun-internal char in patent claim diction. Empirical attestation:
# CN112271269B c10 over-captured `交联网状结构由可交联配体` because regex
# spanned 由. Compound nouns containing 由 (缘由/自由/由来/理由) are
# non-patent-relevant; safe to add as boundary.
_NOUN_CHARS_CN = r"[^\s，。；：、及与和之的该将能须应皆被于以并且其而还另时在由]{2,12}"
# R62 (2026-05-05): post-match paren-numeral closure helper. Mirrors
# the TW walker fix: when the captured noun ends with `(<alphanumeric>`
# (open paren + 1-5 digits/letters, no closing paren), the {2,12}
# length cap truncated inside an open paren-numeral. Walker emit-loop
# extends the noun by 1 char if claim.text[match_end] is `)` or `）`.
_PAREN_NUM_TRAIL_RE_CN = re.compile(r"[(（][0-9A-Za-z]{1,5}$")

# R68d (2026-05-06) TW parity: mid-能 noun capture extension. CN walker
# excludes 能 from _NOUN_CHARS_CN to prevent aux-verb 能 over-capture,
# but cuts compound nouns (功能/性能/智能/换能器/官能基) mid-word. See
# tw_claims.py R68d comment for full rationale + precursor whitelist.
# CN-side mining (supplement_v2): 52 CN walker_fp where context_after
# starts at 能 - confirms the over-cut class.
_NENG_PRECURSORS_CN = (
    "功", "性", "效", "智", "动", "机", "官",
    "才", "本", "势", "万", "全", "异", "燃", "换",
)
_NOUN_EXT_RE_CN = re.compile(
    r"[^\s，。；：、及与和之的该将能须应皆被于以并且其而还另时在由]+"
)


def _extend_neng_compound_cn(
    raw_noun: str, raw_noun_end: int, claim_text: str
) -> tuple[str, int]:
    """Mirror of _extend_neng_compound_tw with Simplified precursors.

    能量 / 能源 follow-gate (parity mirror of TW issue #75): 能 followed
    by 量 or 源 is unambiguously the noun "energy" / "energy source" -
    extend by exactly that 3-char compound (no greedy continuation).
    """
    if not raw_noun:
        return raw_noun, raw_noun_end
    if raw_noun_end >= len(claim_text) or claim_text[raw_noun_end] != "能":
        return raw_noun, raw_noun_end
    follow = claim_text[raw_noun_end + 1: raw_noun_end + 2]
    if follow in ("量", "源"):
        return raw_noun + "能" + follow, raw_noun_end + 2
    if raw_noun[-1] not in _NENG_PRECURSORS_CN:
        return raw_noun, raw_noun_end
    raw_noun = raw_noun + "能"
    raw_noun_end += 1
    if raw_noun_end < len(claim_text):
        ext_m = _NOUN_EXT_RE_CN.match(claim_text, raw_noun_end)
        if ext_m:
            extra = ext_m.group()
            room = 12 - len(raw_noun)
            if room > 0:
                added = extra[:room]
                raw_noun = raw_noun + added
                raw_noun_end += len(added)
    return raw_noun, raw_noun_end

# R47 (2026-06-27): 时-compound capture extension (parity with
# _extend_neng_compound_cn). _NOUN_CHARS_CN excludes 时 to stop the
# `在X时` when-clause over-capture, but that truncates timer/clock compound
# nouns mid-word: 定时器→定, 第一定时器→第一定 (CN115701183B c13), 计时器,
# 时钟/时序/时隙/时段/时刻/时延/时间. A when-clause 时 is ALWAYS followed by
# punctuation or a verb/connective (，。；或则…), NEVER by a timer/clock/period
# noun suffix - so gating the extension on the follow-char being such a suffix
# is FN-safe (mirrors the 能量/能源 follow-gate). The truncation class was
# surfaced by the normalization-asymmetry probe (asymmetry_probe.py): term
# 第一定 vs did_you_mean 第一定时器 - the intro is right there, only the
# reference truncated → FN-safe under-capture repair.
_SHI_NOUN_SUFFIXES_CN = ("器", "钟", "序", "隙", "刻", "延", "段", "间")


def _extend_shi_compound_cn(
    raw_noun: str, raw_noun_end: int, claim_text: str
) -> tuple[str, int]:
    """Extend a noun truncated at the excluded 时 char when 时 forms a
    timer/clock/period compound (定时器/时钟/时序/时间…). FN-safe: a when-clause
    时 is never followed by these noun suffixes."""
    if not raw_noun:
        return raw_noun, raw_noun_end
    if raw_noun_end >= len(claim_text) or claim_text[raw_noun_end] != "时":
        return raw_noun, raw_noun_end
    follow = claim_text[raw_noun_end + 1: raw_noun_end + 2]
    if follow not in _SHI_NOUN_SUFFIXES_CN:
        return raw_noun, raw_noun_end
    raw_noun = raw_noun + "时"
    raw_noun_end += 1
    if raw_noun_end < len(claim_text):
        ext_m = _NOUN_EXT_RE_CN.match(claim_text, raw_noun_end)
        if ext_m:
            extra = ext_m.group()
            room = 12 - len(raw_noun)
            if room > 0:
                added = extra[:room]
                raw_noun = raw_noun + added
                raw_noun_end += len(added)
    return raw_noun, raw_noun_end


# R48 (2026-06-27): 应-compound capture extension (Simplified mirror of the
# TW _extend_ying_compound_tw, R19). _NOUN_CHARS_CN excludes 应 to stop the
# modal 应该/应当 over-capture, but that truncates reaction/effect/sensor
# compound nouns mid-word: 晶化反应→晶化反, 水热反应→水热反, 第一反应器→第一反,
# 效应器→效, 感应线圈→感. UNLIKE 时 (a clean follow-gate), 应 can be terminal
# (反应) so a follow-char gate misses 反应; instead gate on the PRECURSOR char
# (the char before 应) being a reaction/effect/sense/response root - those
# precursors never precede the modal 应该/应当 (反应该/效应当 are not drafting
# diction). Mirrors the _NENG_PRECURSORS_CN precursor arm. Surfaced by the
# asymmetry probe (晶化反 vs did_you_mean 晶化反应). Precursor set is
# CONSERVATIVE - only chars that form an unambiguous NOUN with 应:
# 反应 (reaction), 效应 (effect), 感应 (induction), 响应 (response). The
# gray verb/adverb roots 对应/相应 (correspondingly) / 顺应 / 呼应 / 适应 /
# 供应 are EXCLUDED - `相` over-captured the adverb `执行相应` (CN115952274B
# c1) in a first attempt; the FN-guard fixture harness caught it.
_YING_PRECURSORS_CN = ("反", "效", "感", "响")


# R49 (2026-06-27): leading-quantifier cap-truncation. The _NOUN_CHARS_CN
# {2,12} cap truncates a long compound noun mid-word when a leading quantifier
# eats the budget: 所述一个或更多个便携式手持控制器 → 一个或更多个便携式手持控
# (CN109171977A c1, the 制器 cluster). The quantifier is stripped by normalize
# anyway, so it should NOT count against the noun's length budget. Detect a
# leading quantifier and restore exactly the budget it consumed.
_LEADING_QUANTIFIER_RE_CN = re.compile(
    r"^(?:一个或更多个|一个或多个|至少一个|或更多个|或多个|复数个|多个|数个|两个|一个|复数|一种|一对)"
)


def _extend_ying_compound_cn(
    raw_noun: str, raw_noun_end: int, claim_text: str
) -> tuple[str, int]:
    """Extend a noun truncated at the excluded 应 char when it forms a
    reaction/effect/sense/response compound (反应/反应器/效应器/感应…). FN-safe:
    gated on a precursor whitelist that never precedes the modal 应该/应当."""
    if not raw_noun:
        return raw_noun, raw_noun_end
    if raw_noun_end >= len(claim_text) or claim_text[raw_noun_end] != "应":
        return raw_noun, raw_noun_end
    if raw_noun[-1] not in _YING_PRECURSORS_CN:
        return raw_noun, raw_noun_end
    raw_noun = raw_noun + "应"
    raw_noun_end += 1
    if raw_noun_end < len(claim_text):
        ext_m = _NOUN_EXT_RE_CN.match(claim_text, raw_noun_end)
        if ext_m:
            extra = ext_m.group()
            room = 12 - len(raw_noun)
            if room > 0:
                added = extra[:room]
                raw_noun = raw_noun + added
                raw_noun_end += len(added)
    return raw_noun, raw_noun_end


# R66 (revised 2026-05-05) TW parity: state-modifier capture extension.
# Mirror of TW R66 capture-time fix - gated on Simplified state suffixes
# 状/形. When raw_noun ends in such a suffix and `的<head>` follows,
# extend the captured reference so the displayed reference_form is the
# full `所述<state>的<head>` phrase rather than the bare adjective
# `所述<state>`. See tw_claims.py R66 comment for full rationale.
_STATE_MODIFIER_SUFFIXES_CN = ("状", "形")
_DE_HEAD_NOUN_RE_CN = re.compile(
    r"的(?P<head>[^\s，。；：、及与和之的该将能须应皆被于以并且其而还另时在由]{2,12})"
)

# R64 (2026-05-05) TW parity: display-side ordinal restoration. Walker
# normalizes 第1 → 第一 (Arabic→CJK) for matching; UI display preserves
# drafter's original ordinal style.
_ARABIC_TO_CJK_ORDINAL_CN = (
    ("一", "1"), ("二", "2"), ("三", "3"), ("四", "4"), ("五", "5"),
    ("六", "6"), ("七", "7"), ("八", "8"), ("九", "9"), ("十", "10"),
)


def _restore_original_ordinals_cn(normalized: str, raw: str) -> str:
    """Mirror of TW _restore_original_ordinals; preserves Arabic ordinals
    in displayed reference_form when drafter wrote them that way."""
    out = normalized
    for cjk, ar in _ARABIC_TO_CJK_ORDINAL_CN:
        if f"第{cjk}" in normalized and f"第{ar}" in raw:
            out = out.replace(f"第{cjk}", f"第{ar}")
    return out

# Introduction multi-char quantifiers (TC→SC glyph swap).
_INTRO_MULTI_QUANTIFIERS_CN = (
    # Wave F (2026-10-26): the rest of the "one or more" family. Without it only
    # the leading 一个 was stripped, so both sides keyed a garbage 或多个X that
    # paired only with itself. Listed in BOTH quantifier lists (a one-sided add
    # left the intro and the reference keyed differently: wave E, 162 TW / 714 CN).
    # Wave G (2026-10-26): the classifier spellings (一种或多种 x339 CN, x57 TW).
    r"(?<!第)(?<![統统])一组(?![合织件成态装分别员元])",
    # Wave H (2026-10-26): the 種 measure word after at least / plural (至少一種 x360 TW, 至少一种 x316 CN).
    "至少一种",
    "至少两种",
    "至少二种",
    "至少三种",
    "复数种",
    "若干种",
    "数种",
    r"(?<!第)[二三四]种",
    # Wave G (2026-10-26): the two/three-or-more family (兩個或更多個 x96 TW, 两个或更多个 x98 CN).
    "两个或者更多个",
    "两个或更多个",
    "两种或更多种",
    "两条或更多条",
    "两组或更多组",
    "三个或更多个",
    "三种或更多种",
    "两个或多个",
    "两种或多种",
    "两个或更多",
    "三或更多",
    "一种或更多种",
    "一种或者多种",
    "一种或多种",
    "一组或更多组",
    "一组或多组",
    "一条或多条",
    "一个或多于一个",
    "一个或更多个",
    "一个或者多个",
    "一个或多个",
    "一或多种",
    "一个或更多",
    "一或多个",
    r"至少[一二三四五六七八九十百千\d]+个?",
    "两个",
    r"两(?![端侧])",
    r"[二三四五六七八九十]+个",
    "一个", "一种", "一对",
    # R46 (2026-06-26): plural quantifier + MEASURE WORD (条/道) - Simplified
    # mirror of TW R16 (#288). 复数条<noun> / 多道<noun> captured 条<noun> (the
    # measure leaked) so 该<noun> never matched its intro. FN-safe by the
    # _NOUN_CHARS_CN {2,12} floor (复数条码→backtracks to 条码). Listed before
    # 复数个/复数 so the longer measure-bearing token wins the ordered alternation.
    "复数条", "复数道", "多条", "多道", "数条", "数道",
    "复数个", "多个", "数个",
    "复数",
)

# Weight/molar composition intro (TC→SC).
_WEIGHT_UNITS_CN = r"(?:重量份|重量百分比|摩尔|wt%|mol%)"
_WEIGHT_COMPOSITION_PREFIX_CN = (
    r"\d+(?:\.\d+)?" + _WEIGHT_UNITS_CN
    + r"(?:至\d+(?:\.\d+)?" + _WEIGHT_UNITS_CN + r")?的"
)

# Definitional intro (mechanical TC→SC swap per v2 § 4).
# R30 mechanism #10 (2026-05-03): extended definitional prefixes.
# Common CN patent drafting introduces a term via 定义为/称为/记为/表示为
# already; corpus shows additional shapes: 此处称为, 此处定义为, 简称为
# (abbreviation marker), 命名为 (named as), 标记为 (marked as), 视为
# (deemed/treated as), 等同于 (equivalent to). Anti-pattern guard: the
# `一?` allows optional 一 prefix (drafter writes either form).
_DEFINITIONAL_PREFIX_CN = r"(?:定义为|称为|记为|表示为|此处称为|此处定义为|简称为|命名为|标记为|视为|等同于|又称为|又称|亦即)一?"

_INTRO_PATTERN_CN = re.compile(
    r"(?:"
    + _WEIGHT_COMPOSITION_PREFIX_CN
    + r"|" + _DEFINITIONAL_PREFIX_CN
    + r"|(?:" + "|".join(_INTRO_MULTI_QUANTIFIERS_CN) + r"|(?<!第)(?!(?<=进)一步)一(?![同体])))"
    + f"({_NOUN_CHARS_CN})"
)

# Reference prefixes - Q1 strips 该等/该些 from CN tuples entirely.
# The TC-contamination prefixes live only in check_antecedent_basis_cn
# (see the Q1 tw_contamination rejection branch); no module-level
# constant names them.
_REFERENCE_PREFIXES_CN = ("所述", "前述", "该")
# Negative lookahead on bare 该: suppress matches on 该等/该些 so the
# Q1 tw_contamination rejection (in check_antecedent_basis_cn) is the
# sole handler of those forms. 所述/前述 have no collision.
_REF_PATTERN_CAPTURE_CN = re.compile(
    r"(?P<prefix>所述|前述|该(?![等些]))"
    + f"(?P<noun>{_NOUN_CHARS_CN})"
)

# Trailing-verb denylist (mechanical TC→SC swap; historical rationale in
# tw_claims.py lines 869-990).
# Noun compounds ending in 匹配 that must survive the trailing-verb strip (see
# the R53 guard at the strip site). 匹配 is noun-gray: it is a predicate in the
# 与…相匹配 construction (strip) but the head of an element name in 阻抗匹配
# (do not strip). Extend this set when a report attests another such compound.
_MATCH_NOUN_COMPOUNDS_CN: frozenset[str] = frozenset({"阻抗匹配"})

# R61 (2026-08-13) - CN mirror of _GEI_FINAL_NOUNS_TW: bigrams in which 给 is
# the second half of a noun rather than the transfer coverb. Measured from the
# CN corpus independently of TW: 电力供给 (x23) / 电源供给 (x10) are referenced
# element names; every other 给-final bigram there is a coverb (发送给 /
# 提供给 / 传递给). See the TW twin for why this is an endswith guard and not
# the #492-preferred exact match - the protected lexeme appears as the TAIL of
# a compound, and the colliding capture (one ending in bare 供 / 补) is
# unreachable because the noun scan halts at the two-character verb.
_GEI_FINAL_NOUNS_CN: tuple[str, ...] = ("供给", "补给")

# R63 (2026-08-17, TW R41 mirror of #539) - 属-final NOUN lexemes, measured over
# the CN claim corpus at the positions where a capture can END: 金属 156 of 175,
# 所属 18, 菌属 1. CN is MORE exposed than TW here (金属 is 89% of the noun-final
# occurrences vs 51%), so the lexeme guard is load-bearing, not decorative.
# 附属/专属/隶属 are TW-only lexemes with no CN corpus occurrences at a capture
# boundary; TW protects them because the drafter nominalizes them there.
_SHU_FINAL_NOUNS_CN: tuple[str, ...] = ("金属", "菌属")


_TRAILING_VERB_DENYLIST_CN: tuple[str, ...] = tuple(sorted(
    (
        # === R63 (2026-08-17) - TW R41 mirror, the V+于 STRANDING family.
        # 于 is excluded from _NOUN_CHARS_CN exactly as 於 is on TW, so the same
        # verbs strand. Both REPRODUCED on the CN normalizer first rather than
        # being assumed: `所述背景类型属` and `所述控制系统安装` come back
        # unchanged at HEAD.
        #   安装 (from 安装于) - productive only as a PREFIX (安装端 / 安装臂 /
        #     安装部, 889 corpus occurrences all followed by their head noun),
        #     which an endswith strip cannot touch.
        "安装",
        #   属 (from 属于) - guarded by _SHU_FINAL_NOUNS_CN; a bare strip would
        #     truncate 导电金属 to 导电金.
        "属",
        # === R61 (2026-08-13) - mirror of TW R38 (#515/#516/#517/#526) ===
        # Every arm was REPRODUCED on the CN normalizer before mirroring, per the
        # standing cross-jurisdiction duty - none was ported on the TW evidence
        # alone.
        #
        #   启动 ("activate"): CN reproduces TW's shape exactly -
        #     clean_noun_phrase_cn('收音单元启动') returned it unchanged. Prefix
        #     position (启动装置 / 启动信号) is unreachable by an endswith strip.
        "启动",
        #   重新启动 + 已 - the #389 greedy-trim obligation, same as TW. Bare 启动
        #     alone cuts inside the four-character verb 重新启动 and strands its
        #     head. 已 is an aspect particle, never noun-final; CN's prefix uses
        #     (所述已解密数据) are unreachable by an endswith strip. CN already
        #     carries the sibling 恢复运行 for the same class.
        "重新启动",
        "已",
        #   运作 ("operate"): CN was WORSE than TW here, not merely equal - it
        #     already carried a bare 作 strip, so 外部电子装置运作 normalized to
        #     外部电子装置运, stranding 运. This is a pre-existing stranded-head
        #     defect the parity check surfaced; the two-character entry strips
        #     greedily and recovers 外部电子装置.
        "运作",
        #   给 ("give / to"): the transfer coverb, stranded at the end of the
        #     capture exactly as on TW (`一分享权限给通过所述身份验证程序的…`
        #     captured 分享权限给). Carries the same lexeme guard as TW, and the
        #     CN corpus independently justifies it: 电力供给 (x23) and 电源供给
        #     (x10) are referenced element names, while every other 给-final
        #     bigram there is a coverb reading (发送给 / 提供给 / 传递给).
        "给",
        # === R59 (2026-08-01, reports #448/#449/#451/#454) ===
        # One CNIPA drafter's on-chip integrated WDM draft (片上集成波分复用器) -
        # the largest single CN report batch the campaign has seen.
        #
        #   或者 ("or", #451 antecedent + #454 spec-support): the Markush
        #     alternation connective, captured into the noun head in
        #     `连接所述刻蚀衍射光栅结构、所述阵列波导光栅结构或者所述角度型多模干涉仪
        #     结构` and in `所述第一输入波导的数量或者所述第二输入波导的数量`. Bare
        #     或 has been a member since R36, but the capture ends in 者, so the
        #     endswith strip could never reach it - the two-character form is the
        #     whole gap. A pure conjunction with no noun sense; FN-safe.
        "或者",
        #   集成 ("integrated", #448/#449): `所述波分复用器集成于一光子集成电路芯片上`
        #     over-captured the reference to 波分复用器集成, so 所述波分复用器 never
        #     matched its intro 一种片上集成波分复用器. 于 is excluded from the CN
        #     noun chars, so the scan halts exactly at the verb and the capture
        #     always ends in 集成 - which is why an endswith strip reaches it and
        #     an interior cut is unnecessary. 集成 is a noun-MODIFIER in 集成电路 /
        #     片上集成, i.e. it is followed by its head noun there and never sits
        #     at the tail, so the endswith strip cannot touch those compounds.
        "集成",
        # === R57 (2026-07-23) - TW R32 parity (report #424, spec-support) ===
        # 所对 - the stranded head of 所对应 ("that which corresponds to").
        # Latent on CN, and the pre-existing bare-对 strip made it WORSE, not
        # inert: 电容所对 -> 电容所 (对 stripped, 所 stranded). Adding the full
        # 所对 collocation strips both: 电容所对 -> 电容. FN-safe - no CN element
        # name ends in 所对 (所-suffix nouns are 场所/研究所/事务所).
        "所对",
        # === R56 (2026-07-22) - TW R31 parity (reports #416/#417/#423) ===
        # Verified LATENT on the CN side by direct probe before the fix (same
        # discipline as R52/R54): the Simplified analog of the reported TW draft
        # over-captured `正压电容开关受控` / `正压电容开关彼此串接` -> the reference
        # 所述正压电容开关 found no intro, exactly as on TW, and clean_noun_phrase_cn
        # left both intact. An invisible FN-direction parity gap (the sibling was
        # the over-flagger and no CN report could ever surface it). 受控 is a
        # passive marker with no noun sense in suffix position; 彼此串接 is added
        # as the full reciprocal-adverb+verb collocation (never bare 串接). The
        # sibling TW R31 also carries a 对-at-ref-prefix-truncation trim that is
        # deliberately NOT mirrored: the CN analog #418 does NOT reproduce (CN's
        # forward-prefix resolution already resolves 外部控制电路 through the 对
        # over-capture - consistent with the settled "CN bare 对 buys nothing").
        "受控", "彼此串接",
        # === R54 (2026-07-18) - TW R29 parity (reports #389/#390, #394/#395/#396) ===
        # Verified LATENT on the CN side by direct probe before the fix (same
        # discipline as R52: probe first, mirror only what actually reproduces).
        "划分", "随着",
        # === R55 (2026-07-20) - TW R30 parity, report #399 ===
        # 间隔<verb> spacing collocations. Bare 间隔 is deliberately ABSENT for
        # the same FN reason as TW (时间间隔 / 子载波间隔 are real element
        # names). Corpus-silent on CN (0/0/0) but latent-safe parity; note CN
        # lacks bare 排列 entirely, so these compounds fix 间距间隔排列 WITHOUT
        # taking on the separate DR-1 question of whether bare 排列 is CN-safe.
        "间隔排列", "间隔设置", "间隔布置", "间隔配置", "间隔分布",
        # === R52 (2026-07-13) - TW R27 parity (reports #354/#355, #366, #381-#384) ===
        # Trailing predicate verbs that bled into the captured term, orphaning
        # the bare-noun head. All verified LATENT on the CN side by direct probe
        # before the fix (clean_noun_phrase_cn left each over-capture intact), so
        # these are real parity bugs, not speculative mirrors. endswith strips, so
        # noun compounds that merely CONTAIN the verb are untouched (枢接部 does not
        # END in 枢接). 运行 was ALREADY present on the CN side - the asymmetry ran the
        # other way for that one, which is exactly what the parity check is for.
        #   枢接 ("pivotally connect") - TW #354/#355.
        #   拍摄 ("photograph") - TW #366.
        #   催化下 - TW #381-#384: the verbal-locative frame 在<N><V>下 ("under the
        #     <V> of <N>"). The strip must include the 下 because that is where the
        #     capture ends; a bare 催化 entry would never fire. The catalyst noun
        #     催化剂 is untouched (it does not end in 催化下).
        "枢接", "拍摄", "催化下",
        "包含", "包括", "含有", "具有", "系", "为", "是", "设有", "具备",
        "通过", "经由", "借由", "基于", "透过", "根据", "依据",
        # R45 (2026-06-26): trailing predicate verbs from the CN normalization-
        # asymmetry probe (intro keeps the clause verb; reference is clean).
        # 引起/调整 mirror TW R15; 共混 (blend), 附接 (attach - mirrors TW R12),
        # 配置成 (configured-as - the VERB construction, distinct from noun 配置).
        # Noun compounds carry these with a suffix (调整器/共混物/附接件), so the
        # endswith strip doesn't touch them. FN-guarded.
        "引起", "调整", "共混", "附接", "配置成",
        # NOTE: 排列 (arrange) intentionally NOT mirrored from TW R13 (#266).
        # On the CN corpus it is FN-safe but corpus-silent AND regresses
        # `纤维材料轴向地排列` (strips only 排列, stranding the adverb 轴向地)
        # where the CN pipeline already yields the clean 纤维材料. Re-attempt
        # only with 轴向地-class adverb handling + a CN report (DR-1).
        "还包含", "还包括",
        "并且", "以及",
        "并", "且", "其", "其中", "还", "另",
        "包", "通", "经", "借",
        "所", "前",
        "到", "出",
        # 从: coverb "from" - cross-jurisdiction mirror of the TW #75
        # fix (PR #83). `<noun>从` over-capture; 从 is a coverb in suffix
        # position, never a noun terminus (从动 carries 从 at PREFIX).
        # Corpus-clean: CN phase-8c harness delta 0 vs pristine baseline.
        "从",
        "介",
        "位",
        "或",
        # R62 (2026-05-05) ATTEMPTED but REVERTED - trailing 和/与/及 strip
        # caused 2 protect:true label silencing + 6 unresolved_removed in
        # the CN harness. The risk audit underestimated noun compounds
        # ending in 和 (e.g., 总和 sum, 平和 balance, 缓和 mitigation) -
        # these ARE element-name candidates in chemistry/measurement
        # claims. Held off pending finer-grained guard (e.g., minimum
        # residual length + protected-suffix list) before re-attempting.
        "中",
        "后",
        "用",
        "上",
        "内",
        "下",  # 在…下 locative (TW mirror); residual >= 2 keeps 地下/以下
        "分别", "皆",
        "处",
        "至",
        "依序",
        "撷取",
        # Stage 4 R1 D4a - ADR-100 pattern, CN-specific extensions
        "相关", "有关",
        # Phase 8c close-out R-CO-2 WQ1a - multi-char trailing verbs
        # Walker false positives where capture trails into a verb phrase.
        # Length-desc strip order: 联合训练 / 恢复运行 fire before bare 训练 / 运行.
        "联合训练", "恢复运行",
        "存储有",
        "进行", "接收", "发送", "输入", "来自", "需要",
        "运行", "执行", "确定", "提供", "匹配", "表征",
        "生成", "获取", "获得",
        "向",
        # Phase 8c R9 - additional trailing verbs from re-sampling analysis
        "针对", "支持", "调用", "采用", "作为",
        "对",
        # Phase 8c R22 - single-char preposition residues from BYD-style
        # paren-numeral terms (从动凸轮(320)由, 凹部(322)沿, 辅助层沿).
        "由", "沿",
        # Phase 8c R23 - multi-char trailing verbs from over_capture pool
        # (77-active stratification). Compound-noun risk audited per token
        # against full corpus V+CJK matches; all dominated by particle/
        # determiner suffixes (所/时/的/方) that don't form noun compounds.
        "录入", "推荐", "导入", "提取", "转动", "重复",
        "体外培养", "胰蛋白酶消化", "铰接", "选自", "代替", "交联",
        "检查", "查询", "保存", "固定", "回复", "消化",
        "恢复",
        # Phase 8c R24 - single-char trailing residues from over_capture
        # pool (16 active labels post-R23). Compound-noun risk audited:
        # all noun compounds (作用/不良/相应/均匀/得到) appear at PREFIX
        # position in corpus; suffix-position usage is uniformly verb/
        # particle. All 16 emit-terms ending in these chars match the
        # 16 targets exactly (zero collateral).
        "作", "不", "相", "均", "得",
        # === Phase 8c R7-port (2026-04-30) - TW Round 7 cross-port ===
        # 较 (comparative verb), 厚膜化 (process verb-suffix). CN parity
        # for TW additions; CNIPA semiconductor drafters use these
        # identically. 0 active CN-label collisions; 比较/较量 etc.
        # protected via the existing residual ≥ 1 floor (2-char compounds
        # with 较 at position [-1] strip to 1 char, blocked).
        "较", "厚膜化",
        # === R29 (2026-05-03) - round-1 corpus over-capture extensions ===
        # Conservative extension only. Excludes verbs that double as common
        # noun endings (处理, 配置, 形成, 驱动, 存储, 传输, 连接, 选择,
        # 标识, 识别) - those silenced legacy `处理器配置` protect:true
        # label on tw_contamination_simple synthetic. Kept additions are
        # clearly-verb multi-char phrases without noun-suffix ambiguity.
        "围绕", "代表", "连同", "表示", "移动",
        "检测", "测量", "收集", "输送",
        "释放", "操控", "扫描",
        "覆盖", "分离", "比较", "判断", "决定", "分析",
        "包括以下", "执行以下", "进行以下",
        "执行以下操作", "执行以下操",
        # === R63 (2026-05-05) - TW parity port (神秘黑屏哥.docx audit) ===
        # `不同`/`仅` parity from TW. Pure adjective/adverb in both scripts.
        # CJK `不同` is identical between Simplified and Traditional;
        # `仅` is the SC form of TW `僅` (same meaning, "only/merely").
        # Risk audit:
        # - 不同 trailing: pure adjective, never noun-position-suffix.
        # - 仅 trailing: adverb, never part of noun. 僅供/僅限 are
        #   adverb+verb, not nouns.
        # Min residual via R32 emit-time len < 2 filter.
        "不同", "仅",
        # === R32 (2026-05-04) - passive trailing residue ===
        # 被: passive marker (`<noun>被<verb>`). Compound nouns ending in
        #   `被` are vanishingly rare in CN patent claims (棉被/被服 are
        #   household items, not patent terms). Empirically: walker emits
        #   `单元被`/`子单元被` from CN114357105B c12/c15 spec-support FPs
        #   where bare `单元`/`子单元` is the canonical intro.
        #
        # NOT included: 通信/通讯. Initially considered, but corpus audit
        # showed compound NOUNS like `侧链路中继通信` / `无线通信` use
        # 通信 as HEAD noun at suffix position; symmetric strip would
        # bridge legit-flagged refs to bare `侧链路中继` and silence 7
        # protect:false legit-drafting-error labels in CN115398975B c1-8
        # (LLM ensemble Phase 2c verified). Reserved for a context-aware
        # mechanism (verb-mode vs noun-mode) outside R32 scope.
        '被',
        # === R32 (2026-05-04) - verb-suffix trailing residues (CN parity) ===
        # Cluster-mined from round-1 CN corpus.
        '延伸',  # 51 walker_fp / 0 legit. (Risk audited per TW.)
        '指示',  # 42 walker_fp / 0 legit. Verb form ("indicate").
                # NOTE: 指示牌 / 指示灯 noun compounds at PREFIX position.
        # === R30 (2026-05-03) - sample-derived adverbial / adjectival trims
        # 进一步: adverbial ("further"), fragment of 进一步包括/进一步具有.
        #   Multi-char so safe against noun compounds (第一步/一步走 unaffected).
        # 相关联: adjectival ("related/associated"), fragment of <noun>相关联的.
        #   Existing 相关 + 有关 catch 2-char form; 3-char form needs explicit.
        "进一步", "相关联",
        # === R-batch-r3 (2026-06-01) - locative/positional verb trims
        # 相邻: adjectival ("adjacent"). Never a noun-suffix in CN patent
        #   diction - appears at PREFIX position in legitimate compounds
        #   (相邻边缘 / 相邻区域 / 相邻通道). Closes tw_contamination
        #   over-capture `限位导槽分别相邻` → `限位导槽` (issue #171).
        "相邻",
        # === R41 (2026-06-24) - examiner/gold-mined trailing-verb over-capture
        # batch. Mined from CN gold walker_fp over-capture cluster (2,129
        # no-intro over-captures; these verbs over-ran the head noun, e.g.
        # `换挡拨叉接合`/`开关断开`/`第一光束移动`). All are unambiguous VERBS in
        # trailing position; noun-sense compounds carry a suffix (插入件/对接器/
        # 联接器/穿刺针) so the bare 2-char verb only appears verb-mode at the
        # tail. The FN-guard (silenced_legit==0 over the CN gold) vets each;
        # gray noun-sense verbs (接触/存储/垂直/平行) were HELD OUT, and the
        # FN-guard further removed 布置/接合/插入/对接/联接/卡合/贴合 - each
        # carries a real NOUN sense (布置=layout, 接合=joint, 插入=insertion,
        # 对接/联接=coupling/docking) that the LLM gold flagged as a legit head
        # noun, so stripping them silenced real defects (direct + intro-side
        # cascade). The surviving set is verb-only at the noun tail.
        "穿过", "断开", "切换", "前进", "对准", "穿刺", "嵌入",
        # === R42 (2026-06-24) - second examiner/gold-mined trailing-verb
        # over-capture batch (CN gold walker_fp, 2-char trailing cluster, each
        # legit==0 in the ensemble gold). Same discipline as R41: noun-sense
        # compounds carry a distinguishing suffix so the bare verb only appears
        # verb-mode at the tail - 套设 (sleeve-FIT; the noun is 套筒/套件),
        # 靠近/接近 (approach; the noun 接近度 carries 度), 加入 (add/join),
        # 实施 (implement; the noun 实施例 carries 例), 指定 (designate).
        # Strong independent-NOUN-sense verbs were HELD OUT pre-guard on
        # noun-sense judgment (DR-1), even though the gold flags them clean:
        # 偏移 (offset - a bare noun in 位置偏移), 关联 (association -
        # 关联关系/关联性), 结合 (combination/junction - 结合部). And the
        # FN-guard AUTO-NARROWED 混合 (mix): although no gold-legit reference
        # term ENDS in 混合, stripping it turned the intro-side `与氧源混合`
        # ("mixed with an oxygen source") into a false bare-noun intro of 氧源,
        # which silenced 4 real `所述氧源` §112 defects in CN1384805A
        # (intro-cascade FN). The surviving set is verb-only at the noun tail
        # AND cascade-clean over the CN gold.
        "套设", "靠近", "接近", "加入", "实施", "指定",
        # === R43 (2026-06-24) - third over-capture batch: relational/geometric
        # PREDICATE verbs at the tail (CN gold 2-char trailing cluster, each
        # legit==0). 垂直/平行 (perpendicular/parallel - `第三方向垂直`,
        # `输出轴线平行`; the noun senses 垂直度/平行度 carry 度 so the bare form
        # is predicate-only at the tail - these were held conservatively in R41
        # but the gold + geometry now clear them), 暴露 (exposed -
        # `连接段至少部分暴露`), 啮合 (mesh/engage - `输入小齿轮啮合`),
        # 保持 (maintain/hold - `屏蔽构件保持`; the noun 保持架 carries 架).
        # FN-guard auto-narrows any that silence gold-legit or cascade (cf. 混合).
        "垂直", "平行", "暴露", "啮合", "保持",
    ),
    key=len,
    reverse=True,
))

# Noun-like single-char trailing suffixes with residual ≥ 3 guard.
# R22 adds 由/沿; R24 adds 作/不/相/均/得 with relaxed-residual subset
# participation below.
_NOUNLIKE_SINGLE_CHAR_SUFFIXES_CN: frozenset[str] = frozenset(
    {"所", "位", "中", "后", "用", "上", "内", "下", "撷取", "对", "由", "沿",
     "作", "不", "相", "均", "得",
     # === R7-port (2026-04-30) - TW R7 parity ===
     # 使 (causative particle / verb fragment): residual ≥ 3 protects
     # 大使/天使/特使/使用 (all 2-char compounds, residual 1 < 3).
     "使",
     # === R68 (2026-05-06) - supplement_v2 mining (TW parity) ===
     # 来: verb tail particle in `所述<noun>来自X` constructions.
     # 27 CN walker_fp findings end in 来 across supplement_v2.
     # See tw_claims.py R68 comment for full rationale.
     "来",
     # 向: TW parity (CN 0 walker_fp this round but pre-emptive - CN
     # drafters share the same `<noun>向X` preposition pattern).
     # GUARDED below by _DIRECTION_STEM_BEFORE_XIANG_CN: 向 is a bound noun
     # suffix in 方向/轴向/径向/… (direction nouns), NOT a strippable
     # preposition. Without the guard, `所述圆周方向` truncates to `圆周方`
     # (CN117837052A c32, a real corpus walker_fp). WS-B1 (2026-06-24).
     "向",
     # 自: TW parity (CN had 1 walker_fp, low signal - pre-emptive).
     "自"}
)

# WS-B1 (2026-06-24) - direction-noun stems that bind 向 as a NOUN suffix
# (方向/轴向/径向/横向/纵向/周向/切向/法向/侧向/竖向/斜向/单向/双向/同向/反向/
# 正向/逆向/定向/指向/取向/转向/导向). When a captured term ends in `<stem>向`,
# the 向 is part of the head noun and must NOT be stripped. Over-inclusion is
# FN-safe: at worst it leaves a pre-existing over-capture (FP-direction), it can
# never over-silence a real defect. Grounded by the 圆周方向→圆周方 corpus FP.
_DIRECTION_STEM_BEFORE_XIANG_CN: frozenset[str] = frozenset(
    "方径轴横纵周切法侧竖斜单双同反正逆定指取转导"
)

# Relaxed-guard subset (residual ≥ 2 instead of ≥ 3).
# Stage 4 R1 D4a - relaxed residual ≥ 2 guard for 2-char-stem residue strip.
# R22 adds 由/沿; R24 adds 作/不/相/均/得 (mirrors trailing-verb registration).
# R68 (2026-05-06) adds 来 (TW parity).
# Characters that make 下 part of a word (如下, 以下, 向下, 按下) rather than
# the 在…下 locative, so the trailing strip leaves it.
_XIA_WORD_HEADS_CN: frozenset[str] = frozenset("如以之其底地零上天落留剩放按压向往朝降垂拉取卸拆倒掉写记接")
_NOUNLIKE_RELAXED_SUFFIXES_CN: frozenset[str] = frozenset(
    {"上", "内", "下", "后", "中", "用", "对", "由", "沿",
     "作", "不", "相", "均", "得", "来"}
)

# Phase 8c R22 - `中` very-relaxed (residual ≥ 1) for 2-char locative
# phrases like 组中. The post-strip 1-char residual is then filtered by
# the `len(normalized_term) == 1` emit guard. Empirically scoped: only
# 2 corpus terms (组中 ×2 in CN115952274B) hit this path.
_NOUNLIKE_VERY_RELAXED_SUFFIXES_CN: frozenset[str] = frozenset({"中"})

# Phase 8c R10 - char-exclusion residue map.
# Keys: residue chars left at end of terms because _NOUN_CHARS_CN excludes
# the following char (于→基, 能→功, 应→响).  Values: minimum residual
# length after stripping the residue char.
_CHAR_EXCLUSION_RESIDUE_CN: dict[str, int] = {
    '\u57fa': 3,  # 基 (from 基于) - guard ≥3 protects 培养基
    '\u54cd': 2,  # 响 (from 响应)
    '\u529f': 2,  # 功 (from 功能)
    '\u8f93': 2,  # 输 (from 输出 where 出 is in trailing denylist)
}

# CN R68 (2026-09-07) - noun compounds ending in 位, which the bare trailing
# 位 strip was destroying. 位 is a verb in 位于 ("is located at") and a NOUN
# SUFFIX in 部位 / 相位 / 电位 / 单位 - the same noun-gray shape as the 匹配
# entry, and the same latent FALSE NEGATIVE: a genuine 所述治疗部位 antecedent
# defect was truncated to 治疗部 and could never be flagged.
#
# The only thing between the strip and these nouns was a RESIDUAL LENGTH
# heuristic (>= 3), which is not a judgement about wordhood at all - 治疗部位
# is four characters, so it cleared the bar and lost its head. That is the
# US R52 `-ed` lesson in CN: a length test standing in for a lexical one.
#
# Members are CORPUS-ATTESTED, mined by anchoring on the drafter's OWN
# determiner or reference marking, which is what proves the form is an element
# name rather than a predicate. Removing the bare entry outright was measured
# FIRST and reverted: it silenced 7 gold-legit findings, and NONE of the seven
# terms contains 位 - the token-absent signature of the spurious-intro
# cascade. Guarding the compound keeps the 位于 predicate strip and closes
# the false negative.
#
# R43 MEMBER-BY-MEMBER BISECT (2026-09-10). Eleven candidates were measured as
# eleven separate validate_fix runs against the 14,419-finding CN baseline.
# NINE ARE CLEAN AND SHIP. TWO ARE WITHHELD, FOR DIFFERENT REASONS, AND THE
# REASONS ARE THE REUSABLE PART:
#
#   置位 - 3 ended, 1 gold-legit silenced. It is NOT a word here. The claim
#     reads `所述输出轴装置位于所述封壳…` - the element name is 输出轴装置
#     and the verb is 位于, so `endswith("置位")` matches 装置 + 位 across a
#     boundary THAT DOES NOT EXIST. A segmenter confirms it independently:
#     of 20 corpus occurrences only 2 are a real word and 18 are this exact
#     artefact. Two instruments, one answer. A 位-final guard mined by string
#     matching will always admit members like this, so the segmenter check is
#     now part of mining, not an afterthought.
#
#   相位 - 12 ended, 0 gold walker_fp, 3 UNPAIRED. This one IS a real word
#     (226 of 246 occurrences segment as one token) and the guard is correct;
#     it simply exposes three ARTICLE-LESS INTRODUCTIONS that the truncation
#     had been covering by accident - `提供第一相位…所述第一相位`, where the
#     drafter introduces the element bare. That is the #525 dirty-capture-is-
#     load-bearing shape, and the article-less class is separately MEASURED
#     UNREACHABLE (the blanket rule ends 4,207 FPs and causes 1,539 FNs). So
#     it is withheld on the trade, not on the mechanism: 12 ended, none of
#     them gold, against 3 manufactured. Re-open it only together with the
#     article-less class, never on its own.
#
# 栏位 (34/34) and 限位 (142/144) fire ZERO times on this corpus. They ship on
# the segmenter evidence that they are unambiguous words, and are recorded here
# as UNMEASURED rather than as proven-safe.
_WEI_NOUN_COMPOUNDS_CN: tuple[str, ...] = (
    "部位", "单位", "电位", "移位", "栏位",
    "限位", "箝位", "定位", "挡位",
)


# Chemistry chars that legitimately precede 基 (functional-group suffix).
# When the char before 基 is in this set, 基 is a noun, not a verb residue.
_CHEMISTRY_BEFORE_JI_CN: frozenset[str] = frozenset(
    '性酸碱甲乙丙丁养氨羟羧磷烷烯烃硫氧氮氯氢苯胺酮醛酯醇酚'
)

# Leading quantifier denylist (TC→SC).
_LEADING_QUANTIFIER_DENYLIST_CN: tuple[str, ...] = tuple(sorted(
    (
        # Wave F (2026-10-26): the rest of the "one or more" family. Without it only
        # the leading 一个 was stripped, so both sides keyed a garbage 或多个X that
        # paired only with itself. Listed in BOTH quantifier lists (a one-sided add
        # left the intro and the reference keyed differently: wave E, 162 TW / 714 CN).
        # Wave G (2026-10-26): the classifier spellings (一种或多种 x339 CN, x57 TW).
        # Wave H (2026-10-26): the 種 measure word after at least / plural (至少一種 x360 TW, 至少一种 x316 CN).
        "至少一种",
        "至少两种",
        "至少二种",
        "至少三种",
        "复数种",
        "若干种",
        "数种",
        "二种",
        "三种",
        "四种",
        # Wave G (2026-10-26): the two/three-or-more family (兩個或更多個 x96 TW, 两个或更多个 x98 CN).
        "两个或者更多个",
        "两个或更多个",
        "两种或更多种",
        "两条或更多条",
        "两组或更多组",
        "三个或更多个",
        "三种或更多种",
        "两个或多个",
        "两种或多种",
        "两个或更多",
        "三或更多",
        "一种或更多种",
        "一种或者多种",
        "一种或多种",
        "一组或更多组",
        "一组或多组",
        "一条或多条",
        "一个或多于一个",
        "一个或更多个",
        "一个或者多个",
        "一个或多个",
        "一或多种",
        "一个或更多",
        "一或多个",
        "至少一个", "至少一",
        "一个", "一种", "一对",
        "复数个", "多个", "数个",
        "复数",
        "一",
        # Cross-jurisdiction parity with TW R6 (ce91d2b): 各 distributive
        # quantifier ("each"). CNIPA drafters use 前述各X / 所述各X / 该各X
        # for "each X" references when a parent claim introduces an indexed
        # family. Reference-side normalization must strip 各 so the bare
        # head noun matches the upstream intro. Symmetric strip on the
        # intro side is harmless because 各X intros are unattested at
        # claim-body level (the indexed family is introduced as bare noun,
        # then references add the distributive 各 prefix). Audit confirmed
        # 0 active CN labels collide; 3 resolved entries have mid-string
        # 各 (compound noun usage like 各样本数据) which startswith() leaves
        # untouched.
        "各",
        # === R30 (2026-05-03) - extended plural-quantifier bridging ===
        # Phase 2c Refinement C: when a parent claim introduces `多个X` /
        # `若干X` and a dependent references `所述X` (singular), bridging via
        # symmetric strip is the right move per CN drafting practice. The
        # original set covered 复数/多个/数个; this round adds the rest of
        # the common CNIPA quantifier vocabulary. All multi-char so safe
        # against compound nouns (无 single-char additions).
        "若干个", "若干",
        "一些", "某些",
        "多种", "多类", "多组", "多对",
        "至少两个", "至少两", "两个", "两种",
    ),
    key=len,
    reverse=True,
))


# Wave F (2026-10-26): strip a leading multi-character quantifier BEFORE the
# cleaner, not after it. The interior cuts used to see 所述至少一個處理器 whole and
# could stop inside the noun, leaving only the quantifier (至少一個 -> 個, 一个或多个
# 接收方 -> 或多个). Stripped first, the cuts see only the noun. When this fires,
# the later strip_leading_quantifier is skipped: that strip is deliberately single
# (至少一個一次性容器 keeps 一次性). 一对 stays with the later strip, where the
# drafter-anchored disambiguation lives; a residue under two characters is left.
_PRE_CLEAN_QUANTIFIERS_CN: tuple[str, ...] = tuple(
    q for q in _LEADING_QUANTIFIER_DENYLIST_CN if len(q) >= 2 and q != "一对"
)


# Wave H (2026-10-26): 「一组」 ("a set of") is a quantifier unless the next
# character makes a 組 noun (一组合物 / 一组件 / 一组織 / 一组成 ...). Corpus:
# TW 477 / CN 319 uses; the guard covers every noun reading in the census.
_ZU_NOUN_NEXT_CN = "合织件成态装分别员元"


def _is_guarded_zu_cn(text: str, pos: int) -> bool:
    return text.startswith("一组", pos) and text[pos + 2: pos + 3] not in ("", *_ZU_NOUN_NEXT_CN)


def _pre_clean_quantifier_strip_cn(text: str) -> tuple[str, int]:
    """Return the text without its leading quantifier, and the quantifier length."""
    # Wave I (2026-10-26): longest quantifier first, and a ONE-character noun
    # after a measure-word or or-family quantifier (複數個塊, 一个或多个柱) is
    # stripped too: it kept a garbage key (個塊 / 或多个柱) before. One-character
    # keys are inert in lookup; garbage ones are not.
    for q in sorted(_PRE_CLEAN_QUANTIFIERS_CN, key=len, reverse=True):
        if not text.startswith(q):
            continue
        rest = len(text) - len(q)
        if rest >= 2 or (
            rest == 1 and (q[-1] in "个种条根支片块层组对件套" or "或" in q) and "\u4e00" <= text[-1] <= "\u9fff"
        ):
            return text[len(q):], len(q)
    if _is_guarded_zu_cn(text, 0) and len(text) >= 4:
        return text[2:], 2
    return text, 0

# Reference-form prefixes stripped from reference terms only (Q1: 该等/
# 该些 excluded per Step 1 exception 4 of the port prompt).
_REFERENCE_FORM_PREFIXES_CN: tuple[str, ...] = tuple(sorted(
    ("所述", "前述", "该"),
    key=len,
    reverse=True,
))

# Plural reference-form prefixes - Q1 excludes 该等/该些 from CN;
# the strict_plural_reference_matching escape hatch fires on the
# remaining 前述/所述 plural markers.
_PLURAL_REFERENCE_PREFIXES_CN: tuple[str, ...] = tuple(sorted(
    ("前述复数", "所述复数", "所述多个"),
    key=len,
    reverse=True,
))

# Interior-boundary tokens (mechanical TC→SC swap). See tw_claims.py
# lines 1138-1331 for the historical risk-review rationale per verb.
_INTERIOR_VERB_BOUNDARIES_CN: tuple[str, ...] = tuple(sorted(
    (
        # === R69 (2026-09-10, TW R59 mirror, report #744) ===
        # 提供X where X is an OBJECT DETERMINER. See the TW comment for the full
        # rationale. The CN numbers are DIFFERENT and that is why the mirror is
        # measured rather than copied: TW's dominant noun head is 提供者 (54),
        # CN's is 提供商 (100 vs 提供者 at 2). A guard list mined on one side
        # would have been wrong on the other; the determiner gate is insensitive
        # to which noun head a jurisdiction prefers, because none of them carries
        # a determiner. 的 excluded for the same reason as TW.
        "提供一", "提供该", "提供所述", "提供第", "提供至", "提供给",
        "提供多个", "提供两个",
        # === R64 (2026-09-01) - TW R47 mirror, found by the NEW term-quality
        # gate rather than by a CN report ===
        # 且 is a coordinating conjunction and cannot be noun-internal: measured
        # across 5,530 CN corpus occurrences it is followed only by function
        # words (且所 1123, 且其 1055, 且在 278), and ZERO emitted CN antecedent
        # terms contain it. The TW half was driven by reports #676/#639/#640/
        # #663; the CN half had NO report behind it and was invisible until the
        # term-quality gate shipped in the same round surfaced 9 structurally
        # bad CN spec-support terms (等于m并且小于, 并且在, 并且当, 等于℃且小于).
        # That is the gate paying for itself on its first run.
        #
        # 并 (Simplified 並) is NOT included - 并联 "parallel connection" is a
        # real compound, exactly as on the TW side.
        "\u4e14",
        # === CN R70 withheld, CN R72 (2026-10-24) ships: 并 and 而 ===
        # TW R62's interior cuts. R70 measured them net-harmful (并 16 FP / 1
        # legit, 而 10 FP / 4 legit): a cut can leave a 2-char stem (`结合`,
        # `操作`) that the prefix fallback matched to a longer element. R72 adds
        # the resolution-side guard (_short_stem_opens_compound_cn) and, per
        # Christopher's 2026-10-23 ruling that an article-less earlier mention
        # is an introduction, re-read the five silenced gold-legit as gold
        # errors. Together: 31 walker_fp + 1 coverage ended, 0 legit, 1 real
        # defect surfaced. Ring-fusion 并 (苯并咪唑) is vetoed at the cut.
        "\u5e76", "\u800c",
        # === R63 (2026-08-17) - TW R41 mirror, reports #533/#535 ===
        #   经 ("undergoes / via") - `一共聚物经氢化反应而获得` captured as ONE
        #     intro so the later `所述共聚物` had nothing to match. Reproduced on
        #     the CN normalizer at HEAD before mirroring. A trailing strip
        #     cannot reach it (bare 经 IS already a CN trailing entry) - the
        #     capture ends in the verb's OBJECT.
        #
        #     Ships with _jing_cut_is_verbal_cn, never bare: 经 is a
        #     PASSIVE-ATTRIBUTIVE prefix at the head of a term and a VERB only
        #     after a complete noun. CN measurement: 神经 267, 已经 130,
        #     述经 110, 的经 98 - i.e. the participle reading dominates exactly
        #     as on TW.
        "经",
        # === R61 (2026-08-13) - TW R38 parity (reports #524/#526) ===
        # Both ship as the verb+CARDINAL collocation, never bare, matching the
        # 控制多个 / 传递一 class directly below.
        #   超过一 ("exceeds a"): latent-verified on the CN normalizer -
        #     对位温度差值超过一对位温 came back unchanged. 3 corpus occurrences.
        "超过一",
        #   借一 ("by means of a"): the instrumental coverb. Bare 借 is already a
        #     CN trailing strip; the interior form is a free parity add with 0
        #     corpus occurrences today, so it is a no-op that closes the gap
        #     before a CN draft hits it (the TW twin is report-evidenced).
        "借一",
        # === R57 (2026-07-23) - TW R32 parity (report #425, spec-support) ===
        # 控制多个 ("control multiple") - latent on CN (the Simplified analog
        # 预充电阶段控制多个 over-captures identically). Full verb+quantifier
        # collocation, never bare 控制 (noun-gray: 控制电路 / 控制器 /
        # 温度控制模块). FN-safe by construction.
        "控制多个",
        # === R54 (2026-07-18) - TW R29 parity (reports #394/#395/#396) ===
        # Interior counterparts of the R54 trailing strips; latent-verified.
        "随着", "满足下式", "满足下列", "满足以下", "满足如下",
        # R52 (2026-07-13) - TW R27 parity (report #356). 排成 ("arranged into"):
        # an INTERIOR cut, not a trailing strip, because the over-capture has a
        # real noun BEHIND the verb (一列, "a row") that the endswith pass can
        # never reach. Purely verbal - the arrangement nouns are 排列 / 阵列,
        # neither of which contains 排成 - so no compound-noun risk.
        "排成",
        "设有", "包含", "包括", "具有", "含有", "具备",
        "系为", "系于", "为", "是", "系",
        "所述", "前述", "该等", "该些",
        "传送接收到", "传送一显示影像资", "输出一解锁指令至",
        "通讯连接时", "电性连接", "被带动而向", "分别定义",
        "无法存取", "设置有", "拔除时",
        "连接一第一电子装", "撷取一使用者",
        "电性连", "所施予", "将带动", "被带动",
        "对应", "相对", "相反", "响应", "解锁",
        "读取", "写入", "计算", "处理", "感测",
        "侦测", "监控", "监测", "调整", "修改",
        "更新", "删除", "增加", "减少", "选择",
        "决定", "判别", "辨识", "驱动",
        "定义", "启始", "判断", "持续", "涵盖", "放大", "存取",
        "构成", "设置",
        "透过", "通过", "经由", "借由",
        "基于", "根据", "依据",
        "染色",
        "识别", "传送", "接收",
        "到", "形成", "锁合", "传输",
        "连接", "旋转", "带动", "筛选",
        "区分",
        "显示", "上传", "浏览",
        "产生", "各地",
        "依序",
        "相互", "朝向",
        # Stage 4 R2' D1a - 调出 cuts after 处理器指令 prefix (Huawei c3)
        "调出",
        # Phase 8c R8 - 进行 (carry out) appears mid-term in overcaptures
        # like 第一设备进行第一信号 → should split to 第一设备.
        "进行",
        # Phase 8c R12 - additional interior verb overcaptures
        "需要", "发出", "符合",
        # Phase 8c R23 - interior verb cuts from over_capture pool
        # (像素界定层限定有X, 处理单元周期性地或非周期, 滑块(230)可移动地设,
        # 初始地理预训练模型按照预, 处理器核运行客户端进程, 目标预训练模型采用预训练,
        # 实线边表征不同节点). Compound-noun risk audited per token.
        "限定有", "周期性地", "可移动地", "按照", "运行", "采用", "表征",
        # === Phase 8c R7-port (2026-04-30) - TW Round 7 cross-port ===
        # Process verbs that split mid-string captures cleanly in
        # semiconductor / mechanical claims. CN parity for the TW
        # additions in R7; same drafter conventions across jurisdictions.
        # Compound-noun risk: 夹持器/覆盖层/露出口 absent from CN corpus
        # per grep (verbs only, no compound-noun collision).
        "夹持", "覆盖", "露出",
        # R47 (2026-06-26): Simplified mirror of TW R17 (#289/#280) - the clause
        # verb bled into the captured 该<noun> reference. 贯穿/代入 are clean verbs;
        # 贯穿 is noun-suffix-guarded below (贯穿孔/贯穿部 compounds). 维持 (shipped
        # for TW) was WITHHELD for CN: validate_fix --juris CN caught it silencing
        # a gold-legit (`所述机械臂臂身维持期望构型` - the cut reveals 机械臂臂身,
        # a possessive/bare-noun gray-zone reference the gold treats as a real
        # defect). Attorney-over-corpus discipline: withhold on conflict.
        "贯穿", "代入",
        # CN R71 - 建立 ("establish") over-captured after a complete noun
        # phrase (所述外接装置建立数据链路). Noun-gray: it heads 建立模块 in the
        # corpus, so the cut is gated on _JIANLI_NOUN_HEADS_CN below.
        "建立",
    ),
    key=len,
    reverse=True,
))

# CN R71 - nouns 建立 heads as a compound (会话建立模块, RRC建立消息). The
# interior cut skips 建立 when one of these follows, so only the clause verb is
# cut. Measured over CN claims: 建立请求 30, 建立响应 21, 建立消息 15, 建立模块
# 10, 建立信令 2, 建立完成(消息) 2; the device-noun heads are the ones the R31
# guard protects.
_JIANLI_NOUN_HEADS_CN: tuple[str, ...] = (
    "请求", "响应", "消息", "模块", "信令", "完成",
    "单元", "器", "部", "电路", "装置", "程序", "组件",
)

# Stage 4 R2' D3 - 1-char noun prefixes get a relaxed position gate
# (>= 1 instead of > 1) so interior-verb cuts can fire at idx 1. Without
# this, captures like 边包括实线边 / L具有选自 can never be truncated.
_ONE_CHAR_NOUN_PREFIXES_CN: frozenset[str] = frozenset(
    {"边", "面", "体", "键", "L", "X", "Y", "Z", "M", "N", "R"}
)

# Interior-cut exception set - mechanical TC→SC swap per v2 swap table;
# compound-level re-seeding deferred to Stage 4.
_INTERIOR_CUT_EXCEPTIONS_CN: frozenset[str] = frozenset({
    "连接器", "连接部", "连接端口", "连接点", "连接线",
    "第一连接部", "第二连接部", "第三连接部",
    "电连接器", "电性连接部",
    "编码器", "解码器", "旋转编码器", "光学编码器",
    # R59 (2026-08-01) MEASURED AND WITHHELD alongside its TW twin - selector
    # compounds (选择器/数据选择器/多工器/选择电路/选择单元). 选择 is a
    # _INTERIOR_VERB_BOUNDARIES_CN member, so `数据选择器` (a real CNIPA
    # element name) is cut at its own noun head down to `数据` and a genuine
    # `所述数据选择器` defect can never fire. Found by the FN-direction parity
    # check, not by a report. Held for the same reason as TW - see the
    # corresponding block in tw_claims.py: the truncation fix has to ship
    # together with the bare-noun intro arm or it trades an invisible false
    # negative for visible false positives.
    "识别码", "识别资料", "识别信息", "识别号", "识别子",
    "通讯模块", "通讯端口", "通讯单元", "通讯接口",
    "行动通讯模块", "无线通讯模块", "有线通讯模块",
    "第一通讯模块", "第二通讯模块",
    "第一无线通讯模块", "第二无线通讯模块", "第三无线通讯模块",
    "传送器", "接收器", "发射器", "发送器", "收发器",
    "认证单元", "认证模块", "认证装置", "认证功能单元",
    "衔接部", "第一衔接部", "第二衔接部", "第三衔接部",
    "扣接部", "第一扣接部", "第二扣接部",
    "后轮", "前轮", "传动轮", "从动轮", "主动轮",
    "曲柄", "踏板", "弧面", "第一弧面", "第二弧面",
    "轮轴", "传动件",
    "上端边缘", "下端边缘", "外侧边缘", "内侧边缘",
    "容纳部", "容置部", "容置杯体", "杯体",
    "环形压接部", "压接部", "压接环",
    "开口部", "封闭部",
    "顶壁", "底壁", "侧壁", "顶部", "底部", "侧部",
    "数位内容", "适地性数位内容", "主题标签",
    "浏览程式", "伺服器", "用户界面",
    "放大器",
    "染色墨水",
    "带动轮",
    "显示器", "显示装置", "显示单元",
    "浏览器",
    "波产生器",
    "连接面", "第一连接面", "第二连接面",
    # Stage 4 R2' D1a - Huawei CN113939805B 处理器指令 compound
    "第一处理器指令", "第二处理器指令",
})


# ── Walker normalization functions ───────────────────────────────────────


# R63 (2026-08-17): parenthesized 附图标记 / gloss at the END of a term.
# Half-width AND full-width brackets - CN drafts use （） heavily and the
# pre-existing rule was half-width only, so `所述插头连接器（100）` was invisible
# to it. The unterminated form is matched too (capture stopped inside).
_TRAILING_PAREN_ANNOTATION_CN: re.Pattern[str] = re.compile(
    r"[(\uff08][^()\uff08\uff09]*(?:[)\uff09]|$)$"
)


# R63 (2026-08-17, #533/#535): CN mirror of _jing_cut_is_verbal_tw. Same two
# narrowings, both re-measured on the CN corpus: the participle reading sits at
# the HEAD of the term (after any determiner / quantifier / ordinal), and 神经
# ("nerve / neural", 267 occurrences) is the 经-final lexeme a position rule
# alone cannot save once it sits past the determiner (`所述第一神经网络模型`).
_JING_DETERMINER_PREFIXES_CN: tuple[str, ...] = (
    "所述的", "所述", "前述", "该等", "该些", "该", "一", "其", "此",
)
# 神 is the 经-final noun lexeme; 之 / 的 are GENITIVE PARTICLES, and a
# participle after one is attributive, modifying the head noun that follows
# (`…之間之經增強撓性區域` = "the enhanced-flexibility region between …"). Cutting
# there left the junk phrase 第二換能器之間之 and grew TW spec-support by 3 on
# TW202313138A - the SHARED cleaner is why Engine 2 sees it at all.
_JING_NOUN_FINAL_CHARS_CN: frozenset[str] = frozenset({"神"})
# GENITIVE PARTICLES reset the noun segment. `…之間之第一经增強撓性區域`
# ("the first enhanced-flexibility region between …") is one NP whose head
# noun starts after the last 之, so the participle test has to run on THAT
# segment - measured from the string start it saw 8 chars of "noun" in front
# of the 经 and cut, growing TW spec-support by 3 on TW202313138A (the
# SHARED cleaner is why Engine 2 sees this at all).
_JING_SEGMENT_RESET_CN: frozenset[str] = frozenset({"之", "的"})
# 经-INITIAL noun lexemes. The preceding-char guard catches 神经 but not a
# noun that STARTS with 经: `项目经理修改模块` ("project MANAGER module") was
# cut to 项目, which then registered as a spurious intro and resolved
# `所述项目状态` by prefix - silencing a REAL defect on CN111815283B c3. The
# verb reading is always followed by a process verb (经氫化 / 经量化 /
# 经壓縮 / 经由), so a closed noun set separates them cleanly.
_JING_NOUN_INITIAL_NEXT_CN: frozenset[str] = frozenset(
    "濟济理銷销驗验度緯纬費费營营典絡络"
)
# Ordinal OR bare cardinal+measure-word - both are head, not noun. Without
# the cardinal arm `所述至少约3个经突变的…` cut to 至少3个 on CN101622274A.
_JING_ORDINAL_RE_CN: re.Pattern[str] = re.compile(
    r"(?:第[一二三四五六七八九十百0-9]+"
    r"|(?:至少|至多|不超過|不超过)?(?:约|約|大约|大約)?[0-9一二三四五六七八九十百]+"
    r"(?:个|個|條|条|種|种|者|次|項|项)?)"
)


def _jing_cut_is_verbal_cn(text: str, pos: int) -> bool:
    """True iff the 经 at ``pos`` reads as a verb rather than a participle."""
    if text[pos - 1:pos] in _JING_NOUN_FINAL_CHARS_CN:
        return False
    if text[pos + 1:pos + 2] in _JING_NOUN_INITIAL_NEXT_CN:
        return False
    seg_start = 0
    for i in range(pos - 1, -1, -1):
        if text[i] in _JING_SEGMENT_RESET_CN:
            seg_start = i + 1
            break
    # Walk the LEADING FUNCTION-WORD ZONE - determiner, quantifier, ordinal and
    # coverb/connective prefix, in any order and any number - then require >= 2
    # chars of real noun in front of the 经. Doing this as one zone rather
    # than as a fixed prefix list is what keeps the two sides SYMMETRIC: the
    # reference `所述经X` and the intro `通过经X` /
    # `使得经X` / `多個经X` all put the participle at the
    # head of the noun, and a rule that saw only some of them cut the intro
    # while leaving the reference alone, manufacturing findings out of matched
    # pairs.
    head = seg_start
    for _ in range(6):
        before = head
        for prefix in _JING_DETERMINER_PREFIXES_CN:  # longest-first
            if text.startswith(prefix, head):
                head += len(prefix)
                break
        for quant in _LEADING_QUANTIFIER_DENYLIST_CN:  # longest-first
            if text.startswith(quant, head):
                head += len(quant)
                break
        for lead in _LEADING_VERB_PREFIXES_CN:  # longest-first
            if text.startswith(lead, head):
                head += len(lead)
                break
        m_ord = _JING_ORDINAL_RE_CN.match(text, head)
        if m_ord:
            head = m_ord.end()
        if head == before:
            break
    return (pos - head) >= 2


# Measurement hook (2026-10-06): called with (intro, reference_term, claim_id)
# whenever a reference resolves ONLY through the longest-intro-PREFIX fallback.
# None in production, so it costs one comparison. tests/eval/cn_short_stem_probe.py
# sets it to size the short-stem class the next CN round targets (a 2-char stem
# such as 电路 resolving 所述电路板). Never set it from shipped code.
_PREFIX_FALLBACK_OBSERVER = None

# Ruling R9 (Christopher 2026-10-26, TW and CN): 所述X含量 (the content of X)
# has no basis from an intro of X, unless 含量 is followed by a comparison that
# makes it context rather than the term (所述X含量大於5% says X's content
# exceeds 5%: basis from X). Same family as R8 (過程).
_CONTENT_COMPARISONS_CN: tuple[str, ...] = ("大于", "小于", "高于", "低于", "等于", "不大于", "不小于", "不超过", "不低于", "超过", "少于", "多于", "介于", "为", "是", "在", "达", "至少", "至多", "约", "≥", "≤", ">", "<", "=")


def _content_of_stem_cn(stem: str, reference: str, claim_text: str, ref_start: int) -> bool:
    if not reference.startswith(stem + "含量"):
        return False
    # Read the source: the capture can stop inside the comparison (大於 -> 大).
    i = claim_text.find(stem + "含量", ref_start)
    follow = claim_text[i + len(stem) + 2:].lstrip() if i >= 0 else reference[len(stem) + 2:]
    return not follow.startswith(_CONTENT_COMPARISONS_CN)



# Dev-time hook: called with (raw noun, normalized term, claim id) whenever a
# reference normalizes to one character and is dropped unchecked. Used by
# tests/eval/fn_mask_probe.py onechar, so the count follows the real walker.
_ONE_CHAR_DROP_OBSERVER = None


def _short_stem_opens_compound_cn(stem: str, reference: str) -> bool:
    """True when a 2-char prefix-fallback stem would resolve a DIFFERENT element.

    CN R72. The fallback resolves a reference by the longest introduction that
    is its prefix, which is right when the rest is an over-captured tail
    (所述支架设置 -> 支架) and wrong when the rest continues a noun: 电路 resolving
    所述电路板, 结合 resolving 所述结合点. With a two-character stem the next
    character decides it - a noun suffix makes the reference a longer compound
    naming another element, so the fallback must not silence it.

    Only the stem + ONE character shape: on a longer reference a suffix
    character often opens a verb or adverb instead (底座枢转, 基座线性平移,
    绕组组装), and guarding those re-fired gold walker FPs.

    A POSITIONAL suffix does not name another element: every element has a
    side, a face, an edge, a top and a bottom, so 所述凹部侧 keeps its basis in
    凹部 (the CN form of "the surface of X"). Guarding them manufactured two
    findings, one of them from the verb 面对 (所述边缘面对).
    """
    return (
        len(stem) == 2
        and len(reference) == 3
        and reference[2] in _F10_SINGLE_CHAR_SUFFIXES_CN
        and reference[2] not in _POSITIONAL_SUFFIXES_CN
    )


# CN R72: suffixes naming a location every element inherently has.
_POSITIONAL_SUFFIXES_CN: frozenset[str] = frozenset("侧面边顶底")


_REFERENCE_MARKERS_CN: tuple[str, ...] = ("所述", "该", "前述")


def _mentioned_before_cn(term: str, chain, claim, ref_start: int) -> bool:
    """True when ``term`` occurs earlier in the chain without a reference marker.

    CN R72. Such a mention (围绕副轴线旋转, 通过操作杆的操作) is an article-less
    introduction the gold accepts but no intro arm captures; a short stem had
    been covering it by accident, so the short-stem guard stands down there.
    """
    texts = [c.text for c in chain if c.id != claim.id] + [claim.text[:ref_start]]
    for text in texts:
        start = text.find(term)
        while start >= 0:
            if not text[:start].endswith(_REFERENCE_MARKERS_CN):
                return True
            start = text.find(term, start + 1)
    return False



# TW mirror: a change or motion verb before its directional complement 至 / 到
# and the complement's noun (该液位下降至一警戒值) is the predicate; the
# determiner (or the end of the capture) after 至 / 到 keeps 至少 / 至多 and noun
# pairs (第一表面到第二表面).
_PREDICATE_BEFORE_COMPLEMENT_RE_CN = re.compile(
    r"(?:进入|变化|下降|上升|返回|转变|升高|降低|移动|转动|旋转|滑动|转移|放电|突出|偏置|偏转|入射|插入|摆动|回到|退回|流动|流入|流向|升温|降温|扩散|收缩|膨胀)(?=[至到](?:该|所述|前述|一|第|其|$))"
)

# Wave E: 耦合 / 耦接 before 至 / 到 is the same predicate, and so is the manner
# adverb in front of it (電耦合至, 可操作地耦接至), which would otherwise be left
# on the name. Bare 光 is NOT an adverb here: 照射光 / 顯示光 are nouns.
_COUPLE_BEFORE_COMPLEMENT_RE_CN = re.compile(
    r"(?:电性|电容性|电容|电|光学|通信地|通讯地|可通信地|通信|通讯|可操作性地|可操作地|操作性地|操作上|直接|间接|机械地|机械|磁性|流体|可移除地|可拆卸地)?(?:耦合|耦接)(?=[至到](?:该|所述|前述|一|第|其|$|大于|小于|高于|低于|等于|[大小高低等]$))"
)
# 至少 / 至多 open a quantity; they never end a name.
_QUANTITY_OPENERS_CN: tuple[str, ...] = ("至少", "至多")


# Wave E (ruling R4, 2026-10-25): mirror of _IO_NOUN_RE_TW. A bare 输出 / 输入,
# optionally ordinal, is the element; the trailing 出 strip plus the 输 residue
# repair (or the interior 输出 cut after 第一) emptied it.
# Wave E - 包-final NOUN lexemes mined from CN references (所述碳质包 10,
# 所述封包 9, 所述电池包, 所述中空包, 所述第二包).
_BAO_FINAL_NOUNS_CN: tuple[str, ...] = ("封包", "电池包", "数据包", "资料包", "碳质包", "中空包")
_ORDINAL_BAO_RE_CN: re.Pattern[str] = re.compile(r"第[一二三四五六七八九十0-9]+包")


_IO_NOUN_RE_CN: re.Pattern[str] = re.compile(
    r'(?:一|第[一二三四五六七八九十百0-9]+)?输[出入](?:连接|旋转)?'
)
_IO_SET_AS_RE_CN: re.Pattern[str] = re.compile(
    r'((?:一|第[一二三四五六七八九十百0-9]+)?输[出入])(?:设定|设置)[为成]'
)


def clean_noun_phrase_cn(
    text: str, *, protect_tail_compounds: bool = False, quantifier_lead: int = 0
) -> str:
    """Strip trailing verbs and conjunction fragments from a CN reference term.

    Two-phase cleanup mirroring ``clean_noun_phrase_tw``:
      1. Interior-verb truncation with prefix-aware exception protection.
      2. Trailing-verb stripping (iterative, with residual guards).

    See tw_claims.py::clean_noun_phrase_tw for the full rationale.

    ``protect_tail_compounds`` (CN R71) skips an interior cut whose verb heads
    a declared compound (连接 in 电脑连接器) and retries the verb behind it -
    the TW R27 + R43 guard. It is OFF on every in-place path: the CN capture
    still admits refnum parens and trailing verbs that the cut has been
    collecting, so protecting in place exposes them. The walker uses it only
    in the last-resort exact-match tier (see check_antecedent_basis_cn).
    """
    # Wave F: callers outside the normalizers (Markush / supplementary intro
    # arms) reach the cleaner with the quantifier still on.
    # The stripped quantifier still counts toward the interior-cut position floor
    # (see the TW twin).
    text, lead = _pre_clean_quantifier_strip_cn(text)
    lead = lead or quantifier_lead
    if not text or _IO_NOUN_RE_CN.fullmatch(text):
        return text
    m_set = _IO_SET_AS_RE_CN.match(text)
    if m_set:
        return m_set.group(1)

    def _longest_protected_prefix(s: str) -> int:
        for i in range(len(s), 1, -1):
            if s[:i] in _INTERIOR_CUT_EXCEPTIONS_CN:
                return i
        return 0

    protected_prefix_len = _longest_protected_prefix(text)
    search_text = text[protected_prefix_len:]
    search_offset = protected_prefix_len

    # Stage 4 R2' D3 (ADR-112): 1-char noun prefixes (边/L/etc.) relax the
    # position gate from > 1 to >= 1 so interior-verb cuts at idx 1 can
    # fire. Without this, a capture like 边包括实线边 cannot be truncated
    # because 包括 sits at idx 1 and the original gate blocks it.
    is_one_char_noun_prefix = (
        len(text) > 0
        and text[0] in _ONE_CHAR_NOUN_PREFIXES_CN
        and protected_prefix_len == 0
    )
    min_absolute_idx = max(1, (1 if is_one_char_noun_prefix else 2) - lead)

    # R31 (2026-05-03) tight noun-suffix guard for compound nouns where
    # the verb is part of a real noun compound (verb + noun-suffix). Mirror
    # of TW R31. Restricted by:
    #   1. verb in high-collision whitelist (decision/sense/identify class)
    #   2. char immediately after verb is a noun-suffix
    #   3. TOTAL TEXT LENGTH ≤ 8 chars (typical compound noun max)
    _R31_NOUN_COMPOUND_VERBS_CN = {
        '决定', '感测', '侦测', '监测', '辨识', '识别', '解析',
        '处理', '控制', '驱动', '检出', '判定', '计算', '生成',
        '输出', '输入', '存储', '存取', '读取', '写入',
        # R47 (2026-06-26): 贯穿 forms 贯穿孔 (through-hole) / 贯穿部 - the verb is
        # part of the element. Guarded so 该第二贯穿孔 is NOT cut to 第二 (TW R17
        # parity). The over-capture 该第一切槽贯穿 has no suffix after 贯穿 → cuts.
        '贯穿',
    }
    earliest_idx: int | None = None
    for verb in _INTERIOR_VERB_BOUNDARIES_CN:
        idx = search_text.find(verb)
        # CN R70 (mirror of TW R62): 并 heading a closed compound (并联/并排/...)
        # is noun-internal, so retry the NEXT 并 rather than abandoning the verb.
        # 并入 ("merge into", 64 corpus occurrences) is deliberately NOT guarded:
        # it is a verb, and cutting at it is correct.
        while idx >= 0:
            if (verb == "并"
                    and (text[idx + search_offset + 1:idx + search_offset + 2]
                         in _BING_COMPOUND_SECONDS_CN
                         or _bing_is_ring_fusion_cn(text, idx + search_offset))):
                idx = search_text.find(verb, idx + 1)
                continue
            if protect_tail_compounds:
                protected_len = _longest_protected_prefix(text[idx + search_offset:])
                if protected_len:
                    idx = search_text.find(verb, idx + protected_len)
                    continue
            break
        if idx >= 0 and (idx + search_offset) >= min_absolute_idx:
            absolute_idx = idx + search_offset
            # CN R70: cut BEFORE the adverb head of 从而 (311) / 进而 (26) /
            # 因而 / 然而 / 反而 / 继而, or the head is stranded on the noun.
            if verb == "而" and text[absolute_idx - 1] in _ER_ADVERB_HEADS_CN:
                if absolute_idx - 1 < max(min_absolute_idx, 2):
                    continue
                absolute_idx -= 1
            # #349 CN parity (mirror of TW): an interior verb immediately
            # followed by the device-noun 天线 is a noun-modifier of an antenna
            # compound (发射接收天线 / 接收天线 / 传送天线), not a clause boundary.
            # FN-safe: 天线 is unambiguously a noun head; the over-capture case
            # never has 天线 as the verb's next token. Prevents the truncation
            # 发射接收天线 -> 发射. No CN report - free TW->CN parity (DR-1 exempt:
            # identical structural bug on the shared normalizer design).
            if text[absolute_idx + len(verb):].startswith("天线"):
                continue
            # 输出旋转 / 输入旋转: "output rotation", one name (wave E).
            if verb == "旋转" and _IO_NOUN_RE_CN.fullmatch(text[:absolute_idx]):
                continue
            # 输出连接处 / 输入连接处: the connection point, a noun: cut at the locative instead (wave E).
            if (verb == "连接" and text[absolute_idx + 2:absolute_idx + 3] == "处"
                    and text[:absolute_idx].endswith(("输出", "输入"))):
                if earliest_idx is None or absolute_idx + 2 < earliest_idx:
                    earliest_idx = absolute_idx + 2
                continue
            if verb == "建立" and text[absolute_idx + 2:].startswith(_JIANLI_NOUN_HEADS_CN):
                continue
            # R63 (2026-08-17): 经 position guard - see _jing_cut_is_verbal_cn.
            if verb == "经" and not _jing_cut_is_verbal_cn(text, absolute_idx):
                continue
            # R52 (2026-07-13) - the TW R27 tail-compound guard (reports
            # #352/#353) was TRIALED HERE AND WITHHELD. It is genuinely latent on
            # CN (clean_noun_phrase_cn('对接连接器') -> '对接' truncates exactly as
            # TW did), but MEASURED on the CN corpus it is net-harmful: on
            # CN120359669A it correctly retires 6 truncation artifacts
            # (所述插头 / 所述插座, which exist nowhere in the draft - the real
            # references are 所述插头连接器 / 所述插座连接器) but ADDS 8 findings,
            # several malformed: 所述插头连接器(100)从插 and 所述插座连接器(200)移除.
            # Root cause: the CN noun capture admits the parenthesized reference
            # numeral and does not treat 从 as a boundary char (TW's _NOUN_CHARS
            # excludes 從), so the interior cut at 连接 had been silently acting as
            # a garbage collector for a capture-side defect. Removing the cut
            # exposes it, trading 6 artifact findings for new FPs - so the CN
            # mirror is BLOCKED ON a capture-side fix (strip the trailing
            # refnum-paren + add the 从 boundary), not on this guard. TW ships
            # alone; the CN capture fix is the tracked follow-up.
            pass
            # R31 noun-compound guard (length-bounded): skip cut if verb is
            # in whitelist, char after is noun-suffix, total len ≤ 8.
            if (verb in _R31_NOUN_COMPOUND_VERBS_CN
                    and len(text) <= 8):
                next_char_pos = absolute_idx + len(verb)
                if (next_char_pos < len(text)
                        and text[next_char_pos] in _F10_SINGLE_CHAR_SUFFIXES_CN):
                    continue  # 对象决定+部 etc. (text length ≤ 8)
            if earliest_idx is None or absolute_idx < earliest_idx:
                earliest_idx = absolute_idx

    # #339 CN parity (mirror of the TW 区分别 别-gate) - 区分别 is 区 (region-noun
    # suffix, 源极区/漏极区) + 分别 ("respectively"), NOT the verb 区分. Shift the
    # cut one char right so the region-noun 区 survives (第一源极区分别 →
    # 第一源极区). The genuine verb case 该地域区分 (no trailing 别) still cuts to 地域.
    if (earliest_idx is not None
            and text[earliest_idx:earliest_idx + 2] == "区分"
            and text[earliest_idx + 2:earliest_idx + 3] == "别"):
        earliest_idx += 1

    current = text[:earliest_idx] if earliest_idx is not None else text

    m_pred = _PREDICATE_BEFORE_COMPLEMENT_RE_CN.search(text)
    if m_pred and 2 <= m_pred.start() < len(current):
        current = text[:m_pred.start()]
    m_pred = _COUPLE_BEFORE_COMPLEMENT_RE_CN.search(text)
    if m_pred and 2 <= m_pred.start() < len(current):
        current = text[:m_pred.start()]

    for _ in range(16):
        if _IO_NOUN_RE_CN.fullmatch(current):
            break
        stripped = False
        for verb in _TRAILING_VERB_DENYLIST_CN:
            if not current.endswith(verb):
                continue
            if len(current) <= len(verb):
                continue
            # WS-B1: 向 binds as a noun suffix in direction nouns (方向/轴向/…).
            if verb == "向" and current[-2] in _DIRECTION_STEM_BEFORE_XIANG_CN:
                continue
            # R53 (2026-07-13) - noun-compound guard for the trailing 匹配.
            # The bare 匹配 strip is LOAD-BEARING (it is what recovers 策略 from
            # the very common 与…相匹配 predicate: 所述策略相匹配 -> 策略, gold-legit
            # on CN105354747B c18/c45 - removing it was trialed this round and
            # measured net-harmful, re-introducing the 策略相匹配 over-capture).
            # But as an UNCONDITIONAL endswith strip it was also a latent FALSE
            # NEGATIVE that predates this round: 阻抗匹配 ("impedance matching") is
            # a real element name in RF drafts, so a genuine 所述阻抗匹配 antecedent
            # defect was truncated to 阻抗 and could never be flagged. Guarding the
            # noun compound keeps the predicate strip while closing the FN. TW never
            # carried a bare 匹配 entry, so it has no equivalent exposure - the
            # standing cross-jurisdiction parity check is what surfaced this.
            if verb == "匹配" and current in _MATCH_NOUN_COMPOUNDS_CN:
                continue
            # R61 (2026-08-13) - mirror of the TW R38 给 lexeme guard.
            if verb == "给" and (
                current.endswith(_GEI_FINAL_NOUNS_CN) or (len(current) - 1) < 2
            ):
                continue
            # R63 (2026-08-17) - mirror of the TW R41 属 lexeme guard.
            if verb == "属" and (
                current.endswith(_SHU_FINAL_NOUNS_CN) or (len(current) - 1) < 3
            ):
                continue
            # CN R68 - noun-compound guard for the trailing 位.
            # See _WEI_NOUN_COMPOUNDS_CN: the bare strip was a latent FN
            # held back only by a residual-length heuristic.
            if verb == "位" and current.endswith(_WEI_NOUN_COMPOUNDS_CN):
                continue
            # Wave E (TW mirror): 包-final element names and 比较.
            if verb == "包" and (current.endswith(_BAO_FINAL_NOUNS_CN)
                                or _ORDINAL_BAO_RE_CN.fullmatch(current)):
                continue
            if verb == "较" and current.endswith("比较"):
                continue
            if verb == "下" and current[-2:-1] in _XIA_WORD_HEADS_CN:
                continue  # 如下 / 以下 / 向下 / 按下: 下 is part of a word
            if verb in _NOUNLIKE_SINGLE_CHAR_SUFFIXES_CN:
                if verb in _NOUNLIKE_VERY_RELAXED_SUFFIXES_CN:
                    min_residual = 1
                elif verb in _NOUNLIKE_RELAXED_SUFFIXES_CN:
                    min_residual = 2
                else:
                    min_residual = 3
                if (len(current) - len(verb)) < min_residual:
                    continue
            current = current[: -len(verb)]
            stripped = True
            break
        if not stripped:
            break

    # Phase 8c R10 - char-exclusion residue repair.
    # _NOUN_CHARS_CN excludes 于/能/应 etc., leaving half-compound residues
    # at the end of captured terms (e.g., 第一设备基 from 基于, 第一功 from
    # 功能, 第N响 from 响应).  Strip the residue char when it is NOT part
    # of a legitimate chemistry suffix (培养基, 酸解离性基, 碱基 …).
    if len(current) >= 3 and current[-1] in _CHAR_EXCLUSION_RESIDUE_CN:
        guard = _CHAR_EXCLUSION_RESIDUE_CN[current[-1]]
        if len(current) - 1 >= guard:
            if current[-1] != '\u57fa' or current[-2] not in _CHEMISTRY_BEFORE_JI_CN:
                current = current[:-1]

    # R54 (2026-05-05): regex-based verb-phrase trailing strip.
    # Catches over-capture patterns the literal allowlist doesn't cover:
    #   `\u9501\u626d\u6574\u4f53\u5448\u5706\u67f1\u5f62` \u2192 `\u9501\u626d` (\u6574\u4f53\u5448X = "overall is X" descriptor)
    #   `\u7ea4\u7ef4\u6750\u6599\u8f74\u5411\u5730\u6392\u5217` \u2192 `\u7ea4\u7ef4\u6750\u6599` (XY\u5730ZW = adverbial-verb suffix)
    # Both confirmed walker over-capture per user 2026-05-05 phone-judge
    # (CN103443870A c19, CN106654630B c10).
    #
    # Adverbial regex constrains the pre-\u5730 portion to 2-3 chars (typical
    # CN adverbials: \u8f74\u5411, \u5e73\u7a33, \u5782\u76f4, \u81ea\u52a8). Wider {1,4} bracket consumed
    # head-noun chars greedily (`\u7ea4\u7ef4\u6750\u6599\u8f74\u5411\u5730\u6392\u5217` \u2192 `\u7ea4\u7ef4`); narrower
    # {2,3} leaves head noun intact (`\u7ea4\u7ef4\u6750\u6599`).
    #
    # Verb portion 1-3 chars (\u6392\u5217, \u8fd0\u52a8, \u5f62\u6210).
    # Head-noun group \u22652 chars (residual guard).
    _R54_OVERALL_DESC = re.compile(
        r'^([\u4e00-\u9fff]{2,})\u6574\u4f53\u5448[\u4e00-\u9fff]{1,8}$'
    )
    _R54_ADVERBIAL_VERB = re.compile(
        r'^([\u4e00-\u9fff]{2,})[\u4e00-\u9fff]{2,3}\u5730[\u4e00-\u9fff]{1,3}$'
    )
    for _ in range(4):
        before = current
        m = _R54_OVERALL_DESC.match(current)
        if m:
            current = m.group(1)
        m = _R54_ADVERBIAL_VERB.match(current)
        if m:
            current = m.group(1)
        if current == before:
            break

    # After R54, so an adverb + 地 run still reduces through that rule first.
    if current.endswith(_QUANTITY_OPENERS_CN) and len(current) >= 4:
        current = current[:-2]

    return current


# R32 (2026-05-04): regex-based at-least-N strip + 其-possessive strip
# (CN parity with TW R32). Existing _LEADING_QUANTIFIER_DENYLIST_CN
# covers 至少一/至少一个/至少两/至少两个 only; 至少三个X / 至少100个X
# stranded. 其X (its X) possessive captured by F-anchor patterns when
# the canonical intro is bare X (introduced as feature of prior subject).
_AT_LEAST_N_PREFIX_RE_CN: re.Pattern[str] = re.compile(
    r'^至少[一二三四五六七八九十百0-9]+个'
)
_POSSESSIVE_其_PREFIX_RE_CN: re.Pattern[str] = re.compile(
    r'^其(?=[一-鿿]{2,})'
)


# R32 (2026-05-04): leading conjunction-residue strip. CN drafters use
# `和/或X` (and/or X) constructions in lists. Walker captures `/或X` as
# leading residue when the conjunction-split mechanism fails on the
# slash. Empirical: `/或第二功能模块` from CN115485995B c12 spec-support FP
# where canonical intro is `第二功能模块`.
_LEADING_CONJ_RESIDUE_RE_CN: re.Pattern[str] = re.compile(
    r'^(?:/或|/和|和/或|或/|/)'
)


_DUI_LEXEME_SECONDS_CN: frozenset[str] = frozenset("称象话")

# CN R70: second characters that make a leading 并 part of a WORD. Mined from
# the CN corpus (6,489 并X bigrams): 并联 81, 并行 31, plus the closed
# parallel/juxtaposition family. 并且 (4,328), 并将, 并在, 并入 open predicates.
_BING_COMPOUND_SECONDS_CN: frozenset[str] = frozenset("联列排行接存置网")

# CN R72: in chemical nomenclature 并 is the ring-FUSION infix, not "and":
# 二苯并[1,4]二噁英, 吡啶并[2,3-d], 苯并咪唑. Mined from the CN corpus (6,492 并):
# the fused reading is always preceded by a ring-name character or followed by
# a fusion locant `[` (32), and the conjunction is never followed by `[`.
_RING_FUSION_HEADS_CN: frozenset[str] = frozenset("苯唑啶嗪吩喃咯萘喹嘧吲")


def _bing_is_ring_fusion_cn(text: str, pos: int) -> bool:
    """True when the 并 at ``pos`` fuses two ring names rather than two clauses."""
    return (
        (pos > 0 and text[pos - 1] in _RING_FUSION_HEADS_CN)
        or text[pos + 1:pos + 2] == "["
    )

# CN R70: first characters of the connective adverbs ending in 而 (从而 311,
# 进而 26, plus 因而/然而/反而/继而).
_ER_ADVERB_HEADS_CN: frozenset[str] = frozenset("进从因然反继")



def _yidui_is_noun_initial_dui_cn(text: str, source_text: str) -> bool:
    """CN mirror of ``_yidui_is_noun_initial_dui`` (CN R62 / TW R39, #527).

    ``一对`` is registered as an intro measure word ("a pair of"), so the
    pattern splits ``一对位温度差值`` as 一对 + 位温度差值 when the drafter meant
    一 + 对位温度差值. Reproduced on the CN normalizer before mirroring, per the
    standing cross-jurisdiction duty - CN is if anything MORE exposed than TW,
    because 对 opens two of the highest-frequency lexemes in CNIPA claim
    register (对象 "object", 对应 "corresponding"), so ``一对象…`` and
    ``一对应…`` hit the identical false split.

    Gate: the drafter's own definite reference form. 该 is excluded for the
    same measured reason as TW's 該 - it is the idiomatic anaphor for "that
    PAIR of X" and admitting it manufactured 16 findings on TWI861425B.
    """
    if not text.startswith("一对") or len(text) <= 2:
        return False
    residual = text[2:]
    # CN R70 mirror of TW R62: 对-initial lexemes in which 对 cannot be the
    # measure word (对称 symmetric, 对象 object, 对话 dialog). Not 对数
    # (`一对数值` is "a pair of values"), 对角 or 对立.
    if text[2] in _DUI_LEXEME_SECONDS_CN:
        return True
    if not source_text:
        return False
    return any(
        f"{prefix}对{residual}" in source_text
        for prefix in ("所述", "前述")
    )


def strip_leading_quantifier_cn(text: str) -> str:
    """Strip one matching leading quantifier (ADR-095 Rule 2).

    R32 (2026-05-04): regex-based 至少N个 strip applied first; 其-possessive
    strip applied last with ≥2 CJK lookahead so 其余 (2 chars) is protected.
    """
    if not text:
        return text
    # R32: leading conjunction residue (`/或`, `和/或`) strip
    m = _LEADING_CONJ_RESIDUE_RE_CN.match(text)
    if m and len(text) - m.end() >= 2:
        text = text[m.end():]
    m = _AT_LEAST_N_PREFIX_RE_CN.match(text)
    if m and len(text) - m.end() >= 2:
        text = text[m.end():]
    for q in _LEADING_QUANTIFIER_DENYLIST_CN:
        if text.startswith(q) and len(text) > len(q):
            text = text[len(q):]
            break
    m = _POSSESSIVE_其_PREFIX_RE_CN.match(text)
    if m:
        text = text[m.end():]
    return text


def strip_reference_form_prefix_cn(text: str) -> str:
    """Strip one matching reference-form prefix (该/所述/前述)."""
    if not text:
        return text
    for prefix in _REFERENCE_FORM_PREFIXES_CN:
        if text.startswith(prefix) and len(text) > len(prefix):
            return text[len(prefix):]
    return text


# Leading qualifier strip (relational + position qualifiers with
# quantifier lookahead). See tw_claims.py lines 1580-1666 for rationale.
_LEADING_RELATIONAL_QUALIFIERS_CN: tuple[str, ...] = (
    "对应地", "对应的", "对应",
    "相应地", "相应的", "相应",
    "相对地", "相对的", "相对",
    "相关地", "相关的", "相关",
)

_LEADING_POSITION_QUALIFIERS_CN: tuple[str, ...] = ("前", "后")
_QUANTIFIER_AFTER_POSITION_CN: tuple[str, ...] = (
    "一或多个",
    "一", "二", "三", "四", "五", "六", "七", "八", "九", "十",
    "1", "2", "3", "4", "5", "6", "7", "8", "9",
    "复数", "多个", "数个", "至少",
)


def strip_leading_qualifier_cn(
    text: str,
    *,
    strict_qualifier_matching: bool = False,
) -> str:
    """Strip leading qualifier modifiers from a normalized reference term.

    Relational qualifiers stripped unconditionally; position qualifiers
    (前/后) only when followed by a quantifier. Strict mode disables
    the strip entirely. See tw_claims.py::strip_leading_qualifier.
    """
    if strict_qualifier_matching or not text:
        return text

    for q in _LEADING_RELATIONAL_QUALIFIERS_CN:
        if text.startswith(q) and len(text) > len(q):
            return text[len(q):]

    for q in _LEADING_POSITION_QUALIFIERS_CN:
        if text.startswith(q) and len(text) > len(q):
            remainder = text[len(q):]
            for quant in _QUANTIFIER_AFTER_POSITION_CN:
                if remainder.startswith(quant):
                    return remainder

    return text


def normalize_reference_term_cn(
    text: str,
    *,
    strict_qualifier_matching: bool = False,
    protect_tail_compounds: bool = False,
) -> str:
    """Normalize a flagged reference term for antecedent matching.

    R7 (2026-04-30): + strip_leading_verb_cn for `所述形成p型源极／漏极`
    style references that carry a leading verb prefix (符号见 ADR-095
    addendum / TW R7 commit).

    R33 (2026-05-04): + normalize_arabic_ordinal_to_cjk at the head so
    JP-translated drafts using `第1` / `第2` collapse with canonical
    `第一` / `第二` intros for matching purposes.
    """
    t = normalize_arabic_ordinal_to_cjk(text)
    t = strip_reference_form_prefix_cn(t)
    t, pre_stripped = _pre_clean_quantifier_strip_cn(t)
    t = strip_leading_qualifier_cn(t, strict_qualifier_matching=strict_qualifier_matching)
    pre_stripped = pre_stripped or _pre_clean_quantifier_strip_cn(t)[1]
    t = clean_noun_phrase_cn(
        t, protect_tail_compounds=protect_tail_compounds, quantifier_lead=pre_stripped
    )
    if not pre_stripped:
        t = strip_leading_quantifier_cn(t)
    t = strip_leading_verb_cn(t)
    # R31 (2026-05-03): re-run reference-prefix strip after verb strip,
    # because the new 有 prefix entry can expose a hidden 所述/该/前述
    # underneath (e.g., 有所述高亮度区域 → 所述高亮度区域 after 有 strip
    # → 高亮度区域 after re-prefix-strip). Without this, spec_support
    # mid-phrase recovery test failed.
    t = strip_reference_form_prefix_cn(t)
    t = strip_leading_qualifier_cn(t, strict_qualifier_matching=strict_qualifier_matching)
    return t


def normalize_candidate_intro_cn(
    text: str,
    *,
    strict_qualifier_matching: bool = False,
) -> str:
    """Normalize an introduction candidate for antecedent matching.

    Symmetric with normalize_reference_term_cn per ADR-098; the trailing
    strip_reference_form_prefix_cn is load-bearing for intros where
    the _INTRO_PATTERN_CN captures a reference-prefix artifact as part
    of the bare noun group.
    """
    t = normalize_arabic_ordinal_to_cjk(text)
    t, pre_stripped = _pre_clean_quantifier_strip_cn(t)
    t = strip_leading_qualifier_cn(t, strict_qualifier_matching=strict_qualifier_matching)
    pre_stripped = pre_stripped or _pre_clean_quantifier_strip_cn(t)[1]
    t = clean_noun_phrase_cn(t, quantifier_lead=pre_stripped)
    if not pre_stripped:
        t = strip_leading_quantifier_cn(t)
    t = strip_reference_form_prefix_cn(t)
    t = strip_leading_verb_cn(t)
    # #245 mirror (TW R14 → CN): strip an inline English-word parenthetical gloss
    # that bled into the captured intro (`一中介片（interposer）` → `中介片（interpos`),
    # so it matches the bare reference `所述中介片`. INTRO SIDE ONLY (the reference
    # normalize keeps the paren) so gloss-bearing abbreviations whose abbreviation
    # IS the element identity keep their own intro requirement. ≥3 pure letters so
    # designators `（A1）` / reference numerals `（10）` are preserved; closing paren
    # optional for the _INTRO_PATTERN-truncated tail. FN-guarded on the CN corpus.
    t = re.sub(r"[(（][A-Za-z]{3,}(?:[)）]|$)", "", t)
    return t


def detect_plural_reference_cn(text: str) -> bool:
    """Return True iff text starts with a plural reference-form prefix."""
    return any(text.startswith(p) for p in _PLURAL_REFERENCE_PREFIXES_CN)


def get_ancestor_chain_cn(claim: Claim, all_claims: list[Claim]) -> list[Claim]:
    """Return [claim, ...ancestors] walking the full multi-parent BFS.

    Per ADR-092, the walker uses the FULL ancestor chain. Stage 1.5
    invariant: trusts ``parse_cn_claims_docx`` dependency shape verbatim
    no self-ref stripping, no spec expansion. Both already handled
    upstream at claims_cn.py:40-59 and claims_cn.py:90.
    """
    claims_by_id = {c.id: c for c in all_claims}
    chain: list[Claim] = [claim]
    visited: set[int] = {claim.id}
    # Chain uses dependencies ONLY. Claim.quoted_references is populated
    # by the parser for body cross-refs (`如权利要求N所述的X`) but extending
    # the chain blanket-grants antecedent for ALL of claim N's intros -
    # broader than CNIPA 审查指南 § 3.3 cross-reference doctrine, which
    # says the body cross-ref provides antecedent only for the named
    # element X. Element-scoped chain traversal is a future ADR.
    # See analysis/claims.py:_chain - same design choice.
    queue: list[int] = list(claim.dependencies)
    while queue:
        parent_id = queue.pop(0)
        if parent_id in visited:
            continue
        visited.add(parent_id)
        parent = claims_by_id.get(parent_id)
        if parent is None:
            continue
        chain.append(parent)
        queue.extend(parent.dependencies)
    return chain


# Q4 (defensive): 独 added to the CN predecessor set. Confirm in Stage 4
# corpus tuning whether it surfaces 独一X patterns as word-internal.
_WORD_INTERNAL_YI_PREDECESSORS_CN = frozenset("第另任某唯同单统独")


def _yi_is_word_internal_cn(text: str, idx: int) -> bool:
    """CN R70 mirror of ``_yi_is_word_internal_tw`` (TW R62, reports #784/#787/#788).

    The 一 of the adverb 进一步 ("further") is not an article. Checked as the
    LEXEME, never as a bare 进 predecessor (`前进一段距离` has a real article).
    Present in CN at volume before mirroring: 772 intro matches started on it.
    """
    if idx <= 0 or text[idx] != "一":
        return False
    if text[idx - 1] in _WORD_INTERNAL_YI_PREDECESSORS_CN:
        return True
    return text[idx - 1] == "进" and text[idx + 1:idx + 2] == "步"

_SPLIT_YI_NOUN_RE_CN = re.compile(r"一(" + _NOUN_CHARS_CN + r")")


def _postprocess_intro_capture_cn(
    bare_noun: str,
    match: re.Match,  # type: ignore[type-arg]
    claim_text: str,
) -> list[str]:
    """Post-process a greedy _INTRO_PATTERN_CN capture to repair over-captures.

    Same three-rule repair pipeline as the TW walker's
    ``_postprocess_intro_capture``: ref-marker check + truncation,
    embedded 一 splitting, re-scan for discarded spans.
    """
    # Rule 1a
    for prefix in _REFERENCE_FORM_PREFIXES_CN:
        if bare_noun.startswith(prefix):
            recovered = _rescan_for_yi_cn(
                match.group(0), match.start(), claim_text,
            )
            if recovered:
                return recovered
            remainder = bare_noun[len(prefix):]
            return [remainder] if remainder else []

    # Rule 1b
    for prefix in _REFERENCE_FORM_PREFIXES_CN:
        idx = bare_noun.find(prefix)
        if idx > 0:
            bare_noun = bare_noun[:idx]
            break

    # Rule 2: embedded 一 splitting
    candidates: list[str] = []
    yi_positions = [i for i, ch in enumerate(bare_noun) if ch == "一" and i > 0]

    if not yi_positions:
        return [bare_noun]

    split_pos: int | None = None
    for pos in yi_positions:
        if not _yi_is_word_internal_cn(bare_noun, pos):
            split_pos = pos
            break

    if split_pos is None:
        return [bare_noun]

    leading_part = bare_noun[:split_pos]
    if leading_part:
        candidates.append(leading_part)

    abs_start = match.start() + (len(match.group(0)) - len(match.group(1))) + split_pos
    remaining_text = claim_text[abs_start:]
    yi_match = _SPLIT_YI_NOUN_RE_CN.match(remaining_text)
    if yi_match:
        candidates.append(yi_match.group(1))
    elif split_pos + 1 < len(bare_noun):
        candidates.append(bare_noun[split_pos + 1:])

    return candidates


def _rescan_for_yi_cn(
    full_span: str,
    span_start: int,
    claim_text: str,
) -> list[str]:
    """Re-scan a full matched span for 一 intro sites."""
    candidates: list[str] = []
    for i, ch in enumerate(full_span):
        if ch != "一":
            continue
        if i == 0:
            continue
        if _yi_is_word_internal_cn(full_span, i):
            continue
        abs_pos = span_start + i
        remaining = claim_text[abs_pos:]
        yi_match = _SPLIT_YI_NOUN_RE_CN.match(remaining)
        if yi_match:
            candidates.append(yi_match.group(1))
    return candidates


# ── Supplementary bare-noun intro patterns (F5/F6/F7b/F7c/F7d/F11/F12/F13) ─
#
# F7a/F8/F9 removed 2026-04-16: the R14 investigation confirmed zero matches
# across the 10-fixture corpus. Their shapes (形成于X的Y, 相配合的Y, 透过Y连接)
# are TW-specific drafting patterns; CN tends toward 位于/设于 (now covered
# by F13) and 包括/包含 (covered by F11). If future fixtures surface any of
# these shapes, re-add with empirical grounding.

# CJK char class excluding 的 (U+7684); jurisdiction-invariant.
_CJK_NO_DE_CN = r'[\u4e00-\u7683\u7685-\u9fff]'

# CN R70: the "further comprising" idiom that opens an article-less element in
# a dependent claim.
_JINYIBU_INTRO_RE_CN: re.Pattern[str] = re.compile(
    r'进一步(?:包含|包括|具有|含有|具备|设有|设置有)'
    r'(' + _CJK_NO_DE_CN + r'{2,12})'
)

# F6-specific: also excludes 之 (U+4E4B) to prevent captures extending into
# temporal markers like 之后/之前. Removes the need for (?![的之]) lookahead
# which caused backtracking truncation before 的.
_CJK_NO_DE_ZHI_CN = r'[\u4e00-\u4e4a\u4e4c-\u7683\u7685-\u9fff]'

_PARTICIPIAL_YI_DE_PATTERN_CN = re.compile(
    r'一[\u4e00-\u9fff]+?的(' + _CJK_NO_DE_CN + r'{2,}(?:\([A-Za-z0-9]+\))?)'
)

_POST_DE_ORDINAL_PATTERN_CN = re.compile(
    r'的(第[一二三四五六七八九十\d]+' + _CJK_NO_DE_CN + r'+(?:\([A-Za-z0-9]+\))?)'
)

# R58 (2026-07-23) - TW R33 parity. Article-less introduction via a PLATING verb
# 镀(有) + ordinal noun (`所述第一背面上镀有第一底部铜层`). Latent-verified on CN
# (the Simplified analog fires identically). 镀 is noun-gray (镀层/镀膜 are nouns),
# so it cannot go in _F6_VERB_ALT_CN; this dedicated pattern is gated on the
# ordinal 第N (the first-mention signal), never a bare NP.
_PLATING_ORDINAL_INTRO_CN = re.compile(
    r'(?:镀有|镀)'
    r'(第[一二三四五六七八九十\d]+' + _CJK_NO_DE_CN + r'+(?:\([A-Za-z0-9]+\))?)'
    r'(?![的之])'
)
_PLATING_ORDINAL_TAIL_CN = re.compile(
    r'镀(?:有)?(第[一二三四五六七八九十\d]+' + _CJK_NO_DE_CN + r'+)$'
)


def _strip_plating_prefix_cn(noun: str) -> str:
    m = _PLATING_ORDINAL_TAIL_CN.search(noun)
    return m.group(1) if m else noun

# Phase 8c R14c.2 - F6 bare-noun relax.
# Adds a third capture arm: bare NP (≥3 CJK chars, no ordinal, no paren).
# Gated by:
#   - negative lookahead against _F12_ADJ_REJECTS_CN (rejects predicate-
#     adjective / verb-phrase heads like 经/可/具有/能够/用于/基于)
#   - negative lookahead against 第/所述/该/前述 (arm1 or ref-prefix)
#   - per-CJK-char negative lookahead against F6 verbs, so arm3's greedy
#     CJK{3,20} stops at the next F6-verb start rather than consuming
#     across `进行处理得到第N信号` and blocking arm1 at 得到第N信号.
# See docs/8c/r14c2-f6-bare-noun.md.
_F6_VERB_ALT_CN = (
    r'具有|包含|包括|含有|设有'
    r'|设置|配置|安装|装设'
    r'|形成|构成'
    r'|提供|连接|连结'
    r'|获取|获得|得到|生成|产生|发出'
    r'|发送|接收|输出|输入|传送|存储|确定|涉及'
    r'|进行|调用|运行|调整|建立|构建|制得|根据|存在|使用'
)

_BARE_AFTER_VERB_PATTERN_CN = re.compile(
    r'(?:' + _F6_VERB_ALT_CN + r')'
    r'('
    r'第[一二三四五六七八九十\d]+' + _CJK_NO_DE_ZHI_CN + r'+(?:\([A-Za-z0-9]+\))?'
    r'|' + _CJK_NO_DE_ZHI_CN + r'+\([A-Za-z0-9]+\)'
    r'|'
    r'(?!第|所述|该|前述)'
    + r'(?:(?!(?:' + _F6_VERB_ALT_CN + r'))' + _CJK_NO_DE_ZHI_CN + r'){3,20}'
    r')'
)

# F11: colon-anchored list-after-包括/包含/含有 (WQ8 / R3).
# R31 (2026-05-03): F11 anchor verb set extended to cover broader Pattern B
# trigger vocabulary observed in round-1 corpus. CNIPA drafters use 具有
# /具备/设有/设置/包括以下/还包括/进一步包括/还具有 as Pattern B intro
# anchors, not just 包括/包含/含有. Each addition gated separately against
# protect:true labels.
_F11_COLON_LIST_ANCHOR_CN: re.Pattern[str] = re.compile(
    r'(?:包括以下|还包括|还包含|进一步包括|进一步包含|包括|包含|含有|具有|具备|设有)[：:]\s*([^。]+)'
)
# R29 (2026-05-03): regex no longer excludes `；` so the capture spans the
# whole list (bounded by `。`). Caller in _extract_supplementary_intros_cn
# splits the captured text on `；` and processes each segment as its own
# F11 list-element source. Pattern B claims like `<system>包括: A; B; 以及 C`
# previously dropped B and C because the capture stopped at first `；`.
_F11_LIST_SPLIT_CN: re.Pattern[str] = re.compile(r'[、，,和与及]')

# Phase 8c R14e - F11 no-colon extension. Matches no-colon enum lists
# `(?:包括|包含|含有)(Y(?:、Y)+)` where ≥2 `、`-separated CJK elements
# follow the verb directly. Mutually exclusive with the colon anchor
# because the character after the verb must be CJK (not `：:`), and
# requires the enum-list shape so single-noun `包括Y` doesn't fire
# (that case belongs to F6 / elsewhere).
_F11_NO_COLON_LIST_ANCHOR_CN: re.Pattern[str] = re.compile(
    # R31 (2026-05-03): mirror of F11_COLON anchor verb extension.
    r'(?:包括以下|还包括|还包含|进一步包括|进一步包含|包括|包含|含有|具有|具备|设有)'
    r'([\u4e00-\u7683\u7685-\u9fff]{2,}(?:、[\u4e00-\u7683\u7685-\u9fff]{2,})+)'
)

# Phase 8c R14f - conjunction-split pass. Splits captured intros on
# 和/与/及/以及 with ≥2 CJK chars each side, registering each element as
# its own intro so downstream `所述X` / `所述Y` references can resolve
# when the drafting captured the intro as `X和Y`. Applied as a final
# pass over _extract_supplementary_intros_cn results after the uniform
# trailing-verb cleanup.
_CONJ_SPLIT_RE_CN: re.Pattern[str] = re.compile(r'(.+?)(?:以及|和|与|及)(.+)')

# F13: locative-verb + bare noun (+ optional locative suffix). Phase 8c R14a.
# Registers Y from `X应用于Y侧` / `X位于Y` as an intro, stripping a trailing
# locative suffix (侧/端/方/处/面/内/外/上/下/中) when present. The locative
# strip is required because walker resolution is reference.startswith(intro);
# a reference to `第一设备` cannot resolve to a longer intro `第一设备侧`.
_F13_LOCATIVE_VERB_PATTERN_CN: re.Pattern[str] = re.compile(
    r'(?:应用于|作用于|位于|置于|设于|布置于|设置于|固定于)'
    r'([\u4e00-\u7683\u7685-\u9fff]{2,12}(?:\([A-Za-z0-9]+\))?)'
)
_F13_LOCATIVE_SUFFIXES_CN: tuple[str, ...] = (
    '侧', '端', '方', '处', '面', '内', '外', '上', '下', '中',
)

# F14: V+有 noun-of-existence intro (Phase 9 #61).
# Registers Y from `X形成有Y` / `X安装有Y` / `X存储有Y` as an intro. Gated on
# a narrow verb set with empirically-clean captures - broader verbs (设置,
# 包含) add compound-noun FPs that the ADJ_REJECTS filter does not cover.
# Reuses _F12_ADJ_REJECTS_CN (rejects 可/由/能 etc.) + _REF_PREFIX_SET_CN +
# _BARE_ORDINAL_RE_CN + leading-conjunction reject (与/和/或).
_F14_V_YOU_PATTERN_CN: re.Pattern[str] = re.compile(
    r'(?:形成|安装|存储)有'
    r'([\u4e00-\u7683\u7685-\u9fff]{2,12}(?:\([A-Za-z0-9]+\))?)'
)
_F14_LEADING_CONJ_CN: frozenset[str] = frozenset({'与', '和', '或'})

# F12: copula + 基于/来自 intro family. Phase 8c R14d.
# Three tiers to balance coverage vs. predicate-adjective false positives:
#  - Tier A (unconditional): 转变为|变为|转为|划分为|分为 - always register RHS
#    as intro. Risk is minimal - these verbs are only used for noun transitions.
#  - Tier B (noun-gated): 基于|来自 - register RHS if ≥2 CJK and doesn't start
#    with an adjectival/verb-phrase prefix (_F12_ADJ_REJECTS_CN).
#  - Tier C (two-branch 为|是): (1) ordinal-prefix or paren-numeral RHS
#    (unconditional); (2) bare-noun RHS ≥4 CJK with the same ADJ reject filter.
#    Splits because `A为可光照交联` (adjectival predicate) and `A是经过...`
#    (verb phrase) must be rejected; ordinal-prefix RHS is safe regardless.
_F12_TIER_A_RE_CN: re.Pattern[str] = re.compile(
    r'(?:转变为|变为|转为|划分为|分为)'
    r'([\u4e00-\u7683\u7685-\u9fff]{2,12}(?:\([A-Za-z0-9]+\))?)'
)
_F12_TIER_B_RE_CN: re.Pattern[str] = re.compile(
    r'(?:基于|来自)'
    r'([\u4e00-\u7683\u7685-\u9fff]{2,12}(?:\([A-Za-z0-9]+\))?)'
)
_F12_TIER_C_ORDINAL_RE_CN: re.Pattern[str] = re.compile(
    r'(?:为|是)'
    r'(第[一二三四五六七八九十\d]+[\u4e00-\u7683\u7685-\u9fff]{1,10}'
    r'(?:\([A-Za-z0-9]+\))?'
    r'|[\u4e00-\u7683\u7685-\u9fff]{2,10}\([A-Za-z0-9]+\))'
)
_F12_TIER_C_BARE_RE_CN: re.Pattern[str] = re.compile(
    r'(?:为|是)'
    r'([\u4e00-\u7683\u7685-\u9fff]{4,12}(?:\([A-Za-z0-9]+\))?)'
)
_F12_ADJ_REJECTS_CN: tuple[str, ...] = (
    '可', '具有', '具', '经过', '由', '属于', '用于', '来自',
    '能够', '能', '会',
    '进行', '获得', '获取', '接收', '存储', '输出', '输入',
    '基于', '根据',
    # === Phase 8c R7-port (2026-04-30) - TW R7 parity ===
    # Copula / preposition / verb-prefix rejects for F6 bare-NP arm 3
    # and F12 Tier B emit. CN equivalents of TW's 係/是/為/較/對/在/將/
    # 藉/蝕. Mirror set with TW _F12_ADJ_REJECTS_TW so semiconductor /
    # process-method drafts surface clean noun heads on CN side.
    '系', '是', '为',
    '较', '对', '在',
    '将', '借', '蚀',
)

# F7d: participial `<tail>的Y` intro family. Phase 8c R14b.
# Stative-participle tails that introduce a new noun Y after 的. Intentionally
# narrow allowlist - DE_POSSESSIVE is heterogeneous and a broad `V的Y` regex
# would over-fire. Post-capture cleanup via clean_noun_phrase_cn handles
# trailing-verb overcaptures (e.g., 训练目标进行训练 → 训练目标 via interior-verb
# truncation at 进行 from R8).
_F7D_PARTICIPIAL_TAILS_CN: tuple[str, ...] = (
    '所对应', '按照预设', '相对应', '接收到',
    '预设', '所需', '相关', '对应', '匹配',
    '得到', '制得', '执行', '制造', '相连',
    '生成', '连接', '形成', '组成',
    # === R30 (2026-05-03) - extended participial tails from corpus ===
    # Round-1 corpus walker_fps include patterns like
    # `<X>覆盖的Y`, `<X>构成的Y`, `<X>设置的Y`, `<X>包含的Y` that the
    # original F7d allowlist doesn't catch. Adding them is safe because:
    # (a) each is clearly a participial verb (not a noun), (b) the trailing
    # 的 ensures Y is an attribute of X - registering Y as intro is correct
    # under §112(b) when X is in the chain.
    '覆盖', '构成', '设置', '配置', '安装',
    '提供', '获取', '获得', '产生',
    '所述包括', '所述包含', '所述具有',
    '附加', '增加', '减少', '改变', '修改',
    '包括', '包含', '具有',
)
_F7D_PATTERN_CN: re.Pattern[str] = re.compile(
    r'(?:' + '|'.join(re.escape(t) for t in _F7D_PARTICIPIAL_TAILS_CN) + r')'
    r'的([\u4e00-\u7683\u7685-\u9fff]{2,12}(?:\([A-Za-z0-9]+\))?)'
)
# Reuses _F12_ADJ_REJECTS_CN.

# F5a ref-prefix set (Q1: 该等/该些 excluded).
_REF_PREFIX_SET_CN = ('所述', '该', '前述')

_REF_POSSESSIVE_WITH_NUM_CN = re.compile(
    r'(?:所述|该|前述)'
    r'[\u4e00-\u7683\u7685-\u9fff]{2,}\([A-Za-z0-9]+\)'
    r'的'
    r'([\u4e00-\u7683\u7685-\u9fff]{2,}(?:\([A-Za-z0-9]+\))?)'
)
_REF_POSSESSIVE_NO_NUM_CN = re.compile(
    r'(?:所述|该|前述)'
    r'[\u4e00-\u7683\u7685-\u9fff]{2,4}'
    r'的'
    r'([\u4e00-\u7683\u7685-\u9fff]{2,}(?:\([A-Za-z0-9]+\))?)'
)

_YI_NOUN_PAREN_DE_PATTERN_CN = re.compile(
    r'一[\u4e00-\u7683\u7685-\u9fff]{2,}\([A-Za-z0-9]+\)'
    r'的'
    r'([\u4e00-\u7683\u7685-\u9fff]{2,}(?:\([A-Za-z0-9]+\))?)'
)

_POSSESSIVE_VERB_DENYLIST_CN = {
    '包括', '包含', '具有', '是', '为', '大于', '小于', '等于',
    '设置', '形成', '连接', '连结',
}


# ── R7-port (2026-04-30) - CN architectural buildout for F14/F16/F17/F19/F20 ──
# Mirror of TW R7's bare-modifier intro infrastructure. CN drafters use the
# same structural patterns (locative left-side, verb-X-之/的-Y, instrumental
# clauses) as TIPO drafters; the architectural divergence between CN and
# TW walkers prior to R7 meant CN had no equivalent of these mechanisms.
# This block adds them in advance - without waiting for a CN-side report -
# so CNIPA semiconductor / process-method drafts get the same protection.

# Component-suffix tail set for bare-noun intro emit gates. Mirrors TW
# _F10_COMPONENT_SUFFIXES with CN-specific items (域 region, 极 electrode).
# Single-char only - multi-char composites contribute their tail char which
# is already covered.
_F10_COMPONENT_SUFFIXES_CN: tuple[str, ...] = (
    '部', '件', '体', '器', '阀', '板', '模', '组', '块', '片',
    '环', '壳', '膜', '座', '盘', '筒', '轴', '杆', '轮', '带',
    '管', '架', '框', '壁', '面', '层', '材', '口', '道', '头',
    '侧', '孔', '缝', '边', '顶', '底', '角', '心', '核', '机',
    '柜', '室', '槽', '线', '路', '池', '枢', '盖', '套', '罩',
    '网', '柱', '锥', '球',
    # R7 (2026-04-30) - semiconductor + electronic claim element suffixes:
    # 域 (region: n型区域, p型区域, 主动区域); 极 (electrode pole: 栅极,
    # 源极, 漏极, 集极, 射极)
    '域', '极',
)

# Single-char component-suffix set for walk-back logic. F10's narrow
# endswith gate uses _F10_COMPONENT_SUFFIXES_CN; walk-back uses this
# wider set which includes 法 (method-claim head - `制造方法`).
_F10_SINGLE_CHAR_SUFFIXES_CN: frozenset[str] = frozenset(
    _F10_COMPONENT_SUFFIXES_CN
) | {
    # Walk-back-only: 法 lets `之制造方法` register as `制造方法` (then
    # strip_leading_verb_cn produces `方法`). F10's narrow gate excludes
    # 法 to avoid 想法/做法/算法 misfire on `一种的方法`-style synthetic.
    '法',
}

# Walk-back's discarded-suffix gate - only allow walk-back when the
# discarded portion starts with one of these verb-tail-head characters
# AND has length ≥ 2. Mirrors TW _F14_WALKBACK_VERB_HEADS_TW. CN
# zh-Hans equivalents: 制 (制成, 所制), 经 (经由 - also covers traditional
# 經 in mixed-script).
_F14_WALKBACK_VERB_HEADS_CN: tuple[str, ...] = (
    '所', '露', '形', '构', '组', '制', '经',
    # R7 extension (2026-04-30): 获 covers `X获得Y` / `X获取Y` walk-back
    # in CN process-method drafts. Mirror TW addition; 获利 is rare in
    # claim text, 获得/获取 dominant as verbs.
    '获',
)

# Mixed-script noun class for CN F14/F16/F17/F19/F20. Admits ASCII
# letters/digits + ／ (paired-element separator). Excludes 之 (U+4E4B)
# and 的 (U+7684) so captures don't span possessive markers.
_F14_NOUN_CLASS_CN = r'[A-Za-z0-9／一-乊乌-皃皅-鿿]'

# ADJ/verb heads that must not start a bare-modifier noun capture.
# Mirrors TW _F10_NOUN_REJECTS plus CN-specific copula / preposition /
# verb-prefix rejects.
_F10_NOUN_REJECTS_CN: tuple[str, ...] = (
    '可', '具有', '具', '经过', '由', '属于', '用于', '来自',
    '能够', '能', '会', '进行', '获得', '获取', '接收', '存储',
    '输出', '输入', '基于', '根据',
    '单一', '唯一',
    # R7 - copula / preposition / verb-prefix rejects (zh-Hans equivalents
    # of TW's 系/是/为/较/对/在/将/借/蚀)
    '系', '是', '为',
    '较', '对', '在',
    '将', '借', '蚀',
)

# Leading-verb prefix strip (`形成X`/`制造X` → `X`). Symmetric on intro
# and reference sides per ADR-095. Residual ≥ 2 protects 形成器/形成物
# (3 chars, residual 1 < 2) while admitting 制造方法 (4 chars, residual 2).
# R31 (2026-05-03): added 有 prefix. F-family captures of `设置有X` style
# Pattern B intros leave `有X` after 设置 strip; the leading 有 should be
# stripped to surface bare X. Residual ≥ 2 protects compound nouns
# starting with 有 (有限/有机/有效) - those are 2-char with residual 0/1
# after strip, so still protected.
_LEADING_VERB_PREFIXES_CN: tuple[str, ...] = tuple(sorted(
    (
        '形成', '制造', '有',
        # R32 (2026-05-04): connective-verb prefixes - TW parity.
        # Empirical: `即根据各数字内容` / `使得各数字内容关联` shape leaks
        # into spec-support via shared extract_introductions_cn helper.
        # Multi-char longest-first.
        '即根据', '即基于', '即依据', '即依照',
        '根据', '基于', '依据', '依照',
        '为了', '借以', '借由', '通过',
        '使得', '使其', '从而', '进而', '并且',
        '用以', '用于',
        # R67 (2026-05-05) sweep: 具有 - possession verb ("X has Y").
        # Drafters write `所述具有酸解离性基的结构单元` where the actual
        # antecedent is `结构单元` (or `酸解离性基`), not `具有酸解离性基`.
        # Residual ≥ 2 protects 具有 + 1-char compounds (none expected
        # in patent diction) while admitting 具有 + 2+-char nouns.
        # Attestation: CN120266060A c8 captured `具有酸解离性基`.
        '具有',
    ),
    key=len,
    reverse=True,
))
_LEADING_VERB_RESIDUAL_FLOOR_CN: int = 2


def strip_leading_verb_cn(text: str) -> str:
    """R7 (2026-04-30): strip leading verb prefix (形成/制造) when followed
    by a sufficient noun residual. Used in normalize_*_cn pipelines so
    `所述形成p型源极／漏极` references resolve against bare-noun
    `p型源极／漏极` intros.
    """
    if not text:
        return text
    for prefix in _LEADING_VERB_PREFIXES_CN:
        if (
            text.startswith(prefix)
            and len(text) - len(prefix) >= _LEADING_VERB_RESIDUAL_FLOOR_CN
        ):
            return text[len(prefix):]
    return text


def _trim_capture_to_clean_noun_cn(text: str) -> str | None:
    """R7 (2026-04-30): walk back from end of `text` to the last component-
    suffix character and truncate; return ``None`` if hygiene gates fail.
    Mirror of _trim_capture_to_clean_noun_tw - see that function for full
    contract documentation.
    """
    if not text or len(text) < 2:
        return None
    if text[-1] in _F10_SINGLE_CHAR_SUFFIXES_CN:
        truncated = text
    else:
        clean_end = None
        for i in range(min(len(text), 12), 0, -1):
            if text[i - 1] in _F10_SINGLE_CHAR_SUFFIXES_CN:
                clean_end = i
                break
        if clean_end is None:
            return None
        discarded = text[clean_end:]
        if len(discarded) < 2 or not discarded.startswith(
            _F14_WALKBACK_VERB_HEADS_CN
        ):
            return None
        truncated = text[:clean_end]
    if len(truncated) < 2:
        return None
    for prefix in _REFERENCE_FORM_PREFIXES_CN:
        if prefix in truncated:
            return None
    if truncated.startswith(_F10_NOUN_REJECTS_CN):
        return None
    return truncated


# F14 - bare-modifier `之NOUN` intro (formal-register parallel to F10's
# `的NOUN`). Less common in modern CN claims but appears in formal-register
# / JP-translated CN drafts. Mixed-script noun class for semiconductor.
_F14_BARE_ZHI_NOUN_RE_CN = re.compile(
    r'之'
    r'(?P<noun>' + _F14_NOUN_CLASS_CN + r'{2,12}'
    r'(?:\([A-Za-z0-9]+\))?)'
    r'(?!' + _F14_NOUN_CLASS_CN + r')'
)

# F16 - locative left-side intro `(?:于|在)X[之的]Y`. Captures left-side X
# (the new claim element introduced via locative phrase). CN uses both
# 之 (formal) and 的 (modern) for the possessive marker.
_F16_LOC_LEFT_INTRO_RE_CN = re.compile(
    r'(?:于|在)'
    r'(?P<noun>' + _F14_NOUN_CLASS_CN + r'{2,8}'
    r'(?:\([A-Za-z0-9]+\))?)'
    r'[之的]'
)

# F17 - locative-internal `在X之间` / `在X之间` intro (zh-Hans uses 间).
_F17_LOC_INTERNAL_INTRO_RE_CN = re.compile(
    r'在'
    r'(?P<noun>' + _F14_NOUN_CLASS_CN + r'{2,8}'
    r'(?:\([A-Za-z0-9]+\))?)'
    r'之间'
)

# F19 - `verb + X + [之的] + Y` left-side intro. F6 rejects this shape
# via its `(?![的之])` trailing lookahead; F19 explicitly catches it.
_F19_VERB_NP_ZHI_RE_CN = re.compile(
    r'(?:夹持|包含|包括|具有|含有|具备|设有|设置|配置|安装|装设|形成|构成|连接|连结|提供|构建)'
    r'(?P<noun>' + _F14_NOUN_CLASS_CN + r'{2,8}'
    r'(?:\([A-Za-z0-9]+\))?)'
    r'[之的]'
)

# F20 - `(以|借由|透过|经由|将) X (verb)` instrumental/object intro.
# `以` excluded when followed by `及` (conjunction `以及`).
# R41 (2026-05-04): added `将` (instrumental object marker, very
# common in CN claims for `将<noun><verb>` constructions like
# `将第一激发光输出`/`将信号发送`/`将数据传输`). Extended trailing-
# verb list with output/send/transmit/etc. to cover the most common
# 将-shape cases. Phase A on post-R36 corpus showed CN `发光` cluster
# 48 wfp / 0 legit (top: `第二激发光` 14, `第一激发光` 13) - parent
# claim 1 introduces 第一激发光 via `将第一激发光输出` shape that
# F20 didn't recognize.
_F20_PREP_NP_VERB_RE_CN = re.compile(
    r'(?:以(?!及)|借由|透过|经由|将)'
    r'(?P<noun>' + _F14_NOUN_CLASS_CN + r'{2,8}'
    r'(?:\([A-Za-z0-9]+\))?)'
    r'(?:夹持|覆盖|包含|包括|具有|含有|具备|设有|设置|配置|形成|构成|连接|连结|提供|分隔|划分|实施|分为|构建|测量|蚀刻|除去|装设|安装|输出|输入|发送|接收|传输|传送|生成|获取|获得|确定|存储|读取|写入|执行|处理|计算)'
)


def _extract_supplementary_intros_cn(text: str) -> list[tuple[str, str]]:
    """Extract bare-noun introductions from supplementary CN patterns.

    Returns (original_span, normalized_term) pairs. Active families:
    F5a/F5b, F6, F7b/F7c/F7d, F11 (colon + no-colon), F12, F13. Uniform
    ``clean_noun_phrase_cn`` cleanup. See tw_claims.py lines 1982-2099
    for per-family rationale. F7a/F8/F9 removed after zero-coverage
    R14 investigation confirmed CN corpus never exercises them.
    """
    results: list[tuple[str, str]] = []

    # F7d (R64, 2026-05-05) TW parity: bare locative `于X的Y` - captures X.
    # Same scoping as TW F7d:
    #   1. 于 must follow a clause boundary or claim start
    #   2. X must be ≥ 3 CJK chars
    #   3. X must not start with reference prefix (前述/所述/该/该等/该些)
    # Conservative: CN drafters use 在X上 / 在X中 more than 于X的, so
    # this pattern's hit rate may be low - but adding for cross-jurisdiction
    # symmetry with TW F7d (which surfaced the user-reported 半导体基板
    # missed-intro on 神秘黑屏哥.docx).
    _BARE_YU_X_DE_RE_CN = re.compile(
        r"(?:^|[，、。；\n　])"
        r"于([^\s，。；：、及与和之的该将能须应皆被于以并且其而还另时在前所]{3,12})"
        r"的"
    )
    for m in _BARE_YU_X_DE_RE_CN.finditer(text):
        candidate = m.group(1)
        if any(candidate.startswith(p) for p in _REFERENCE_FORM_PREFIXES_CN):
            continue
        cjk_len = sum(1 for c in candidate if '一' <= c <= '鿿')
        if cjk_len < 3:
            continue
        results.append((m.group(0), candidate))

    # F7b: 一V的Y - participial
    for m in _PARTICIPIAL_YI_DE_PATTERN_CN.finditer(text):
        noun = m.group(1)
        normalized = re.sub(r'\([A-Za-z0-9]+\)', '', noun)
        # R58: strip an embedded plating verb before the ordinal head
        # (镀第N<noun>); the real element is the trailing ordinal noun.
        normalized = _strip_plating_prefix_cn(normalized)
        has_numeral = '(' in noun
        has_ordinal = normalized.startswith('第')
        cjk_len = sum(1 for c in normalized if '\u4e00' <= c <= '\u9fff')
        if not (has_ordinal or has_numeral or cjk_len >= 3):
            continue
        results.append((m.group(0), normalized))

    # F7c: 的第Y - post-的 ordinal noun
    for m in _POST_DE_ORDINAL_PATTERN_CN.finditer(text):
        noun = m.group(1)
        normalized = re.sub(r'\([A-Za-z0-9]+\)', '', noun)
        results.append((m.group(0), normalized))

    # R58: plating verb + ordinal noun (镀有第一底部铜层 -> 第一底部铜层).
    for m in _PLATING_ORDINAL_INTRO_CN.finditer(text):
        noun = m.group(1)
        normalized = re.sub(r'\([A-Za-z0-9]+\)', '', noun)
        results.append((m.group(0), normalized))

    # F6: verb + Y - bare-after-verb
    # CN R70: article-less introduction after 进一步<transitional verb>. The
    # compensating arm for the 进一步 repair above, and it is REQUIRED, not
    # optional: `其进一步包含溶剂` (CN119421888A c6) introduces 溶剂 with no
    # quantifier at all, and the bug being fixed was the only thing registering
    # it - as the garbage key `步包含溶剂`, which covered `所述溶剂` by
    # containment. Removing the garbage without this arm manufactured 4
    # findings on exactly that draft. Chinese has no articles, so a first
    # mention after the "further comprising" idiom is a real introduction.
    for m in _JINYIBU_INTRO_RE_CN.finditer(text):
        noun = m.group(1)
        if noun.startswith(_REF_PREFIX_SET_CN) or noun.startswith(_F12_ADJ_REJECTS_CN):
            continue
        results.append((m.group(0), re.sub(r'\([A-Za-z0-9]+\)', '', noun)))

    for m in _BARE_AFTER_VERB_PATTERN_CN.finditer(text):
        noun = m.group(1)
        # R14c.2: bare-NP arm (no ordinal, no paren) is gated by
        # _F12_ADJ_REJECTS_CN startswith to suppress predicate-adjective
        # and verb-phrase heads like 可/经过/具有/能够/用于/基于/根据.
        if (not noun.startswith('第')
                and '(' not in noun
                and noun.startswith(_F12_ADJ_REJECTS_CN)):
            continue
        # CN R70: the TW R62 夹持 device-noun guard is NOT mirrored, and the
        # reason is worth recording rather than leaving as an omission: the CN
        # F6 arm does not reach the shape at all. `所述夹持机构能用来…` yields NO
        # F6 match on CN (checked directly), so a guard here would be dead code
        # carrying its own FN surface - the #508/#511 probe-before-you-guard
        # lesson. A test pins the absence so a later mirror sweep does not add
        # it blind.
        # CN R70 mirror of TW R62 (#779): arm 3 opening on the purpose coverb
        # 以 is the verb's complement clause, not its object (包括以下各项).
        # 630 corpus emits; 以 heads no CN element name except the loan 以太.
        if (not noun.startswith('第') and '(' not in noun
                and noun.startswith("以") and not noun.startswith("以太")):
            continue
        normalized = re.sub(r'\([A-Za-z0-9]+\)', '', noun)
        results.append((m.group(0), normalized))
        # Also split conjunctions (和/与/及/、) into individual intros
        parts = _F11_LIST_SPLIT_CN.split(normalized)
        if len(parts) > 1:
            for part in parts:
                part = part.strip()
                if part:
                    results.append((m.group(0), part))

    # F5a: ref-prefix possessive (two variants)
    for pattern in (_REF_POSSESSIVE_WITH_NUM_CN, _REF_POSSESSIVE_NO_NUM_CN):
        for m in pattern.finditer(text):
            noun = m.group(1)
            normalized = re.sub(r'\([A-Za-z0-9]+\)', '', noun)
            cjk_len = sum(1 for c in normalized if '\u4e00' <= c <= '\u9fff')
            if cjk_len < 2:
                continue
            if normalized.startswith(_REF_PREFIX_SET_CN):
                continue
            end_pos = m.end()
            follower = text[end_pos:end_pos + 2]
            if follower in _POSSESSIVE_VERB_DENYLIST_CN:
                continue
            results.append((m.group(0), normalized))

    # F5b: 一X(N)的Y - intro with paren-numeral possessive
    for m in _YI_NOUN_PAREN_DE_PATTERN_CN.finditer(text):
        noun = m.group(1)
        normalized = re.sub(r'\([A-Za-z0-9]+\)', '', noun)
        cjk_len = sum(1 for c in normalized if '\u4e00' <= c <= '\u9fff')
        if cjk_len < 2:
            continue
        if normalized.startswith(_REF_PREFIX_SET_CN):
            continue
        end_pos = m.end()
        follower = text[end_pos:end_pos + 2]
        if follower in _POSSESSIVE_VERB_DENYLIST_CN:
            continue
        results.append((m.group(0), normalized))

    # F11: list-after-包括 - colon-anchored preamble lists register each
    # element as a bare-noun intro. WQ8 / Phase 8c close-out R3.
    # R14e extends with a no-colon sibling pattern gated on ≥2 `、`-
    # separated elements.
    for anchor_re in (_F11_COLON_LIST_ANCHOR_CN, _F11_NO_COLON_LIST_ANCHOR_CN):
        for m in anchor_re.finditer(text):
            # R29 (2026-05-03): iterate ；-segments instead of truncating
            # at first; strip leading 以及/及 from each segment.
            full_list = m.group(1).split('。')[0]
            for segment in full_list.split('；'):
                segment = segment.strip()
                if not segment:
                    continue
                segment = re.sub(r'^(?:以及|及)\s*', '', segment)
                if not segment:
                    continue
                for element in _F11_LIST_SPLIT_CN.split(segment):
                    element = element.strip()
                    if not element:
                        continue
                    normalized = re.sub(r'\([A-Za-z0-9]+\)', '', element)
                    cjk_len = sum(1 for c in normalized if '\u4e00' <= c <= '\u9fff')
                    if cjk_len < 2:
                        continue
                    if normalized.startswith(_REF_PREFIX_SET_CN):
                        continue
                    results.append((element, normalized))
                    # R30 mechanism #4 (2026-05-03): sub-noun extraction from
                    # `<verb>X\u7684Y` shape inside the captured element. Pattern B
                    # often introduces multiple terms via possessive constructs:
                    # `\u5904\u7406\u672b\u7aef\u6267\u884c\u5668\u7684\u6240\u6709\u4efb\u52a1` should register both `\u672b\u7aef\u6267\u884c\u5668`
                    # and `\u6240\u6709\u4efb\u52a1`. Find the FIRST \u7684 (avoid deep nesting),
                    # split into head/tail, register each if valid noun phrase.
                    de_idx = normalized.find('\u7684')  # \u7684
                    if 0 < de_idx < len(normalized) - 1:
                        head = normalized[:de_idx]
                        tail = normalized[de_idx + 1:]
                        for sub in (head, tail):
                            sub_cjk = sum(1 for c in sub if '\u4e00' <= c <= '\u9fff')
                            if sub_cjk < 2:
                                continue
                            if sub.startswith(_REF_PREFIX_SET_CN):
                                continue
                            if sub.startswith(_F12_ADJ_REJECTS_CN):
                                continue
                            # Strip leading verb prefix (creation-verb subset)
                            # to unwrap `<verb><noun>` head into bare noun.
                            stripped = sub
                            for verb in ('\u63d0\u4f9b', '\u914d\u7f6e', '\u8bbe\u7f6e', '\u5f62\u6210', '\u6784\u6210',
                                          '\u6784\u5efa', '\u83b7\u53d6', '\u83b7\u5f97', '\u5f97\u5230', '\u751f\u6210',
                                          '\u4ea7\u751f', '\u8fde\u63a5', '\u8fde\u7ed3', '\u5b89\u88c5', '\u88c5\u8bbe',
                                          '\u5904\u7406'):
                                if stripped.startswith(verb) and len(stripped) > len(verb) + 1:
                                    rest = stripped[len(verb):]
                                    rest_cjk = sum(1 for c in rest if '\u4e00' <= c <= '\u9fff')
                                    if rest_cjk >= 2:
                                        stripped = rest
                                        break
                            if stripped != sub:
                                results.append((element, stripped))
                            results.append((element, sub))

    # F13: locative-verb + bare noun (+ optional locative suffix). R14a.
    for m in _F13_LOCATIVE_VERB_PATTERN_CN.finditer(text):
        raw = m.group(1)
        if raw.startswith(_REF_PREFIX_SET_CN):
            continue
        normalized = re.sub(r'\([A-Za-z0-9]+\)', '', raw)
        if (
            normalized
            and normalized[-1] in _F13_LOCATIVE_SUFFIXES_CN
            and len(normalized) >= 3
        ):
            normalized = normalized[:-1]
        if len(normalized) < 2:
            continue
        if normalized.startswith(_REF_PREFIX_SET_CN):
            continue
        results.append((m.group(0), normalized))

    # F14: V+有 noun-of-existence intro. Phase 9 #61.
    for m in _F14_V_YOU_PATTERN_CN.finditer(text):
        raw = m.group(1)
        if raw.startswith(_REF_PREFIX_SET_CN):
            continue
        if raw.startswith(_F12_ADJ_REJECTS_CN):
            continue
        if raw and raw[0] in _F14_LEADING_CONJ_CN:
            continue
        if _BARE_ORDINAL_RE_CN.match(raw):
            continue
        normalized = re.sub(r'\([A-Za-z0-9]+\)', '', raw)
        if len(normalized) < 2:
            continue
        results.append((m.group(0), normalized))

    # F12: copula + 基于/来自 intro family. R14d.
    for m in _F12_TIER_A_RE_CN.finditer(text):
        raw = m.group(1)
        if raw.startswith(_REF_PREFIX_SET_CN):
            continue
        normalized = re.sub(r'\([A-Za-z0-9]+\)', '', raw)
        if len(normalized) < 2:
            continue
        results.append((m.group(0), normalized))

    for m in _F12_TIER_B_RE_CN.finditer(text):
        raw = m.group(1)
        if raw.startswith(_REF_PREFIX_SET_CN):
            continue
        if raw.startswith(_F12_ADJ_REJECTS_CN):
            continue
        normalized = re.sub(r'\([A-Za-z0-9]+\)', '', raw)
        if len(normalized) < 2:
            continue
        results.append((m.group(0), normalized))

    for m in _F12_TIER_C_ORDINAL_RE_CN.finditer(text):
        raw = m.group(1)
        if raw.startswith(_REF_PREFIX_SET_CN):
            continue
        normalized = re.sub(r'\([A-Za-z0-9]+\)', '', raw)
        if len(normalized) < 2:
            continue
        results.append((m.group(0), normalized))

    for m in _F12_TIER_C_BARE_RE_CN.finditer(text):
        raw = m.group(1)
        if raw.startswith(_REF_PREFIX_SET_CN):
            continue
        if raw.startswith(_F12_ADJ_REJECTS_CN):
            continue
        normalized = re.sub(r'\([A-Za-z0-9]+\)', '', raw)
        if len(normalized) < 4:
            continue
        results.append((m.group(0), normalized))

    # F7d: participial <tail>的Y. R14b.
    for m in _F7D_PATTERN_CN.finditer(text):
        raw = m.group(1)
        if raw.startswith(_REF_PREFIX_SET_CN):
            continue
        if raw.startswith(_F12_ADJ_REJECTS_CN):
            continue
        normalized = re.sub(r'\([A-Za-z0-9]+\)', '', raw)
        if len(normalized) < 2:
            continue
        results.append((m.group(0), normalized))

    # === Phase 8c R7-port (2026-04-30) - TW R7 architectural buildout ===
    # F14 (V之Y), F16 (locative left-side), F17 (locative-internal),
    # F19 (verb-X-之/的), F20 (instrumental). Mirror of TW R7 mechanisms.
    # All use _trim_capture_to_clean_noun_cn for hygiene.

    # F14: bare-modifier `之NOUN` intro (formal-register parallel to F10).
    for m in _F14_BARE_ZHI_NOUN_RE_CN.finditer(text):
        noun = m.group('noun')
        # CN R70 mirror of TW R62 (#786): 之间 is the locative "between", never
        # 之 + a noun, so a capture opening on its orphaned 间 is the predicate
        # after the locative frame. Present in CN at volume before mirroring:
        # 723 corpus captures. 之间隔 / 之间隙 / 之间距 ARE 之 + noun.
        if noun.startswith("间") and noun[1:2] not in ("隔", "隙", "距"):
            continue
        normalized = re.sub(r'\([A-Za-z0-9]+\)', '', noun)
        trimmed = _trim_capture_to_clean_noun_cn(normalized)
        if trimmed is None:
            continue
        results.append((m.group(0), trimmed))

    # F16: locative left-side intro `(于|在)X[之的]`.
    for m in _F16_LOC_LEFT_INTRO_RE_CN.finditer(text):
        noun = m.group('noun')
        normalized = re.sub(r'\([A-Za-z0-9]+\)', '', noun)
        trimmed = _trim_capture_to_clean_noun_cn(normalized)
        if trimmed is None:
            continue
        results.append((m.group(0), trimmed))

    # F17: locative-internal `在X之间`.
    for m in _F17_LOC_INTERNAL_INTRO_RE_CN.finditer(text):
        noun = m.group('noun')
        normalized = re.sub(r'\([A-Za-z0-9]+\)', '', noun)
        trimmed = _trim_capture_to_clean_noun_cn(normalized)
        if trimmed is None:
            continue
        results.append((m.group(0), trimmed))

    # F19: `verb + X + [之的] + Y` left-side intro.
    for m in _F19_VERB_NP_ZHI_RE_CN.finditer(text):
        noun = m.group('noun')
        normalized = re.sub(r'\([A-Za-z0-9]+\)', '', noun)
        trimmed = _trim_capture_to_clean_noun_cn(normalized)
        if trimmed is None:
            continue
        results.append((m.group(0), trimmed))

    # F20: `(以|借由|透过|经由) X (verb)` instrumental intro.
    for m in _F20_PREP_NP_VERB_RE_CN.finditer(text):
        noun = m.group('noun')
        normalized = re.sub(r'\([A-Za-z0-9]+\)', '', noun)
        trimmed = _trim_capture_to_clean_noun_cn(normalized)
        if trimmed is None:
            continue
        results.append((m.group(0), trimmed))

    # Uniform trailing-verb cleanup
    cleaned: list[tuple[str, str]] = []
    for orig, norm in results:
        cleaned_norm = clean_noun_phrase_cn(norm)
        if not cleaned_norm or len(cleaned_norm) < 2:
            continue
        if cleaned_norm.startswith('第') and len(cleaned_norm) < 4:
            continue
        cleaned.append((orig, cleaned_norm))

    # R14f conjunction-split: for each cleaned intro containing 和/与/及/以及
    # with ≥2 CJK chars on each side, register each element as its own intro.
    seen_norms = {norm for _, norm in cleaned}
    extras: list[tuple[str, str]] = []
    for _, norm in cleaned:
        m = _CONJ_SPLIT_RE_CN.match(norm)
        if not m:
            continue
        for piece in (m.group(1), m.group(2)):
            piece_clean = clean_noun_phrase_cn(piece)
            if not piece_clean or len(piece_clean) < 2:
                continue
            cjk = sum(1 for c in piece_clean if '\u4e00' <= c <= '\u9fff')
            if cjk < 2:
                continue
            if piece_clean.startswith(_REF_PREFIX_SET_CN):
                continue
            if piece_clean in seen_norms:
                continue
            seen_norms.add(piece_clean)
            extras.append((piece_clean, piece_clean))

    # R31 (2026-05-03): generic 的-substring sub-noun extraction across ALL
    # captured intros. R30's F11 sub-noun was F11-only; round-1 mining
    # showed F12/F13/F14 captures also benefit (e.g., F13 locative-verb
    # intros like `位於連接器之間的耦合介面` should register both 連接器
    # and 耦合介面). Apply post-pass over `cleaned` (which contains all
    # F-family results after trim). Single-的 split only.
    # Anti-pattern: skip if both halves < 2 CJK chars OR start with reject prefix.
    cleaned_subs = []
    for orig, norm in cleaned:
        de_idx = norm.find('的')  # 的
        if 0 < de_idx < len(norm) - 1:
            head = norm[:de_idx]
            tail = norm[de_idx + 1:]
            for sub in (head, tail):
                sub_cjk = sum(1 for c in sub if '\u4e00' <= c <= '\u9fff')
                if sub_cjk < 2:
                    continue
                if sub.startswith(_REF_PREFIX_SET_CN):
                    continue
                if sub.startswith(_F12_ADJ_REJECTS_CN):
                    continue
                if sub in seen_norms:
                    continue
                seen_norms.add(sub)
                cleaned_subs.append((orig, sub))
    cleaned.extend(cleaned_subs)

    # R31 second 的-split pass - handles X的Y的Z three-way splits.
    cleaned_subs2 = []
    for orig, norm in cleaned_subs:  # only re-split the newly added ones
        de_idx = norm.find('的')
        if 0 < de_idx < len(norm) - 1:
            head = norm[:de_idx]
            tail = norm[de_idx + 1:]
            for sub in (head, tail):
                sub_cjk = sum(1 for c in sub if '\u4e00' <= c <= '\u9fff')
                if sub_cjk < 2:
                    continue
                if sub.startswith(_REF_PREFIX_SET_CN):
                    continue
                if sub in seen_norms:
                    continue
                seen_norms.add(sub)
                cleaned_subs2.append((orig, sub))
    cleaned.extend(cleaned_subs2)

    # R30 mechanism #11 (2026-05-03): step-label colon intros for method claims.
    # Pattern: `；以及<step-name>:<step-content>` or `；<step-name>:<content>`
    # where the step-name (multi-char CJK before colon) is the new claim element.
    # Common in CN method claims: `；以及印刷步骤：在所述陶瓷块...`. Anti-pattern:
    # the noun must NOT start with reference-prefix or 第N (those are existing
    # references / ordinals, not new step labels).
    _STEP_LABEL_RE_R30 = re.compile(
        r'[；;]\s*(?:以及|及)?\s*([\u4e00-\u9fff]{2,12})\s*[：:]'
    )
    for sl_m in _STEP_LABEL_RE_R30.finditer(text):
        noun = sl_m.group(1)
        if not noun or len(noun) < 2:
            continue
        if noun.startswith(_REF_PREFIX_SET_CN):
            continue
        if noun.startswith('第'):
            continue
        if noun.startswith(_F12_ADJ_REJECTS_CN):
            continue
        if noun in seen_norms:
            continue
        seen_norms.add(noun)
        extras.append((sl_m.group(0), noun))

    # R30 mechanism #7 (2026-05-03): F6c Latin/short-CJK term floor.
    # F6 arms 1-3 require CJK-only nouns. Walker_fps on Latin acronyms
    # (UE, DCI, LHT, CU-CP) and Latin-CJK mixed terms (PWM信号, DCI格式,
    # RAM控制器) need an explicit arm. Pattern: <F6 verb>(<Latin-noun>)
    # where Latin-noun is uppercase Latin chars optionally followed by CJK
    # suffix. Anti-pattern: must be at a clear boundary (followed by
    # punctuation, conjunction, or end-of-clause) to avoid mid-word matches.
    _F6C_VERB_ALT = (
        r'具有|包含|包括|含有|设有|设置|配置|安装|装设|形成|构成|提供|连接|连结'
        r'|获取|获得|得到|生成|产生|发出|发送|接收|输出|输入|传送|存储|确定|涉及'
        r'|进行|调用|运行|调整|建立|构建|制得|根据|存在|使用'
    )
    _F6C_LATIN_RE = re.compile(
        r'(?:' + _F6C_VERB_ALT + r')'
        r'(?P<noun>[A-Z][A-Za-z0-9\-]{1,15}[\u4e00-\u9fff]{0,8})'
        r'(?=[，,。；;、 \t\n或与和及])'
    )
    for fc_m in _F6C_LATIN_RE.finditer(text):
        noun = fc_m.group('noun')
        if not noun or len(noun) < 2:
            continue
        if noun in seen_norms:
            continue
        seen_norms.add(noun)
        extras.append((fc_m.group(0), noun))

    # R30 mechanism #6 (2026-05-03): parenthetical abbreviation bridging.
    # Pattern B intros like `<full term>(<Abbr>)` should register both
    # full and abbrev so later `所述<Abbr>` references resolve.
    # Phase 2c Refinement B (Christopher: LHT/VH-region pattern is common).
    # CN form: `中心单元-控制面(CU-CP)`, `超参数自适应选择策略单元(HASS)`.
    # R34 (2026-05-04): mirror of TW R34 widening \u2014 accept full-width
    # \u5168\u89d2 parens AND lowercase-full-form-then-uppercase-abbrev shape
    # (`\u7528\u6237\u8bbe\u5907(user equipment, UE)`). Cross-jurisdiction parity.
    _PAREN_ABBREV_RE_R30 = re.compile(
        r'([\u4e00-\u9fff]{2,12})'
        r'[(\uff08]\s*'
        r'(?:[a-z][A-Za-z0-9\- ]{0,40}[,;\uff0c\uff1b]\s*)?'
        r'([A-Z][A-Za-z0-9\-]{0,15})'
        r'\s*[)\uff09]'
    )
    for pa_m in _PAREN_ABBREV_RE_R30.finditer(text):
        full_noun = pa_m.group(1)
        abbrev = pa_m.group(2)
        if abbrev not in seen_norms and len(abbrev) >= 2:
            seen_norms.add(abbrev)
            extras.append((pa_m.group(0), abbrev))
        if full_noun not in seen_norms:
            seen_norms.add(full_noun)
            extras.append((pa_m.group(0), full_noun))

    # R50 (2026-05-05): Chinese-name-Latin-abbrev juxtaposition (no parens).
    # Drafters introduce telecom/protocol acronyms via Chinese-then-Latin
    # format with NO parens between them: `所述IGP报文包括类型长度值TLV`
    # introduces both 类型长度值 (the descriptor) AND TLV (the acronym).
    # Phase 1 cluster `SHAPE|CN|ASCII_UPPER:SHORT` (81 wfp / 0 legit on
    # supplement_v2 corpus, 2026-05-05).
    #
    # Trigger: must be preceded by Pattern B-style introducer
    # (`包括`/`包含`/`为`/`是`) so we don't over-extract from random
    # Chinese-Latin neighbor pairs.
    #
    # Boundary check after the Latin abbrev: punctuation, common
    # particles, sentence end. Prevents the regex from greedily eating
    # into mixed-script compound nouns where Latin and Chinese are
    # genuinely distinct tokens.
    #
    # Both the Chinese descriptor and Latin acronym register as intros;
    # the walker's normal exact-match resolves `所述TLV` references
    # against the Latin form.
    _CN_LATIN_ABBREV_RE = re.compile(
        r'(?:包括|包含|为|是)\s*'
        r'([一-鿿]{2,12})'
        r'([A-Z][A-Za-z0-9]{1,4})'
        r'(?=[，。；,;:、(（]|的|所述|实施|是|为|具有|$|\s)'
    )
    for la_m in _CN_LATIN_ABBREV_RE.finditer(text):
        chinese = la_m.group(1)
        latin = la_m.group(2)
        if latin not in seen_norms and len(latin) >= 2:
            seen_norms.add(latin)
            extras.append((la_m.group(0), latin))
        if chinese not in seen_norms:
            seen_norms.add(chinese)
            extras.append((la_m.group(0), chinese))

    # R50b (2026-05-05): AF-style Pattern A preamble juxtaposition.
    # Drafters embed acronyms in Pattern A preambles via function-role
    # suffix anchoring:
    #
    #   `一种由与通信网络相关联的应用功能AF实施的方法`
    #            └──── 应用功能AF: 应用功能 = "application function" descriptor,
    #                              AF = "Application Function" acronym
    #
    # Phase 1 supplement_v2 cluster SHAPE|CN|ASCII_UPPER:SHORT residual
    # 52 wfp after R50 (R50 only handles 包括/包含-triggered shapes).
    #
    # Anchor: well-known telecom/protocol function-role suffixes that
    # ALWAYS signal "<noun phrase><suffix><acronym>" pattern. Narrow
    # allowlist so we don't over-extract from random Chinese-Latin
    # neighbor pairs. Drafters universally use these CJK suffixes for
    # functional/network entities - high precision.
    _CN_FUNCTION_SUFFIXES = (
        r'功能|服务|系统|网络|设备|单元|协议|平面|层|消息|报文|网元|节点'
    )
    _CN_FUNCTION_LATIN_ABBREV_RE = re.compile(
        r'([一-鿿]{1,8}(?:' + _CN_FUNCTION_SUFFIXES + r'))'
        r'([A-Z][A-Za-z0-9]{1,4})'
        r'(?=[，。；,;:、(（]|的|所述|实施|是|为|具有|包括|包含|$|\s)'
    )
    for la_m in _CN_FUNCTION_LATIN_ABBREV_RE.finditer(text):
        chinese = la_m.group(1)
        latin = la_m.group(2)
        if latin not in seen_norms and len(latin) >= 2:
            seen_norms.add(latin)
            extras.append((la_m.group(0), latin))
        if chinese not in seen_norms:
            seen_norms.add(chinese)
            extras.append((la_m.group(0), chinese))

    # R51 (2026-05-05): facilitate-verb verbal-noun introduction.
    # CN method-claim drafters introduce verbal nouns via constructions
    # like `便于操作的执行` ("facilitates operation's execution") where
    # 操作 (the operation) is intended as a noun-introduction. Subsequent
    # `所述操作` references should resolve.
    #
    # Phase 1 supplement_v2 cluster `TAIL|CN|操作` + `HEAD|CN|操作`
    # (65 wfp / 0 legit, 13 distinct drafts).
    #
    # Trigger verbs limited to clear "facilitate/realize" semantics. NOT
    # 用于 (for-use-of, much broader and risks over-extraction). NOT
    # 使 / 让 (causative, too generic).
    #
    # Pattern: <facilitate-verb> <X> 的 <Y>
    #   register X as intro (Y is captured by other extractors)
    _CN_FACILITATE_VERBS = r'便于|促进|完成|实现|执行|支持|有助于'
    _CN_FACILITATE_X_DE_Y_RE = re.compile(
        r'(?:' + _CN_FACILITATE_VERBS + r')'
        r'([一-鿿]{2,8})'
        r'的[一-鿿]{1,8}'
    )
    for fv_m in _CN_FACILITATE_X_DE_Y_RE.finditer(text):
        x_term = fv_m.group(1)
        if x_term not in seen_norms and len(x_term) >= 2:
            seen_norms.add(x_term)
            extras.append((fv_m.group(0), x_term))

    # R37 (2026-05-04): mirror of TW R37 F22 - list-item bare-noun
    # extraction WITHOUT colon trigger. CN parity: parent claim
    # introduces multiple components in `<verb><N1>、<N2>以及<N3>`
    # comma-list shape:
    #   `导电端子包括差分信号端子、第一接地端子以及第二接地端子`
    # Trigger verbs limited to `包括`/`包含` (most reliable list verbs).
    # Each item must be 2-12 pure CJK chars (filters out fragments
    # with embedded Latin/digit/punctuation). Reference-prefix items
    # are skipped (they're not new intros).
    # R44 (2026-05-04): expand triggers to 具有/具备/设有/含有 BUT only
    # when the captured list has >=2 commas (3+ items) - single-comma
    # lists with these triggers were too noisy on R37/R38 gate-3
    # spec-support test. 3+ items strongly signal a list (not a
    # possessive or modifier sequence).
    _F22_NO_COLON_LIST_CN = re.compile(
        r'(?:包括|包含)'
        r'((?:[一-鿿]{2,12}[、，])+'
        r'(?:[一-鿿]{2,12}(?:以及|及|和|或))?'
        r'[一-鿿]{2,12})'
        r'|'
        r'(?:具有|具备|设有|含有)'
        r'((?:[一-鿿]{2,12}[、，]){2,}'
        r'(?:[一-鿿]{2,12}(?:以及|及|和|或))?'
        r'[一-鿿]{2,12})'
    )
    _F22_LIST_SPLIT_CN = re.compile(r'[、，]|以及|及|和|或')
    for fl_m in _F22_NO_COLON_LIST_CN.finditer(text):
        # Either group 1 (包括/包含 with >=1 comma) or group 2
        # (具有/具备/设有/含有 with >=2 commas) captures the list.
        list_text = fl_m.group(1) or fl_m.group(2)
        if not list_text:
            continue
        for item_raw in _F22_LIST_SPLIT_CN.split(list_text):
            item = item_raw.strip()
            if not item or len(item) < 2:
                continue
            if item.startswith(_REF_PREFIX_SET_CN):
                continue
            if not all('一' <= ch <= '鿿' for ch in item):
                continue
            if item in seen_norms:
                continue
            seen_norms.add(item)
            extras.append((fl_m.group(0), item))

    return cleaned + extras


# CN R66 (2026-09-02) - DEFINITIONAL FRAME, the mirror of TW R53.
# Same construction, same discriminator, confirmed present in the CN corpus
# before porting rather than assumed: 26 occurrences across 25 drafts, every
# one a real definition -
#   所述导体是扁平导线，所述扁平导线…
#   所述雷达为激光雷达，所述激光雷达…
#   所述第一单向离合器为被动单向离合器，所述被动单向离合器…
# The predicate complement is article-less, so no intro arm sees it and the
# drafter's own back-reference flags. See tw_claims._DEFINITIONAL_FRAME_RE_TW
# for the full rationale, including why a bare 为/系/是/由 pattern is unusable
# and why the drafter's own re-reference is the guard.
_DEFINITIONAL_FRAME_RE_CN = re.compile(
    "(?:" + "|".join(_REFERENCE_PREFIXES_CN) + ")" + r'[\u4e00-\u9fff]{2,12}'
    r'(?:\u4e3a|\u7cfb|\u662f|\u7531)'
    r'(?P<y>[\u4e00-\u9fff]{2,12})'
    r'(?:\u5f62\u6210|\u6784\u6210|\u5236\u6210|\u7ec4\u6210)?'
    r'[\uff0c,\u3002\uff1b;]\s*'
    + "(?:" + "|".join(_REFERENCE_PREFIXES_CN) + ")" + r'(?P=y)'
)


# Wave G (2026-10-26): the "or more" quantifiers, longest first. Two intro-side
# repairs follow from adding them to the quantifier alternation.
_OR_FAMILY_QUANTIFIERS_CN = tuple(sorted(
    (q for q in _INTRO_MULTI_QUANTIFIERS_CN if "或" in q and q.isalpha()), key=len, reverse=True,
))


# Wave H (2026-10-26): the 種 quantifiers added to the intro alternation. A
# span right after a determiner (該至少一種X) is a REFERENCE; before wave H its
# self-registration keyed a garbage 種X that resolved nothing, and letting it key
# a clean X would silence real defects (the item-13 mask). Skip only these.
_ZHONG_QUANTIFIERS_CN = ('至少一种', '至少两种', '至少二种', '至少三种', '复数种', '若干种', '数种', '二种', '三种', '四种', '一组')
_ZHONG_SELF_INTRO_DETERMINERS_CN = ("该", "所述", "前述")
# Wave K (2026-10-27): CN mirror of TW R82. The "one or more" family joins the
# 种 family in the self-skip and the shared-quantifier basis: 所述一个或多个X
# right after a determiner is a reference and no longer introduces itself.
_SELF_INTRO_QUANTIFIERS_CN = tuple(sorted(
    _ZHONG_QUANTIFIERS_CN + _OR_FAMILY_QUANTIFIERS_CN, key=len, reverse=True,
))
# The TW 所-relative guard and plain-一 rescan were measured here and carry
# nothing on the CN corpus, so they are not mirrored.


_INTRO_VERB_YI_CN = ("产生一", "包括一", "包含一", "具有一", "形成一", "提供一", "生成一")
# The rescan also covers the 種 quantifiers (至少一種適體或至少一種寡核苷酸).
_RESCAN_QUANTIFIERS_CN = _OR_FAMILY_QUANTIFIERS_CN + tuple(
    q for q in _ZHONG_QUANTIFIERS_CN if len(q) >= 3
)


def _shared_zhong_mention_cn(term: str, chain, ref_start: int) -> bool:
    """A reference written with a 種 quantifier (該至少一種X) has basis in an
    earlier mention written with one, outside a determiner, in the same clause:
    至少一種X接觸… (a predicate the cleaner cannot strip safely: 接觸 / 結合 /
    功能化 are noun-gray), 至少一種下述X, 至少一種具有以下通式之X. The shared
    quantifier is the evidence; a bare 該X gets no such reading."""
    if len(term) < 2:
        return False
    ordinal_gray = ("二种", "三种", "四种")
    quant = re.compile(
        "|".join(
            ("(?<!第)" if q.startswith("一") else "") + re.escape(q)
            for q in _SELF_INTRO_QUANTIFIERS_CN
            if q not in ordinal_gray
        )
        + "|(?<!第)[二三四]种"
    )
    pat = re.compile("[^，。；：、,;:]{0,20}?" + re.escape(term))
    texts = [a.text for a in chain[1:]] + [chain[0].text[:ref_start]]
    for text in texts:
        for q in quant.finditer(text):
            # match from EVERY quantifier: an earlier rejected one must not
            # consume a later one (該至少一種A…的至少一種X).
            mm = pat.match(text, q.end())
            if not mm:
                continue
            noun_at = mm.end() - len(term)
            if not text[: q.start()].endswith(_ZHONG_SELF_INTRO_DETERMINERS_CN) and not text[:noun_at].endswith(_ZHONG_SELF_INTRO_DETERMINERS_CN):
                return True
    return False


def _same_quantifier_stem_cn(term: str, raw_noun: str, chain, ref_start: int) -> bool:
    """An "or more" quantified reference whose noun carries predicate residue
    (所述一个或多个附加轴内操作) has basis in an earlier mention with the SAME
    quantifier, outside a determiner, sharing a stem of three or more
    characters, or a one-character element whose mention ends at the
    character or is a possessive part of an owner (ruling R6)."""
    lead = next((q for q in _OR_FAMILY_QUANTIFIERS_CN if raw_noun.startswith(q)), "")
    if not lead or len(term) < 2 or not raw_noun[len(lead):].startswith(term[:2]):
        return False
    texts = [a.text for a in chain[1:]] + [chain[0].text[:ref_start]]
    for text in texts:
        if len(term) >= 3:
            # a line break can leave a space inside the run (一个或多个 处理器)
            for mm in re.finditer(r"\s*".join(map(re.escape, lead + term[:3])), text):
                if not text[: mm.start()].endswith(_ZHONG_SELF_INTRO_DETERMINERS_CN):
                    return True
        for mm in re.finditer(re.escape(lead + term[0]), text):
            before = text[: mm.start()]
            det = next((d for d in _ZHONG_SELF_INTRO_DETERMINERS_CN if before.endswith(d)), "")
            if not det:
                nxt = text[mm.end(): mm.end() + 1]
                if not nxt or nxt in "，。；：、,;:" or nxt in _BARE_NOUN_BOUNDARY_CN:
                    return True
            elif before[: -len(det)].endswith(("的", "之")):
                return True
    return False


_INSIDE_REFERENCE_RUN_CN = re.compile(r"(?:所述|前述|该)[^，。；：、,;:\s]{0,10}$")


def _skipped_self_intro_keys_cn(chain) -> set[str]:
    """The keys the determiner + "or more" spans (所述一个或多个X) registered
    before wave K stopped them introducing themselves."""
    keys: set[str] = set()
    for a in chain:
        for m in _INTRO_PATTERN_CN.finditer(a.text):
            q = next((q for q in _OR_FAMILY_QUANTIFIERS_CN if m.group(0).startswith(q)), "")
            if q and _is_zhong_self_intro_cn(m, a.text):
                for cand in _postprocess_intro_capture_cn(m.group(1), m, a.text):
                    keys.add(normalize_candidate_intro_cn(cand))
    return keys


def _bare_earlier_mention_cn(term: str, chain, ref_start: int) -> bool:
    """A term the draft also named article-less keeps the basis that a
    determiner + "or more" span, which wave K no longer registers, used to
    give it. Only references that are the element's sole mentions are
    unmasked; nothing else changes."""
    if term not in _skipped_self_intro_keys_cn(chain):
        return False
    texts = [a.text for a in chain[1:]] + [chain[0].text[:ref_start]]
    for text in texts:
        for mm in re.finditer(re.escape(term), text):
            if not _INSIDE_REFERENCE_RUN_CN.search(text[: mm.start()]):
                return True
    return False


def _zu_set_reference_intro_cn(rest: str, intros_by_term, chain, ref_start: int) -> str | None:
    """The intro a 該组X reference names once 一组X keys X: exact, then the
    longest introduced prefix (the reference may carry residue), then an
    earlier same-clause mention with a quantifier."""
    if rest in intros_by_term:
        return rest
    best = max((i for i in intros_by_term if len(i) >= 2 and rest.startswith(i)), key=len, default=None)
    if best:
        return best
    return rest if _shared_zhong_mention_cn(rest, chain, ref_start) else None


def _is_zhong_self_intro_cn(m, text: str) -> bool:
    q = next((q for q in _SELF_INTRO_QUANTIFIERS_CN if m.group(0).startswith(q)), "")
    if not q or q == "一组":
        # 所述一组 is also "the set" itself (所述一组是第一組): left as before.
        return False
    # 該至少一種X, and 複數種前述X (the determiner after the quantifier)
    if q in _OR_FAMILY_QUANTIFIERS_CN:
        det = next((d for d in _ZHONG_SELF_INTRO_DETERMINERS_CN if text[: m.start()].endswith(d)), "")
        if det and text[: m.start() - len(det)].endswith(("的", "之")):
            # 所述光子堆叠的所述一个或多个腔: a part of an introduced owner (ruling R6).
            return False
    return text[: m.start()].endswith(_ZHONG_SELF_INTRO_DETERMINERS_CN) or m.group(0)[
        len(q):
    ].startswith(_ZHONG_SELF_INTRO_DETERMINERS_CN)


def _iter_intro_matches_cn(text: str):
    """finditer over the intro pattern, plus a rescan wherever a match's noun
    span swallowed a later "or more" quantifier. The longer quantifiers spend
    more of the 12-character budget, so 两个或多个副本分别传送至两个或多个输出接口 kept only the
    first intro."""
    for m in _INTRO_PATTERN_CN.finditer(text):
        if not _is_zhong_self_intro_cn(m, text):
            yield m
        start = m.start(1) + 1
        while True:
            hits = [i for i in (text.find(q, start, m.end()) for q in _RESCAN_QUANTIFIERS_CN) if i >= 0]
            if m.group(0).startswith(_SELF_INTRO_QUANTIFIERS_CN):
                # A 種 span can swallow a following 產生一X intro.
                hits += [i + 2 for i in (text.find(v, start, m.end()) for v in _INTRO_VERB_YI_CN) if i >= 0]
            if not hits:
                break
            mm = _INTRO_PATTERN_CN.match(text, min(hits))
            if mm and mm.end() >= m.end() and not _is_zhong_self_intro_cn(mm, text):
                yield mm
            start = min(hits) + 1


def _or_family_shi_intro_cn(m, text: str) -> tuple[str, str] | None:
    """时 is not a noun character, so 兩個或更多個时間點 matched only its own
    quantifier. Take the 时 compound when its suffix makes it a noun (the
    reference capture's follow-gate); the general intro 时 gate stays withheld."""
    original = m.group(0)
    if original not in _OR_FAMILY_QUANTIFIERS_CN:
        return None
    end = m.end()
    if not text.startswith("时", end) or text[end + 1: end + 2] not in _SHI_NOUN_SUFFIXES_CN:
        return None
    ext_m = _NOUN_EXT_RE_CN.match(text, end + 1)
    bare = "时" + (ext_m.group()[:11] if ext_m else "")
    return original + bare, bare


_ABBREV_INTRO_LEADS_CN = tuple(q for q in _PRE_CLEAN_QUANTIFIERS_CN if q not in ("一些", "某些")) + ("一",)
_ABBREV_INTRO_RE_CN = re.compile(
    r"(?<![第統统同唯單单])(?P<lead>"
    + "|".join(re.escape(q) for q in sorted(_ABBREV_INTRO_LEADS_CN, key=len, reverse=True))
    + r")(?P<exp>[\u4e00-\u9fff/]{2,12}?)[(（](?P<abbr>(?=[0-9]*[A-Za-z])[A-Za-z0-9][A-Za-z0-9/\-]{0,9})[)）]"
    r"(?P<tail>[\u4e00-\u9fff]{1,8})"
)


def _abbreviation_intros_cn(claim) -> list[tuple[str, str]]:
    """Wave K (2026-10-27): an introduction that spells out an abbreviation,
    一个或多个人工智能/机器学习(AI/ML)模型 or 一二維(2D)影像, also introduces the
    abbreviated name (AI/ML模型, 2D影像) the later references use. Walker only:
    in the shared extractor it reached spec-support (TW 59 -> 66, CN +5)."""
    pairs: list[tuple[str, str]] = []
    for am in _ABBREV_INTRO_RE_CN.finditer(claim.text):
        if len(am.group("exp")) > 2 * len(am.group("abbr").replace("/", "")) + 1:
            # the expansion must be the spelled-out name, not a clause
            # running into it (多個第二垂直互連形成三維(3D)電感器)
            continue
        abbr_norm = normalize_candidate_intro_cn(am.group("abbr") + am.group("tail"))
        if len(abbr_norm) >= 3:
            pairs.append((am.group(0), abbr_norm))
    return pairs

def extract_introductions_cn(
    claim: Claim,
    *,
    strict_qualifier_matching: bool = False,
) -> list[tuple[str, str]]:
    """Extract introductions from a CN claim as (original, normalized) pairs."""
    pairs: list[tuple[str, str]] = []
    seen: set[str] = set()
    for m in _iter_intro_matches_cn(claim.text):
        original = m.group(0)
        bare_noun = m.group(1)
        shi_intro = _or_family_shi_intro_cn(m, claim.text)
        if shi_intro:
            original, bare_noun = shi_intro
        # Wave F (2026-10-26): the 能 follow-gate the reference capture already
        # has. 能 is not a noun character, so 一个或多个身体功能 was captured as
        # 身体功 and normalized to a phantom 身体 that resolved a real 所述身体.
        # The 时 / 应 gates were measured here too and NOT mirrored: they
        # manufactured 68 TW findings (服務時段, 主持續時間期間).
        bare_noun, _ = _extend_neng_compound_cn(bare_noun, m.end(), claim.text)
        # R62 (2026-08-13) - TW R39 parity: 一对 measure-word disambiguation.
        # The split happens HERE, in the match, not in the normalizer.
        # `original == 一对 + bare_noun` is load-bearing - see the TW twin.
        # Without it, `同一对象` (where the pattern correctly matched 一 +
        # 对象) got a second 对 prepended, manufacturing 2 findings on
        # CN119343088A c14/c16.
        if (original == "一对" + bare_noun
                and _yidui_is_noun_initial_dui_cn(original, claim.text)):
            bare_noun = "对" + bare_noun
        candidates = _postprocess_intro_capture_cn(bare_noun, m, claim.text)
        for candidate in candidates:
            normalized = normalize_candidate_intro_cn(
                candidate,
                strict_qualifier_matching=strict_qualifier_matching,
            )
            if not normalized:
                continue
            if normalized not in seen:
                seen.add(normalized)
                pairs.append((original, normalized))

        # R67 (2026-05-08) - symmetric state-modifier+head-noun lookahead.
        # CN parity with the TW R67 intro-side extension. Mirrors the
        # walker reference-side R66 logic so consistent intro+ref pairs
        # like `一岛状的纳米片积层体` ↔ `所述岛状的纳米片积层体` resolve
        # without spurious walker_fp. Also drops the bare state-modifier
        # form (e.g. `岛状`) from inventory once the extended form is
        # captured - bare 岛状 alone is the modifier, not a claim noun.
        if (
            bare_noun.endswith(_STATE_MODIFIER_SUFFIXES_CN)
            and not bare_noun.startswith("第")
        ):
            m_de = _DE_HEAD_NOUN_RE_CN.match(claim.text, m.end())
            if m_de:
                head_raw = m_de.group("head")
                extended_bare = bare_noun + "的" + head_raw
                extended_normalized = normalize_candidate_intro_cn(
                    extended_bare,
                    strict_qualifier_matching=strict_qualifier_matching,
                )
                if extended_normalized:
                    bare_norms_to_drop: set[str] = set()
                    for cand in candidates:
                        cand_norm = normalize_candidate_intro_cn(
                            cand,
                            strict_qualifier_matching=strict_qualifier_matching,
                        )
                        if (
                            cand_norm
                            and cand_norm != extended_normalized
                            and cand_norm.endswith(_STATE_MODIFIER_SUFFIXES_CN)
                        ):
                            bare_norms_to_drop.add(cand_norm)
                    if bare_norms_to_drop:
                        seen -= bare_norms_to_drop
                        pairs[:] = [
                            (o, n) for (o, n) in pairs
                            if n not in bare_norms_to_drop
                        ]
                    if extended_normalized not in seen:
                        seen.add(extended_normalized)
                        extended_original = original + "的" + head_raw
                        pairs.append((extended_original, extended_normalized))

    # R7 (2026-04-30): also apply strip_leading_verb_cn to supplementary
    # intros so a captured `制造方法` (from F14 on `之制造方法`) registers
    # as `方法` after stripping the leading 制造 verb prefix - matching
    # the canonical method-claim head-noun reference `所述方法`.
    supplementary = _extract_supplementary_intros_cn(claim.text)
    for orig, norm in supplementary:
        # R63 (2026-05-05) parity with TW - apply Arabic→CJK ordinal
        # normalize so claim 1 supplementary intro `第1间隔件` registers
        # as `第一间隔件`, matching dep claim references that go through
        # `normalize_reference_term_cn` which already applies the convert.
        # Without this the asymmetry produces spurious walker_fp findings
        # on CN drafts using Arabic-ordinal element naming.
        norm = normalize_arabic_ordinal_to_cjk(norm)
        norm = strip_leading_verb_cn(norm)
        if not norm or norm in seen:
            continue
        # R32 (2026-05-04): TW parity - drop intros with newline/colon
        # (capture crossed paragraph or label boundary). Spec-support
        # reads intros directly so guard at extraction time.
        if '\n' in norm or '：' in norm or ':' in norm:
            continue
        seen.add(norm)
        pairs.append((orig, norm))

    # R32 (2026-05-04): F-head-indep - capture rightmost head noun from
    # `一种<modifier>的<HEAD>，` independent-claim preambles. CN parity
    # with TW R32. Default `_INTRO_PATTERN_CN` excludes `的` from the
    # noun class, so a long preamble like `用于X的Y的装置` only captures
    # fragment intros, leaving the canonical head `装置` unregistered
    # for downstream `所述装置` references in dependent claims.
    #
    # Conflict guard: skip registration when claim text contains a
    # `<head><positional-suffix>` form (装置侧, 处理器端) that would be
    # a distinct §112 entity. Without this, prefix-match resolves
    # `所述装置侧` → `装置` and masks legit drafting errors (CN115485995B
    # c121 protect:true label).
    for m in _F_HEAD_INDEP_RE_CN.finditer(claim.text):
        head = m.group('head')
        if not head or head in seen:
            continue
        if _f_head_indep_conflict_cn(head, claim.text):
            continue
        seen.add(head)
        pairs.append((m.group(0), head))

    # CN R66: definitional frame - see _DEFINITIONAL_FRAME_RE_CN.
    for m in _DEFINITIONAL_FRAME_RE_CN.finditer(claim.text):
        y_raw = m.group('y')
        y_norm = normalize_candidate_intro_cn(
            y_raw,
            strict_qualifier_matching=strict_qualifier_matching,
        )
        for candidate in (y_norm, y_raw):
            if candidate and candidate not in seen:
                seen.add(candidate)
                pairs.append((m.group(0), candidate))


    return pairs


# R32 (2026-05-04): F-head-indep regex (CN parity with TW). Captures
# rightmost head noun in `一种<modifier>的<HEAD>，` preambles.
# Conflict guard applied at registration time (not in regex): the head
# is rejected if `<head><1-3 CJK>` appears elsewhere in the claim text,
# since prefix-match resolution would over-resolve longer references
# onto the captured head (CN115485995B c121: `装置 + 装置侧` collision
# masks legit drafting error). The narrower regex (lookahead trailing
# verbs) was tried but lost ~95 walker_fp silences in CN, ~135 in TW;
# the conflict-guard approach preserves silence yield while protecting
# protect:true labels.
_F_HEAD_INDEP_RE_CN: re.Pattern[str] = re.compile(
    r'一种(?:[^，。；,;:：]{4,80})的'
    r'(?P<head>[一-鿿]{2,12})'
    r'(?=[，,。；;:：])'
)


_F_HEAD_POSITIONAL_SUFFIX_RE_CN: re.Pattern[str] = re.compile(
    r'(?:侧|端|部|面|段|层|区|际|际面|底|顶|前|后|左|右|内|外|上|下|侧面|端面|端部|底部|顶部|前面|后面|左面|右面|内部|外部|上部|下部|内侧|外侧|内端|外端|内层|外层|内面|外面)'
)


def _f_head_indep_conflict_cn(head: str, claim_text: str) -> bool:
    """True if registering `head` would cause prefix-match over-resolution.

    R32 (2026-05-04): scan for `<head><positional-suffix>` patterns where
    the suffix indicates a DIFFERENT entity (装置侧 vs 装置, 处理器端 vs
    处理器). Positional suffixes (侧/端/部/面/段/底/顶/前/后/左/右/内/外/上/下
    + compounds) frequently create distinct claim elements; prefix-match
    would wrongly resolve them. Compound-noun patterns (装置中的, 装置包括)
    don't trigger because they require additional non-suffix CJK after.
    """
    pattern = re.compile(re.escape(head) + r'(?:' + _F_HEAD_POSITIONAL_SUFFIX_RE_CN.pattern + r')(?:[，,。；;:： \t]|$)')
    return bool(pattern.search(claim_text))


def full_ref_starts_with_plural_cn(text: str) -> bool:
    """True iff text begins with a plural quantifier marker."""
    return text.startswith(("复数", "多个", "数个", "复数个"))


_BARE_GENUS_NOUNS_CN: frozenset[str] = frozenset({
    "方法", "装置", "系统", "设备", "组件",
    "模块", "单元", "电路", "部件", "芯片",
})

_GENUS_PREAMBLE_RE_CN: re.Pattern[str] = re.compile(
    r"(?:(?:如|根据)权利要求[^，。\n]*?" + _CN_DEP_CONNECTIVE + r"[^，。\n]*?|一种[^，。\n]*?)"
    r"(?:方法|装置|系统|设备|组件|模块|单元|电路|部件|芯片)[，,\s]"
)


# Phase 8c R22 - chemistry formula reference like 式(1) / 式(L-4) / 式(I).
# These are bibliographic-style references to formulae defined elsewhere in
# the spec, not noun terms; missing-antecedent doesn't apply.
_FORMULA_REFERENCE_RE_CN: re.Pattern[str] = re.compile(r"^式\([^)]+\)$")

# Phase 8c R22 - verb-predicate term suppression. Walker captured a bare
# verbal idiom (e.g., 安装有 from 使得安装有X的Y); the trailing-strip already
# eliminated the noun head, leaving the pure predicate as the term.
# R23 extends with cascade-product predicates from over_capture round
# (加入胰蛋白酶消化 → 加入; 加热沸腾提取 → 加热沸腾).
_VERB_PREDICATE_TERMS_CN: frozenset[str] = frozenset({
    "安装有", "存储有", "形成有", "设置有",
    "加入", "加热沸腾",
    # R68 (2026-05-06) - TW parity. Pure-action verbs from supplement_v2
    # walker_fp mining (n=6289 CN walker_fp): 确定 ~15, 进行 ~3, 获得,
    # 判断, 执行, 完成. Safe-suppress: drafters never use as standalone
    # noun antecedents; appear only in compounds (确定值/获得结果 etc.).
    "确定", "进行", "获得", "判断", "执行", "完成",
})


_FORMULA_ORDINAL_RE_CN: re.Pattern[str] = re.compile(r"^第[A-Za-z]")
_BARE_ORDINAL_RE_CN: re.Pattern[str] = re.compile(
    r"^第[一二三四五六七八九十\d]+$"
)


# Phase 8c R21 - DYM quality gate. Audit (docs/8c/suggested-match-audit.md,
# Phase 9 #57) showed 85% of corpus DYMs have substring-relationship with
# the reference; ~30% of those are over-captured garbage the walker's intro
# extraction pool emitted as legitimate intros. These filters reject DYM
# candidates the Jaccard loop already picked, without changing the finding
# pool. Non-shifting - `suggested_match` is terminal-only.
_DYM_LEADING_REJECTS_CN: tuple[str, ...] = (
    "能够由", "响应于", "针对", "基于",
    "对", "从", "向", "为", "在",
    "与", "和", "以", "于", "且", "还", "由", "被",
)

_DYM_STOP_PARTICLES_CN: tuple[str, ...] = (
    "的", "于", "在", "为", "对", "从", "向",
    "与", "和", "以", "且", "还", "由", "被",
    "所述", "前述", "该",
    "能够由", "响应于", "针对", "基于",
    "初始化时", "之前", "之后",
)


def _dym_quality_reject_cn(ref: str, dym: str) -> bool:
    """True if DYM should be suppressed.

    Three filters:
      1. `len(dym) > 2 * len(ref)` - disproportionate expansion.
      2. DYM starts with a token in `_DYM_LEADING_REJECTS_CN` - walker
         captured a prep/particle-headed fragment, not a clean NP.
      3. `ref in dym` strict substring AND the wrapping chars contain any
         stop-particle - walker captured the ref + noise.
    """
    if len(dym) > 2 * len(ref):
        return True
    for prefix in _DYM_LEADING_REJECTS_CN:
        if dym.startswith(prefix):
            return True
    if len(ref) < len(dym) and ref in dym:
        idx = dym.index(ref)
        before = dym[:idx]
        after = dym[idx + len(ref):]
        if any(p in before or p in after for p in _DYM_STOP_PARTICLES_CN):
            return True
    return False


def _is_bare_genus_self_reference_cn(term: str, claim_text: str) -> bool:
    """Suppress bare-genus self-references in claim preambles (WQ5).

    When the claim's preamble declares the genus as its subject - either
    the dependent form ``(如|根据)权利要求N所述的<genus>`` or the independent
    form ``一种...<genus>，`` - a bare ``所述<genus>`` later in the body is
    a trivial self-reference, not a missing antecedent. Phase 8c close-out
    R1.
    """
    if term not in _BARE_GENUS_NOUNS_CN:
        return False
    return bool(_GENUS_PREAMBLE_RE_CN.search(claim_text))


# R35 (2026-05-23) - bare-noun-introduction rescue (CN mirror of TW R7
# has_bare_noun_introduction_tw and US R4 utils.has_bare_noun_introduction).
#
# A multi-character noun first mentioned article-less -- as a verb or
# coverb object (接收输入信号 / 基于超宽频连接) or a clause / enumeration
# item -- establishes antecedent basis under the same MPEP s 2173.05(e)
# reasonable-ascertainability standard CNIPA 审查指南 applies (清楚 /
# 明确). The intro extractors register only quantified / framed intros
# plus F10 de-NOUN gated to component-suffix nouns, so article-less data
# / attribute nouns slip through.
#
# Two CJK-aware guards (the two bugs that halted the naive TW R5 port):
#   (a) whole-compound-boundary -- an occurrence whose neighbour char is
#       a noun-compounding CJK ideograph is the tail / head of a longer
#       compound, not a standalone mention.
#   (b) possessive guard -- an occurrence headed by 的 or 之 is never
#       counted: <noun>的X is surface-identical to a <verb-phrase>的X
#       relative clause. The F10 extractor already handles the safely-
#       disambiguable subset (component-suffix nouns); the rescue defers
#       to F10 there and rejects 的 / 之 outright.
_BARE_NOUN_INTRO_VERBS_CN: tuple[str, ...] = tuple(
    sorted(
        {v for v in _F6_VERB_ALT_CN.split("|") if v}
        | {"基于", "来自", "通过", "经由", "利用", "依据", "依"}
        # R36 (2026-05-29): include F11 locative verbs as bare-noun-intro
        # contexts. Issues #141 / #142 - drafter wrote
        # `限位于第三位置或第四位置二者之一` (constrained to be at position 3 or
        # position 4, one of the two). The `endswith(verb)` left-clean
        # check missed because `位于` / `设于` / `置于` etc. are the
        # canonical locative verbs in CN claim diction yet weren't in the
        # bare-noun verb set. Already known to other arms (F11 at line
        # 2194). MPEP-equivalent: 审查指南 第二部分第二章 §3.2.5
        # (clear/明确 standard).
        | {"位于", "置于", "设于", "应用于", "作用于", "布置于", "固定于"}
        # Wave D (2026-10-25): bare 有 and 导入 introduce their object (TW
        # mirror); 所有/没有/只有/仅有 quantify or negate.
        | {"有", "导入"}
        # Wave D: bare 在 (TW R8 mirror): 在X下 / 在X中 names X article-less, an
        # introduction under the 2026-10-23 CN ruling.
        | {"在"},
        key=len,
        reverse=True,
    )
)
# Noun-compounding CJK ideographs = CJK range minus the _NOUN_CHARS_CN
# exclusion set (clause stops, conjunctions, possessive markers, modals).
_BARE_NOUN_BOUNDARY_CN: frozenset[str] = frozenset(
    set(_NOUN_CHARS_CN[_NOUN_CHARS_CN.index("s") + 1 : _NOUN_CHARS_CN.index("]")])
    # R36 (2026-05-29): 或 (or) is a Markush enumerator that separates
    # bare noun mentions in claim diction; never part of a noun's name.
    # Issues #141 / #142 - drafter wrote `限位于第三位置或第四位置二者之一`;
    # without 或 in the boundary set, `_bare_noun_right_clean_cn`
    # treated `第三位置或...` as a longer compound and rejected the
    # bare intro.
    | {"或"}
    # R39 (2026-06-11): 至 (goal-preposition "to") terminates a verb-object
    # bare-noun introduction. Issues #221/#222/#223 - drafter wrote
    # `通过该主机发送控制指令至该显示器`; the object `控制指令` is a complete
    # bare-noun intro, but without 至 in the boundary set
    # `_bare_noun_right_clean_cn` treated `控制指令至...` as a longer
    # compound and rejected it, so `该控制指令` was flagged as lacking
    # antecedent. 至 is a goal-preposition, never a noun-compound interior
    # char (夏至/冬至 END in 至; it is not a continuation char after a
    # noun). Corpus-neutral: ephemeral sim showed 0 delta across all 16
    # CN fixtures (the verb-object-至 pattern is not in the corpus pool).
    | {"至"}
)
_BARE_NOUN_CJK_RE_CN: re.Pattern[str] = re.compile(r"[一-鿿]")
_BARE_NOUN_MIN_LEN_CN = 4


def _bare_noun_compound_char_cn(c: str) -> bool:
    """True if c is a CJK ideograph that compounds into a noun phrase."""
    return bool(_BARE_NOUN_CJK_RE_CN.match(c)) and c not in _BARE_NOUN_BOUNDARY_CN


def _bare_noun_left_clean_cn(text: str, i: int) -> bool:
    """True if the occurrence at i is a fresh, article-less left boundary."""
    if i == 0:
        return True
    if text[i - 1] in ("该", "一"):
        return False  # reference / quantifier
    if i >= 2 and text[i - 2:i] in ("所述", "前述"):
        return False
    if text[:i].endswith(_BARE_NOUN_NON_INTRO_YOU_CN) or _bare_noun_after_you_word_cn(text, i):
        return False
    # Verb-object / coverb-object: the run before the term ends with a
    # verb. Checked first -- coverbs (基于) end in a boundary char (于).
    if any(text[:i].endswith(v) for v in _BARE_NOUN_INTRO_VERBS_CN):
        return True
    c = text[i - 1]
    if c.isspace() or unicodedata.category(c)[0] == "P":
        return True  # clause boundary / enumeration item
    # R36 (2026-05-29): CJK noun-enumeration conjunctions ({或, 及, 与, 和})
    # are clause boundaries - they introduce the next noun in a Markush
    # `A或B`, `A、B及C`, etc. enumeration. Issues #141 / #142 - drafter
    # wrote `限位于第三位置或第四位置二者之一`; the second mention `第四位置`
    # is preceded by `或` (CJK letter, not Unicode punctuation), so the
    # Unicode-category check above missed it.
    #
    # Critical narrowing: this set MUST NOT include 的 / 之 / 其 / 被 / 由
    # even though they're in `_BARE_NOUN_BOUNDARY_CN`. They're possessive /
    # pronoun / passive markers that head relative clauses (e.g.
    # `所述X相关的Y` = "the Y related to X"), where Y is NOT a fresh bare
    # intro - that's exactly the guard (b) the function docstring describes.
    # Accepting them would silence real §112(b) defects like
    # CN115485995B c82/c124's `第一训练信号` (R20 parallel-invention
    # drafter-error protect:true labels).
    if c in _BARE_NOUN_ENUMERATORS_CN:
        return True
    # CJK ideograph not preceded by a verb -- compound tail (guard a),
    # 的 / 之 possessive marker (guard b), or a conjunction / modal not
    # verb-led. All rejected conservatively.
    return False


def _bare_noun_verb_led_cn(text: str, i: int) -> bool:
    """True if the occurrence at i is the object of an introducing verb."""
    if i == 0 or text[i - 1] in ("该", "一"):
        return False
    if i >= 2 and text[i - 2:i] in ("所述", "前述"):
        return False
    # After 进行 / 执行 / 运行 the word is an action, after 经 a participle.
    if text[:i].endswith(_BARE_NOUN_ACTION_LEADS_CN) or text.startswith("经", i):
        return False
    if text[:i].endswith(_BARE_NOUN_NON_INTRO_YOU_CN) or _bare_noun_after_you_word_cn(text, i):
        return False
    return any(text[:i].endswith(v) for v in _BARE_NOUN_INTRO_VERBS_CN)


_BARE_NOUN_ACTION_LEADS_CN: tuple[str, ...] = ("进行", "执行", "运行", "实行", "实施", "经")
# Bare 有 introduces only as a verb; after these it quantifies or negates.
_BARE_NOUN_NON_INTRO_YOU_CN: tuple[str, ...] = ("所有", "没有", "只有", "仅有", "未有", "唯有")
# 有 also opens words (有機, 有源, 有損); a term starting right after such a
# 有 is a fragment of that word, not the object of the verb.
_BARE_NOUN_YOU_WORD_TAILS_CN: frozenset[str] = frozenset("机源损效限线色益关利害毒序形声理名向功界")


def _bare_noun_after_you_word_cn(text: str, i: int) -> bool:
    """True if a bare 有 before i is the head of a word, not the verb."""
    return (
        text[:i].endswith("有")
        and not text[:i].endswith(('具有', '设有', '含有'))
        and text[i:i + 1] in _BARE_NOUN_YOU_WORD_TAILS_CN
    )
# A word followed straight by a determiner is a verb taking its object.
_BARE_NOUN_OBJECT_DETERMINERS_CN: tuple[str, ...] = ("该", "所述", "前述", "一")


_BARE_NOUN_MARKUSH_CLOSERS_CN: tuple[str, ...] = ("二者", "三者", "四者", "任一", "任意")

# R36 (2026-05-29): CJK noun-enumeration conjunctions accepted as left
# boundaries in `_bare_noun_left_clean_cn`. Strict subset of
# `_BARE_NOUN_BOUNDARY_CN` - explicitly excludes 的 / 之 / 其 / 被 / 由
# (possessive / pronoun / passive markers) which head relative clauses
# and must remain rejected per guard (b).
_BARE_NOUN_ENUMERATORS_CN: frozenset[str] = frozenset({"或", "及", "与", "和"})


def _bare_noun_right_clean_cn(text: str, j: int) -> bool:
    """True if the term is not the head of a longer noun compound (guard a)."""
    if j >= len(text):
        return True
    # R36 (2026-05-29): Markush closers `N者` / `任一` mark the end of an
    # `X或Y二者之一` enumeration - the term is the last enumeration item,
    # not the head of a longer compound. Issues #141 / #142 - drafter
    # wrote `第三位置或第四位置二者之一`; without this carve-out the right
    # side of `第四位置` was `二` (CJK char, not a boundary), so the bare
    # intro was rejected. The closers are unambiguous Markush idioms;
    # `第二X` wouldn't end a term that starts mid-compound just before
    # `第二` (drafters separate enumeration items with 或 / 、).
    if any(text[j:].startswith(closer) for closer in _BARE_NOUN_MARKUSH_CLOSERS_CN):
        return True
    # Wave D: the 在…下 locative ends the noun (在升壓模式下藉由…), matching the
    # trailing 下 strip in the normalizer; 下方 / 下部 / 下端 are words.
    if text[j] == "下" and text[j + 1:j + 2] not in "方部端侧面层缘游表":
        return True
    # Wave E: a coverb taking its own determiner object (輸出旋轉通過所述軸) ends
    # the noun; 通過 is never noun-internal right before 所述 / 該 / 一.
    if any(text.startswith(c, j) and text.startswith(("所述", "该", "前述", "一"), j + 2)
           for c in ("通过", "经由", "经过")):
        return True
    return not _bare_noun_compound_char_cn(text[j])


_NEW_ARGUMENT_COVERBS_CN: tuple[str, ...] = ("用于", "以", "对", "为", "将", "被", "使")


# CN R79 (wave D) - PREDICATE-TAIL INTRO TIER, the mirror of TW R66.
# The introduction capture ran past its head into a predicate (a coverb, a
# locative postposition, or a short verb taking an object), so the drafter's
# clean 所述<head> matched nothing. Same positional signals as TW, no verb
# list, and the intro must itself be a real introduction (a quantifier right
# before it, or a possessive whose possessor is introduced). Additive: runs
# only after the exact, prefix and R46 tiers fail, so it can only silence.
_PREDICATE_OBJECT_OPENERS_CN: tuple[str, ...] = (
    "所述", "前述", "至少一", "多个", "每一", "该", "其", "一",
)
_LOCATIVE_POSTPOSITIONS_CN: frozenset[str] = frozenset("下中内上")
_COVERBS_CN: frozenset[str] = frozenset("自至向往给对")
_DUI_LEXEME_CHARS_CN: frozenset[str] = frozenset("应位称接齐准象话")
_INTRO_QUANTIFIER_OPENERS_CN: tuple[str, ...] = (
    "至少一", "多个", "两个", "数个", "每一", "若干", "一",
)
_TAIL_STOP_CHARS_CN = frozenset("或与及和、，。；：的之")


def _intro_opens_as_introduction_cn(text: str, pos: int, intros_by_term) -> bool:
    """True when the mention of an intro at ``pos`` is a real introduction."""
    before = text[max(0, pos - 16):pos]
    for q in _INTRO_QUANTIFIER_OPENERS_CN:
        if before.endswith(q):
            lead = before[: len(before) - len(q)]
            return not lead or lead[-1] not in "进统唯同单第万"
    if before.endswith(("的", "之")):
        for det in ("所述", "前述", "该"):
            k = before.rfind(det)
            if k >= 0 and before[k + len(det):-1] in intros_by_term:
                return True
    return False


def _predicate_tail_intro_cn(term, intros_by_term, chain, claim, ref_start):
    """The introduction that is ``term`` plus a predicate tail, if any."""
    if len(term) < 2:
        return None
    by_id = {c.id: c for c in chain}
    for intro, (ancestor_id, _depth) in intros_by_term.items():
        if len(intro) <= len(term) or not intro.startswith(term):
            continue
        source = by_id.get(ancestor_id)
        if source is None:
            continue
        pos = source.text.find(intro)
        if pos < 0:
            continue
        if ancestor_id == claim.id and pos >= ref_start:
            continue
        rem = intro[len(term):]
        if rem[0] in _TAIL_STOP_CHARS_CN:
            continue
        tail = rem + source.text[pos + len(intro): pos + len(intro) + 4]
        hit = rem in _LOCATIVE_POSTPOSITIONS_CN or (
            rem[0] in _COVERBS_CN
            and not (rem[0] == "对" and rem[1:2] in _DUI_LEXEME_CHARS_CN)
        )
        if not hit:
            for k in (1, 2):
                if any(ch in _TAIL_STOP_CHARS_CN for ch in tail[:k]):
                    break
                if tail[k:].startswith(_PREDICATE_OBJECT_OPENERS_CN) or tail[k:k + 1] == "于":
                    hit = True
                    break
        if hit and _intro_opens_as_introduction_cn(source.text, pos, intros_by_term):
            return intro
    return None


# Ruling R7 (2026-10-25): in a method claim a step verb gives basis to a later
# reference naming that step - 输出所述估测值 ... 所述输出所述估测值包括 - as US R35
# rules for "outputting X ... the outputting". R4 still governs the output as a
# THING (处理器输出一指标 ... 接收该输出), so the reference must read as the act:
# followed by its own object, or, in a method claim, by 包括 / 包含.
_STEP_GERUND_TERMS_CN: frozenset[str] = frozenset({"输出", "输入", "比较"})
_ACT_ONLY_TERMS_CN: frozenset[str] = frozenset({"比较"})
_STEP_DESCRIBED_BY_CN: tuple[str, ...] = (
    "包括", "包含", "更包括", "更包含", "还包括", "还包含", "进一步包括", "进一步包含",
)
_STEP_VERB_NOT_BEFORE_CN: frozenset[str] = frozenset("的之一个该述等")
_STEP_VERB_NOT_AFTER_CN: frozenset[str] = frozenset(
    "端值层讯信号电终级埠口介单模元器部侧流位功资数图影出入设连耦轴"
)


def _step_gerund_reference_cn(claim_text: str, chain: list, term: str, ref_offset: int) -> bool:
    """True if the reference to ``term`` at ``ref_offset`` names a method step
    whose verb is ``term`` earlier in the chain (ruling R7)."""
    if term not in _STEP_GERUND_TERMS_CN:
        return False
    pos = claim_text.find(term, ref_offset)
    if pos < 0:
        return False
    after = claim_text[pos + len(term):]
    if term not in _ACT_ONLY_TERMS_CN and not after.startswith(("所述", "该", "前述")):
        root = getattr(chain[-1], "text", "") if chain else claim_text
        if "方法" not in (root or "")[:60] or not after.startswith(_STEP_DESCRIBED_BY_CN):
            return False

    def _has_step_verb(text: str, limit: int | None) -> bool:
        i = text.find(term)
        while i >= 0 and (limit is None or i < limit):
            before = text[i - 1:i]
            nxt = text[i + len(term):i + len(term) + 1]
            if (before not in _STEP_VERB_NOT_BEFORE_CN
                    and not text[:i].endswith(("所述", "前述"))
                    and nxt and nxt not in _STEP_VERB_NOT_AFTER_CN):
                return True
            i = text.find(term, i + 1)
        return False

    if _has_step_verb(claim_text, ref_offset):
        return True
    return any(_has_step_verb(getattr(a, "text", "") or "", None) for a in chain[1:])


# Ruling R6 (2026-10-25): in 所述X的所述Y with X introduced, Y has basis only
# when Y is a GEOMETRY part of X - every body has a surface, sides, ends, an
# edge, a top and a bottom (MPEP 2173.05(e), "the outer surface of said
# sphere"). Terminals (控制端 / 输出端) are NOT inherent and still flag.
_GEOMETRY_PARTS_CN: frozenset[str] = frozenset({"表面", "外表面", "上表面", "下表面", "顶面", "底面", "侧面", "端面", "前端", "后端", "上端", "下端", "顶端", "底端", "末端", "另一端", "两端", "另一侧", "两侧", "外侧", "上侧", "下侧", "边缘", "外缘", "周缘", "顶部", "底部", "外周", "周边"})


def _inherent_geometry_part_reference_cn(
    claim_text: str, term: str, ref_offset: int, intros_by_term,
) -> bool:
    """True if the reference at ``ref_offset`` is 所述X的所述Y, Y a geometry part
    and X itself an introduced element (ruling R6)."""
    if term not in _GEOMETRY_PARTS_CN or not intros_by_term:
        return False
    look = claim_text[max(0, ref_offset - 17):ref_offset]
    if not look or look[-1] not in ("的", "之"):
        return False
    look = look[:-1]
    for det in ("所述", "前述", "该"):
        k = look.rfind(det)
        if k >= 0:
            owner = look[k + len(det):]
            return owner in intros_by_term or strip_leading_quantifier_cn(owner) in intros_by_term
    return False


# Wave E: an I/O element first named as the head of an attributive 的 phrase in
# an introducing clause (具有…的第二輸入和耦合到X的輸出 / 更包括…之中的輸出連接)
# is introduced there. Scoped to the I/O nouns whose one-character truncation
# used to hide every such reference; the general relative-clause arm is not
# shipped (it is surface-identical to a reference-bearing 的 phrase).
_IO_ATTRIBUTIVE_TERMS_CN: frozenset[str] = frozenset({"输出", "输入", "输出连接", "输入连接"})
_IO_INTRO_VERBS_CN: tuple[str, ...] = ("包括", "包含", "具有", "含有", "设有")


def _io_attributive_intro_cn(claim_text: str, chain: list, term: str, ref_offset: int) -> bool:
    if term not in _IO_ATTRIBUTIVE_TERMS_CN:
        return False

    def _scan(text: str, limit: int | None) -> bool:
        i = text.find(term)
        while i >= 1 and (limit is None or i < limit):
            nxt = text[i + len(term):i + len(term) + 1]
            if text[i - 1] in ("的", "之") and (
                    not nxt or nxt in "，。；：、,;和及與与或"):
                seg = re.split(r"[，。；：,;]", text[:i])[-1]
                if any(v in seg for v in _IO_INTRO_VERBS_CN):
                    return True
            i = text.find(term, i + 1)
        return False

    if _scan(claim_text, ref_offset):
        return True
    return any(_scan(getattr(a, "text", "") or "", None) for a in chain[1:])


def has_possessive_introduction_cn(
    claim_text: str, chain: list, term: str, ref_offset: int,
    intros_by_term=None,
) -> bool:
    """R37 (2026-06-01) - TW R9 parity (issue #134 generalization).

    True if ``term`` appears earlier in possessive position
    ``(所述|前述|该)<X>(的|之)<term>``, where the genitive owner X is
    itself referenced. Y (the term) gets antecedent basis from this
    first article-less possessive mention.

    CN-specific notes:
    - Accepts BOTH 的 (modern CNIPA standard) and 之 (classical /
      JP-translation variant) as genitive markers. TW uses 之
      predominantly; CN drafters split between 的 and 之.
    - Markers ``所述`` / ``前述`` / ``该`` (CN simplified - TW equivalent
      is ``該``).

    Differs from ``has_bare_noun_introduction_cn``:
    - NO 4-char min-len gate (the structural pattern is unambiguous so
      short locative attributes 顶面/底面/侧面/端面/顶端/底端 qualify).
    - Accepts ``的``/``之``-headed left context. Guard (b) in
      ``has_bare_noun_introduction_cn`` blanket-rejects these to defend
      against verb-phrase relative-clause ambiguity. That defense
      doesn't apply when the required ``所述/前述/该<X>(的|之)`` prefix
      anchors the construction as definite genitive.

    Statute pin: CNIPA 审查指南 第二部分第二章 §3.2 "清楚" / "明确"
    antecedent standard; MPEP § 2173.05(e) equivalent.
    """
    t = (term or "").strip()
    if not t or len(t) < 2:
        return False
    if any(ch.isdigit() for ch in t) or "(" in t:
        return False
    # CN R37 narrowing: ordinal-led terms (第一X / 第二X / ...) are
    # EXCLUDED. Doctrine is ambiguous - `所述X的第一Y` may be either
    # (a) a definitional intro of "the first Y of X" in possessive
    # position, OR (b) a definite reference to a previously-introduced
    # "first Y" that strict §112(b) requires to have its own clean
    # intro. The R20 corpus maintainer chose reading (b) (e.g.,
    # CN115485995B c82/c124's `所述第三信号相关的第一训练信号` is
    # marked protect:true as a real §112(b) defect). To preserve that
    # protect AND still cover the unambiguous locative-attribute
    # pattern (顶面/底面/侧面/端面 - non-ordinal short nouns that R9 was
    # designed for), exclude terms starting with the 第 ordinal prefix.
    # Wave C (Christopher's rulings 2026-10-24, mirror of TW): an ordinal head
    # IS introduced by a possessive or relative clause when the noun right
    # after the determiner is itself an introduced element (所述X的第一Y,
    # 垂直于所述X的第二方向). The determiner governing the ordinal itself
    # (该固定的第一抗原) stays a reference.
    ordinal = t.startswith("第")
    if ordinal and not intros_by_term:
        return False

    def _possessor_introduced(look_back: str) -> bool:
        for det in ("所述", "前述", "该"):
            k = look_back.rfind(det)
            if k >= 0:
                owner = look_back[k + len(det):].strip()
                stripped = strip_leading_quantifier_cn(owner)
                for base in (owner, stripped):
                    for term in intros_by_term:
                        if len(term) >= 2 and base.startswith(term):
                            # The element opening its own clause (用於 / 以 /
                            # 對 ...) is not what the 的 phrase modifies.
                            return not any(
                                c in base[len(term):] for c in _NEW_ARGUMENT_COVERBS_CN
                            )
                # Wave I (2026-10-26): a quantified one-character element (所述
                # 多个匝中的第一匝) now keys its single character, not the garbage
                # 个匝 it used to match by accident.
                if (
                    stripped != owner
                    and stripped[:1] in intros_by_term
                    and stripped[1:] in ("", "中", "之中", "內", "内", "上")
                ):
                    return True
                return False
        return False

    def _scan(text: str, limit: int | None) -> bool:
        start = 0
        while True:
            idx = text.find(t, start)
            if idx < 0:
                return False
            if limit is not None and idx >= limit:
                return False
            # Possessive intro shape: text[idx-1] is 的 OR 之 AND the
            # 15-char window before that marker contains 所述/前述/该.
            if idx >= 1 and text[idx - 1] in ("的", "之"):
                look_back = text[max(0, idx - 16):idx - 1]
                if ordinal:
                    if _possessor_introduced(look_back):
                        return True
                elif any(marker in look_back for marker in ("所述", "前述", "该")):
                    # Right-clean intentionally skipped (same rationale as
                    # has_possessive_introduction_tw - verb-start chars
                    # would block legitimate intros of short locatives).
                    return True
            start = idx + 1

    if _scan(claim_text or "", ref_offset):
        return True
    for ancestor in chain[1:]:
        if _scan(getattr(ancestor, "text", "") or "", None):
            return True
    return False


def has_bare_noun_introduction_cn(
    claim_text: str, chain: list, term: str, ref_offset: int
) -> bool:
    """True if multi-character noun ``term`` is introduced earlier article-less.

    "Introduced earlier" = a whole-phrase, article-less occurrence of
    ``term`` preceding the reference in document order: in ``claim_text``
    before ``ref_offset``, or anywhere in an ancestor claim (``chain[1:]``
    -- every ancestor is wholly earlier). Gated multi-character
    (>= 4 CJK chars). Digit / paren-numeral terms are excluded -- those
    resolve via the paren-asymmetry path. See the constant block above
    for the (a) compound-boundary and (b) possessive guards.
    """
    t = (term or "").strip()
    # A shorter noun counts only as the object of an introducing verb
    # (连接电阻的第一端): Christopher's ruling 2026-10-24 that an article-less
    # earlier mention is an introduction. Mirror of TW.
    short = len(t) < _BARE_NOUN_MIN_LEN_CN
    if len(t) < 2:
        return False
    if any(ch.isdigit() for ch in t) or "(" in t:
        return False
    n = len(t)

    def _scan(text: str, limit: int | None) -> bool:
        start = 0
        while True:
            idx = text.find(t, start)
            if idx < 0:
                return False
            if limit is not None and idx >= limit:
                return False
            left = (_bare_noun_verb_led_cn(text, idx) if short
                    else _bare_noun_left_clean_cn(text, idx))
            if short and text.startswith(_BARE_NOUN_OBJECT_DETERMINERS_CN, idx + n):
                left = False
            if left and _bare_noun_right_clean_cn(text, idx + n):
                return True
            start = idx + 1

    if _scan(claim_text or "", ref_offset):
        return True
    for ancestor in chain[1:]:
        if _scan(getattr(ancestor, "text", "") or "", None):
            return True
    return False


def check_antecedent_basis_cn(
    doc: CnPatentDocument,
    *,
    strict_plural_reference_matching: bool = False,
    strict_qualifier_matching: bool = False,
) -> list[dict]:
    """CN antecedent-basis BFS walker (Phase 8c Stage 2).

    Mirrors the TW walker's resolution algorithm (tw_claims.py
    ``check_antecedent_basis``) with the Q1/Q3 divergences:

      * Q1: references using the TC-contamination prefixes 该等 / 该些
        are rejected with a ``category: "tw_contamination"`` finding
        and bypass normal resolution.
      * Q3: dedup key is the tuple
        ``(normalized_term, normalized_reference_form)`` from day 1
        (ADR-107). TW uses single-key dedup pending Phase 9 parity.

    Returns a list of dicts, 6-field ``{claim_id, term, reference_form,
    claim_text, suggested_match, cross_ref}`` for normal findings; the
    ``category`` key is added only on the Q1 path.
    """
    claims = doc.claims
    if not claims:
        return []

    issues: list[dict] = []

    for claim in claims:
        chain = get_ancestor_chain_cn(claim, claims)

        # R64 (2026-05-05) TW parity: suppress walker emit when chain
        # doesn't terminate at an independent claim (broken chain via
        # self-loop / cycle / dangling parent ref upstream). The
        # structural defect surfaces separately via selfDependent /
        # circularDependency checks; cascading antecedent findings are
        # confusing UX.
        if chain and chain[-1].dependencies:
            continue

        intros_by_term: dict[str, tuple[int, int]] = {}
        for depth, ancestor in enumerate(chain):
            for original, normalized in extract_introductions_cn(
                ancestor,
                strict_qualifier_matching=strict_qualifier_matching,
            ):
                intros_by_term.setdefault(normalized, (ancestor.id, depth))
            for original, normalized in _abbreviation_intros_cn(ancestor):
                intros_by_term.setdefault(normalized, (ancestor.id, depth))

        # R32 (2026-05-04): Path A equivalent for CN - chain-level
        # ordinal-prefix bridging. Mirror of TW R32. Two guards:
        #   1. Multi-modifier ambiguity (no other 第N+suffix in chain).
        #   2. Prefix-conflict (suffix not followed by 1-3 CJK in claim
        #      text outside the ordinal-prefixed source intro itself).
        _R32_ORDINAL_RE_CN = re.compile(r'^第[一二三四五六七八九十百0-9]+')
        suffix_count_chain_cn: dict[str, int] = {}
        suffix_anchor_chain_cn: dict[str, tuple[int, int]] = {}
        for norm, (ancestor_id, depth) in intros_by_term.items():
            mo = _R32_ORDINAL_RE_CN.match(norm)
            if not mo:
                continue
            suffix = norm[mo.end():]
            if len(suffix) < 2:
                continue
            suffix_count_chain_cn[suffix] = suffix_count_chain_cn.get(suffix, 0) + 1
            existing = suffix_anchor_chain_cn.get(suffix)
            if existing is None or depth < existing[1]:
                suffix_anchor_chain_cn[suffix] = (ancestor_id, depth)
        for suffix, count in suffix_count_chain_cn.items():
            if count > 1:
                continue
            if suffix in intros_by_term:
                continue
            conflict_re = re.compile(re.escape(suffix) + r'[一-鿿]{1,3}')
            has_conflict = False
            for ancestor in chain:
                full_re = re.compile(r'第[一二三四五六七八九十百0-9]+' + re.escape(suffix))
                consumed = full_re.sub('', ancestor.text)
                if conflict_re.search(consumed):
                    has_conflict = True
                    break
            if has_conflict:
                continue
            intros_by_term[suffix] = suffix_anchor_chain_cn[suffix]

        # R52-CN (2026-05-05): head-noun-suffix bridging for compound nouns.
        # CN parity of TW R52 (commit 930ad0c). When a chain intro is
        # `<modifier><HEAD>` where HEAD is a known compound head-noun
        # suffix (Simplified script), register `<HEAD>` separately so dep
        # claims using the bare head can resolve.
        #
        # Phase 1 supplement_v2 cluster `TAIL|CN|导体层` (31 wfp / 0 legit)
        # and similar patterns. CN drafters of chemistry/materials claims
        # use Pattern A on full compound (e.g. `半导体导体层`) but back-
        # reference using just the head (`所述导体层`).
        #
        # Architectural mirror of R32 ordinal bridge + R52 TW:
        #   1. Multi-modifier ambiguity guard
        #   2. Conflict guard (HEAD already an intro)
        #   3. Suffix allowlist - Simplified-script equivalents of TW R52
        _R52_HEAD_SUFFIXES_CN = (
            # Pharma/chemistry (R52-CN original)
            "组合物", "化合物", "溶液", "溶剂", "配方",
            "混合物", "复合物", "产物", "药剂", "抗体",
            "导体层", "聚合物",
            # R56-CN (2026-05-05): electronic/circuit head nouns
            # (Simplified parity of R56 TW). Phase 1 supplement_v2.
            "电路系统", "晶体管", "区块链", "管理功能",
            "参考电压", "定位辅助", "操作单元",
            "指令集", "传送信息",
        )
        head_count_cn: dict[str, int] = {}
        head_anchor_cn: dict[str, tuple[int, int]] = {}
        for norm, (ancestor_id, depth) in intros_by_term.items():
            for suffix in _R52_HEAD_SUFFIXES_CN:
                if (
                    norm.endswith(suffix)
                    and len(norm) > len(suffix)
                ):
                    head_count_cn[suffix] = head_count_cn.get(suffix, 0) + 1
                    existing = head_anchor_cn.get(suffix)
                    if existing is None or depth < existing[1]:
                        head_anchor_cn[suffix] = (ancestor_id, depth)
                    break
        for suffix, count in head_count_cn.items():
            if count > 1:
                continue
            if suffix in intros_by_term:
                continue
            intros_by_term[suffix] = head_anchor_cn[suffix]


        # Q1 tw_contamination rejection pre-pass. The TC-plural prefixes
        # 该等 / 该些 are not valid in CN drafting (CNIPA审查指南 uses 所述).
        # Their detection regex is local to this function so the only
        # module occurrence of these literals is this rejection apparatus.
        _tw_contamination_re = re.compile(
            r"(?P<prefix>该等|该些)" + f"(?P<noun>{_NOUN_CHARS_CN})"
        )
        for m in _tw_contamination_re.finditer(claim.text):
            prefix = m.group("prefix")
            raw_noun = m.group("noun")
            if not raw_noun:
                continue
            # Run the captured tail through the same cleanup pipeline as
            # the normal path (strip_reference_form_prefix →
            # strip_leading_qualifier → clean_noun_phrase →
            # strip_leading_quantifier), skipping resolution. The Q1
            # regex already split prefix (该等/该些) from noun, so we
            # normalize raw_noun directly.
            normalized_term = normalize_reference_term_cn(
                raw_noun,
                strict_qualifier_matching=strict_qualifier_matching,
            )
            finding: dict = {
                "claim_id": claim.id,
                "term": normalized_term or raw_noun,
                "reference_form": prefix,
                "claim_text": claim.text,
                "suggested_match": None,
                "cross_ref": None,
                "category": "tw_contamination",
                "document_dedup_key": make_document_dedup_key(
                    normalized_term or raw_noun, prefix
                ),
                # Q1 path is a rule-based detection of TC-plural prefixes
                # (该等/该些) on a CN doc. Not pattern-based - the prefix
                # alone is the violation under CNIPA审查指南 guidance to
                # use 所述. Very rarely a false positive in practice;
                # ship a fixed high confidence so the tier-display knob
                # treats these as high-confidence by default.
                "confidence_score": 90,
            }
            if not normalized_term:
                finding["note"] = "cleanup_empty"
            issues.append(finding)

        # Q3 tuple dedup (ADR-107): the key is the pair
        # (normalized_term, normalized_reference_form). See the
        # module-header ADR-107 comment for the parity rationale.
        seen_terms: set[tuple[str, str]] = set()
        for m in _REF_PATTERN_CAPTURE_CN.finditer(claim.text):
            prefix = m.group("prefix")
            raw_noun = m.group("noun")
            if not raw_noun:
                continue

            # R62 (2026-05-05) paren-numeral closure (parallel of TW fix).
            # When the regex {2,12} length cap truncates inside an open
            # paren-numeral, look ahead for the closing paren and extend.
            raw_noun_end = m.end()
            if _PAREN_NUM_TRAIL_RE_CN.search(raw_noun):
                if (
                    raw_noun_end < len(claim.text)
                    and claim.text[raw_noun_end] in (")", "）")
                ):
                    raw_noun = raw_noun + claim.text[raw_noun_end]
                    raw_noun_end += 1

            # R68d (2026-05-06) TW parity: mid-能 noun extension.
            raw_noun, raw_noun_end = _extend_neng_compound_cn(
                raw_noun, raw_noun_end, claim.text
            )

            # R47 (2026-06-27): mid-时 timer/clock compound extension
            # (定时器→第一定 truncation, CN115701183B c13). FN-safe follow-gate.
            raw_noun, raw_noun_end = _extend_shi_compound_cn(
                raw_noun, raw_noun_end, claim.text
            )

            # R48 (2026-06-27): mid-应 reaction/effect compound extension
            # (反应器→第一反, 晶化反应→晶化反). TW 應 mirror; precursor-gated.
            raw_noun, raw_noun_end = _extend_ying_compound_cn(
                raw_noun, raw_noun_end, claim.text
            )

            # Wave F (2026-10-26): 于 is not a noun character, so 所述一个或多于一个X
            # stopped inside its own quantifier (一个或多). Step over it.
            if raw_noun == "一个或多" and claim.text.startswith("于一个", raw_noun_end):
                ext_m = _NOUN_EXT_RE_CN.match(claim.text, raw_noun_end + 3)
                if ext_m:
                    added = ext_m.group()[:12]
                    raw_noun = "一个或多于一个" + added
                    raw_noun_end += 3 + len(added)

            # R49 (2026-06-27): leading-quantifier cap-truncation. Restore the
            # {2,12} budget a leading quantifier consumed so a long compound
            # (一个或更多个便携式手持控制器) isn't cut mid-word at the cap.
            if (
                len(raw_noun) >= 12
                and raw_noun_end < len(claim.text)
                and _LEADING_QUANTIFIER_RE_CN.match(raw_noun)
            ):
                ext_m = _NOUN_EXT_RE_CN.match(claim.text, raw_noun_end)
                if ext_m:
                    q = _LEADING_QUANTIFIER_RE_CN.match(raw_noun).group(0)
                    room = (12 + len(q)) - len(raw_noun)
                    if room > 0:
                        added = ext_m.group()[:room]
                        raw_noun = raw_noun + added
                        raw_noun_end += len(added)

            # R66 (revised 2026-05-05): TW parity - state-modifier capture
            # extension. When raw_noun ends in 状/形 and `的<head>` follows,
            # extend capture so the displayed reference_form is the full
            # `所述<state>的<head>` phrase rather than the bare adjective.
            # See tw_claims.py R66 comment for the full rationale.
            if (
                raw_noun.endswith(_STATE_MODIFIER_SUFFIXES_CN)
                and not raw_noun.startswith("第")
                and raw_noun_end < len(claim.text)
            ):
                m_de = _DE_HEAD_NOUN_RE_CN.match(claim.text, raw_noun_end)
                if m_de:
                    head_raw = m_de.group("head")
                    raw_noun = raw_noun + "的" + head_raw
                    raw_noun_end = raw_noun_end + 1 + len(head_raw)

            full_ref = f"{prefix}{raw_noun}"
            normalized_term = normalize_reference_term_cn(
                full_ref,
                strict_qualifier_matching=strict_qualifier_matching,
            )
            if not normalized_term:
                continue

            normalized_reference_form = f"{prefix}{normalized_term}"
            dedup_key = (normalized_term, normalized_reference_form)
            if dedup_key in seen_terms:
                continue
            seen_terms.add(dedup_key)

            # R64 (2026-05-05) TW parity: dedup uses CJK-normalized
            # reference_form (matching parity); displayed reference_form
            # restores drafter's original Arabic ordinals.
            display_term = _restore_original_ordinals_cn(normalized_term, raw_noun)
            reference_form = f"{prefix}{display_term}"

            resolved_intro: str | None = None
            if normalized_term in intros_by_term:
                resolved_intro = normalized_term
            elif not _TRAILING_PAREN_ANNOTATION_CN.search(normalized_term):
                for intro in intros_by_term:
                    stripped_intro = _TRAILING_PAREN_ANNOTATION_CN.sub("", intro)
                    if stripped_intro != intro and stripped_intro == normalized_term:
                        resolved_intro = intro
                        break
            else:
                # R63 (2026-08-17): CN mirror of TW R41 - the missing half of
                # the paren-asymmetry rule. An annotated reference
                # `所述设备(7.1)` / `所述消弧滑车(200)` against a bare intro the
                # drafter wrote article-less had no branch, so it could never
                # resolve. 专利法实施细则 §20 puts the 附图标记 in parentheses and
                # it is not part of the element name.
                #
                # Same construction-level guard as TW: only intros carrying NO
                # annotation are eligible, so a reference and an intro that
                # BOTH carry one must still match exactly and a numeral typo
                # keeps firing.
                stripped_ref = _TRAILING_PAREN_ANNOTATION_CN.sub("", normalized_term)
                if len(stripped_ref) >= 2 and stripped_ref in intros_by_term:
                    resolved_intro = stripped_ref
            if resolved_intro is None:
                best_len = 0
                for intro in intros_by_term:
                    if (
                        len(intro) >= 2
                        and len(intro) > best_len
                        and normalized_term.startswith(intro)
                        and not _content_of_stem_cn(intro, normalized_term, claim.text, m.start())
                        and not (
                            _short_stem_opens_compound_cn(intro, normalized_term)
                            and not _mentioned_before_cn(
                                normalized_term, chain, claim, m.start()
                            )
                        )
                    ):
                        best_len = len(intro)
                        resolved_intro = intro
                # 該组X ("that set of X") after 一组X, which now keys X. A bare 组
                # is not stripped in the normalizer: 所述组包括 is "the set includes".
                if (
                    resolved_intro is None
                    and normalized_term.startswith("组")
                    and len(normalized_term) >= 3
                    and normalized_term[1] not in _ZU_NOUN_NEXT_CN
                ):
                    resolved_intro = _zu_set_reference_intro_cn(
                        normalized_term[1:], intros_by_term, chain, m.start()
                    )
                if resolved_intro is None and raw_noun.startswith(_SELF_INTRO_QUANTIFIERS_CN):
                    if _shared_zhong_mention_cn(normalized_term, chain, m.start()):
                        resolved_intro = normalized_term
                    elif _same_quantifier_stem_cn(normalized_term, raw_noun, chain, m.start()):
                        resolved_intro = normalized_term
                if resolved_intro is None and _bare_earlier_mention_cn(
                    normalized_term, chain, m.start()
                ):
                    resolved_intro = normalized_term
                if (
                    resolved_intro is not None
                    and _PREFIX_FALLBACK_OBSERVER is not None
                ):
                    _PREFIX_FALLBACK_OBSERVER(resolved_intro, normalized_term, claim.id)

            # R46 (2026-05-04): mirror of TW R46 - ordinal-prefix-to-
            # Latin-abbrev bridge. Reference `第N<X>` where X is short
            # uppercase Latin abbrev (2-5 chars) and `<X>` is registered
            # as an intro -> bridge. Common in CN 5G/wireless drafts.
            if resolved_intro is None:
                m_ord = re.match(r'^第[一二三四五六七八九十百0-9]+', normalized_term)
                if m_ord:
                    bare = normalized_term[m_ord.end():]
                    if (
                        bare and 2 <= len(bare) <= 5
                        and bare.isupper() and bare.isascii()
                        and bare in intros_by_term
                    ):
                        resolved_intro = bare

            # R29 (2026-05-03) - Resolution-side architectural mechanisms
            # (forward-prefix with boundary, symmetric clean, cross-branch
            # sibling, substring) all silenced protect:true legit_drafting
            # _error labels (parallel-invention drafter errors on
            # CN115485995B / CN113939805B / CN110276410B). §112(b) is
            # strict: references must resolve to SAME-CHAIN antecedents,
            # not sibling-claim intros or substring matches. Round 29
            # restricted to the capture-side fix (F11 ;-segment continuation
            # in _extract_supplementary_intros_cn) plus conservative trim-
            # verb extensions, both of which respect the chain invariant.

            # R35 (2026-05-23): bare-noun-introduction rescue (CN mirror of
            # TW R7). A multi-character noun first mentioned article-less
            # (verb / coverb object, clause item) has antecedent basis by
            # implication (审查指南 第二部分 第二章 §3.2 清楚 / 明确).
            # The intro extractors miss article-less data / attribute
            # nouns; this closes the gap. See has_bare_noun_introduction_cn.
            # CN R79: an intro that is the term plus a predicate tail.
            if resolved_intro is None:
                resolved_intro = _predicate_tail_intro_cn(
                    normalized_term, intros_by_term, chain, claim, m.start()
                )

            if resolved_intro is None and has_possessive_introduction_cn(
                claim.text, chain, normalized_term, m.start(), intros_by_term
            ):
                continue

            if resolved_intro is None and _step_gerund_reference_cn(
                claim.text, chain, normalized_term, m.start()
            ):
                continue

            if resolved_intro is None and _io_attributive_intro_cn(
                claim.text, chain, normalized_term, m.start()
            ):
                continue

            if resolved_intro is None and _inherent_geometry_part_reference_cn(
                claim.text, normalized_term, m.start(), intros_by_term
            ):
                continue

            if resolved_intro is None and has_bare_noun_introduction_cn(
                claim.text, chain, normalized_term, m.start()
            ):
                continue
            # CN R71 - last-resort tier, the tail-compound mirror of TW R27/R43.
            # The interior cut reads 连接 in 所述电脑连接器 as a verb and keeps
            # 电脑, while the introduction 包含电脑连接器 registers whole, so the
            # pair never matches. Re-normalize with the compound protected and
            # accept only an EXACT introduction: the tier runs after every other
            # path has failed, so it can only silence, and the exact match means
            # a dirty tail the protection exposes (触头(100)解) never resolves.
            # The protected form must EXTEND the default one - the tier restores
            # a tail the cut removed, nothing else. Otherwise a quantifier-led
            # 所述至少三个连接器接收通道 (default 至少三个) re-normalizes to the
            # bare 连接器 and resolves against a different element.
            if resolved_intro is None:
                protected_term = normalize_reference_term_cn(
                    full_ref,
                    strict_qualifier_matching=strict_qualifier_matching,
                    protect_tail_compounds=True,
                )
                if (
                    len(protected_term) > len(normalized_term)
                    and protected_term.startswith(normalized_term)
                    and protected_term in intros_by_term
                ):
                    continue

            if resolved_intro is not None:
                if not strict_plural_reference_matching:
                    continue
                if not detect_plural_reference_cn(full_ref):
                    continue
                ancestor_id, _ = intros_by_term[resolved_intro]
                ancestor_claim = next(
                    (c for c in chain if c.id == ancestor_id), None
                )
                intro_was_plural = False
                if ancestor_claim is not None:
                    for original, normalized in extract_introductions_cn(
                        ancestor_claim,
                        strict_qualifier_matching=strict_qualifier_matching,
                    ):
                        if normalized != resolved_intro:
                            continue
                        if full_ref_starts_with_plural_cn(original):
                            intro_was_plural = True
                            break
                if intro_was_plural:
                    continue

            suggested_match: dict | None = None
            if resolved_intro is None:
                ref_tokens = tokenize_cn(normalized_term)
                best_score = 0.0
                best_depth: int | None = None
                for intro_term, (ancestor_id, depth) in intros_by_term.items():
                    if ordinal_guard(normalized_term, intro_term):
                        continue
                    score = jaccard(ref_tokens, tokenize_cn(intro_term))
                    if score < _DIDYOUMEAN_THRESHOLD_CN:
                        continue
                    if (
                        score > best_score
                        or (
                            score == best_score
                            and (best_depth is None or depth < best_depth)
                        )
                    ):
                        best_score = score
                        best_depth = depth
                        suggested_match = {
                            "term": intro_term,
                            "claim_id": ancestor_id,
                        }

            if (
                suggested_match is not None
                and suggested_match["term"] == normalized_term
            ):
                suggested_match = None

            # Phase 8c R21 - DYM quality gate
            if (
                suggested_match is not None
                and _dym_quality_reject_cn(
                    normalized_term, suggested_match["term"]
                )
            ):
                suggested_match = None

            if _is_bare_genus_self_reference_cn(normalized_term, claim.text):
                continue

            if "权利要求" in normalized_term:
                continue

            # R32 (2026-05-04): TW parity - citation boilerplate filter
            # (任一项 stranded after `权利要求` substring removal would
            # otherwise pass - but multi-dep refs like `任一项所述的X`
            # produce term=`任一项` directly when the dep regex misses).
            if "任一项" in normalized_term or "申请专利范围" in normalized_term:
                continue

            if len(normalized_term) == 1:
                if _ONE_CHAR_DROP_OBSERVER is not None:
                    _ONE_CHAR_DROP_OBSERVER(raw_noun, normalized_term, claim.id)
                continue

            # R32 (2026-05-04): TW parity - newline/colon filter. F-anchor
            # captures crossing paragraph or label boundaries leak garbage
            # into spec-support too via shared extract_introductions_cn.
            if '\n' in normalized_term or '：' in normalized_term or ':' in normalized_term:
                continue

            if _FORMULA_ORDINAL_RE_CN.match(normalized_term):
                continue

            if _BARE_ORDINAL_RE_CN.match(normalized_term):
                continue

            # Phase 8c R22 - chemistry formula reference + verb-predicate suppression
            if _FORMULA_REFERENCE_RE_CN.match(normalized_term):
                continue

            if normalized_term in _VERB_PREDICATE_TERMS_CN:
                continue

            # R62 (2026-05-05): bare-quantifier emit suppression (CN parity
            # with TW). Drafters universally use 多个/复数/数个/至少 as
            # quantifier prefixes (多个X, 复数X), NEVER as standalone nouns.
            # Walker capture without proper leading-quantifier strip leaves
            # the bare quantifier as the term. Mirror of TW
            # _BARE_QUANTIFIER_TERMS_TW filter. Surfaced via supplement_v2
            # hand-verification - `多个` flagged on CN121219509A c10.
            if normalized_term in {
                "多个", "复数", "数个", "至少", "若干", "一些",
                "多个个", "复数个",
            }:
                continue
            # R62: short residual structural fragments - single CJK char
            # or 1-char Latin terms that escape the prefix-strip cascade.
            if len(normalized_term) < 2:
                continue

            # Structural fingerprint (ADR-145) - mirror of TW walker.
            # No claim content; counts + booleans only.
            diagnostics = {
                "prefix_charlen": len(prefix),
                "term_charlen": len(normalized_term),
                "intros_pool_size": len(intros_by_term),
                "has_suggested_match": suggested_match is not None,
                "suggested_cross_branch": bool(
                    suggested_match and suggested_match.get("cross_branch")
                ) if suggested_match else False,
            }
            confidence_score = compute_confidence_score(
                term=normalized_term,
                prefix=prefix,
                intros_pool_size=len(intros_by_term),
                has_suggested_match=suggested_match is not None,
                suggested_cross_branch=bool(
                    suggested_match and suggested_match.get("cross_branch")
                ),
                suggested_jaccard=best_score if suggested_match else None,
                suggested_same_claim=bool(
                    suggested_match
                    and suggested_match.get("claim_id") == claim.id
                ),
                reference_form=reference_form,
                jurisdiction="CN",
            )
            # Parent-claim diagnostic enrichment (US/TW parity, 2026-06-09):
            # does the flagged term appear verbatim in an ancestor claim?
            # If so the introduction exists but in a shape the intro
            # extractor missed (walker FP); if not, a genuine §112 gap.
            # `ancestor_match_text` stays in-process - the extractor windows
            # it. Brings CN to parity with the US/TW antecedent walkers so
            # CN child-claim reports (#222/#223/#226) self-classify from the
            # payload via `term_in_ancestor_text`.
            anc_match_id, anc_match_text = first_ancestor_with_term(
                chain, normalized_term
            )
            issues.append(
                {
                    "claim_id": claim.id,
                    "term": normalized_term,
                    "reference_form": reference_form,
                    "claim_text": claim.text,
                    "suggested_match": suggested_match,
                    "cross_ref": None,
                    "diagnostics": diagnostics,
                    "document_dedup_key": make_document_dedup_key(
                        normalized_term, reference_form
                    ),
                    "confidence_score": confidence_score,
                    "ancestor_claim_ids": [c.id for c in chain[1:]],
                    "ancestor_match_claim_id": anc_match_id,
                    "ancestor_match_text": anc_match_text,
                }
            )

    issues.sort(key=lambda x: (x["claim_id"], x["term"], x["reference_form"]))
    return issues
