# SPDX-License-Identifier: LicenseRef-PolyForm-Strict-1.0.0
# Copyright (c) 2025-2026 Christopher Chen
"""Claim-level structural analysis.

Checks for missing periods, extra periods, dependencies, similarity, sequentiality,
preamble consistency, and spec support.
"""

import heapq
import re
from typing import Any, Optional

import snowballstemmer as _sb

from patentlint.analysis.en_normalize import en_number_key
from patentlint.analysis.utils import (
    _DEFINITE_REF, _QUANTIFIER_STOPS, _dx,
    extract_introductions, extract_introductions_permissive,
    extract_pattern_a_intros,
    pattern_a_intro_offsets,
    extract_abbreviation_intros, clean_noun_phrase, gerund_display_head,
    _PREDICATIVE_ADJECTIVES, _strip_comparative_tail,
    _strip_measurement_condition_tail, strip_display_negation,
    extract_contextual_cleaned_intros,
    subordinate_clause_final_verb_stem,
    compute_confidence_score, make_document_dedup_key,
    strip_contextual_verb, strip_trailing_adverb, token_set_jaccard,
    _is_likely_past_participle,
    first_ancestor_with_term, has_bare_noun_introduction,
)
from patentlint.diagnostic_extractors import extract_special_format
from patentlint.models import Claim, CheckItem, UnsupportedTerm

# 2026-06-01 (issue #178): `through hole(s)` is a patent-diction compound
# noun (a hole that passes through a substrate; MPEP § 2173 element-naming
# convention). _NP_CORE in utils.py truncates at `through` because it's
# listed as a preposition in _STOP_WORDS. When the captured term is
# exactly a bare cardinal AND the immediate source-text continuation
# is `through hole(s)`, restore the compound by post-extension at the
# definite-ref consumer site. This is tighter than a regex-level
# _NP_CORE change: cardinal-only gate prevents over-extension in
# verb-preposition contexts like `the X mounted through holes in the wall`.
_BARE_CARDINAL_TAIL = re.compile(
    r"^(?:two|three|four|five|six|seven|eight|nine|ten|\d+)$",
    re.IGNORECASE,
)
_THROUGH_HOLE_CONTINUATION = re.compile(
    r"^\s+through\s+(?P<head>holes?)\b",
    re.IGNORECASE,
)


def find_missing_periods(claims: list[Claim]) -> list[int]:
    """Find claims missing a final period."""
    return [
        c.id for c in claims
        if not re.search(r"(?s)\.\s*$", c.text, re.UNICODE)
    ]


def has_extra_periods(claim_text: str) -> bool:
    """Check if a claim has extra/misplaced periods."""
    lines = re.split(r"\r?\n", claim_text)
    for i, raw_line in enumerate(lines):
        line = raw_line.strip()
        if not line:
            continue
        is_last = i == len(lines) - 1

        if ".." in line:
            return True

        if line.endswith(".") and not is_last:
            if (
                not re.search(r"\d+\.$", line)
                and not re.match(r"(?i)^wherein ", line)
                and not re.search(r"(?i)\bdifference between\b", line)
            ):
                return True

    return False


def find_extra_periods(claims: list[Claim]) -> list[int]:
    """Find claims with extra/misplaced periods."""
    return [c.id for c in claims if has_extra_periods(c.text)]


def find_multiple_dependents(claims: list[Claim]) -> list[int]:
    return [c.id for c in claims if c.multiple_dependent]


def find_chained_multi_dependents(claims: list[Claim]) -> list[int]:
    """35 U.S.C. § 112(e) prohibits a multi-dependent claim that depends on
    another multi-dependent claim. Returns the IDs of claims that violate
    this rule - multi-dep claims whose chain includes another multi-dep.

    Mirrors CN cn_claims::check_multi_multi_dep and TW tw_claims::
    check_multi_dep_on_multi_dep (专利法实施细则 §25 第3款 / 專利法施行細則 §18)."""
    multi_dep_ids = {c.id for c in claims if c.multiple_dependent}
    if not multi_dep_ids:
        return []
    return [
        c.id for c in claims
        if c.multiple_dependent
        and any(dep in multi_dep_ids for dep in c.dependencies)
    ]


def find_self_dependent_claims(claims: list[Claim]) -> list[int]:
    return [c.id for c in claims if c.id in c.dependencies]


# US R46 follow-up (2026-08-28) - the dependency-FORMAT guard.
#
# 37 CFR 1.75(c) / MPEP § 608.01(n): a dependent claim must refer back to a
# preceding claim, and the reference must be an explicit cross-reference.
# `The command message exchanging method claim 10` drops the connector
# entirely. The PARSER still resolves the parent (`_DEP_REF` matches a bare
# `claim N`), so the claim is correctly classified dependent and nothing
# downstream complains - the malformed preamble was only ever surfaced BY
# ACCIDENT, through a garbage antecedent-basis term, and US R46 correctly
# stopped emitting that. This check is what replaces the accident.
#
# Note this is deliberately NOT the EPC/TW shape of "dependent claim with no
# resolved parent". That test is VACUOUS for this defect: the US parser
# resolves `claim 10` fine, so a dependent-without-parent check passes on the
# exact drafts six reporters attested. The check has to interrogate the FORM.
#
# Connectors below are the MPEP § 608.01(n) recognized cross-reference forms.
_US_DEP_CONNECTIVE = (
    r"(?:"
    r"of|in|to|"
    r"according\s+to|"
    r"as\s+(?:in|claimed\s+in|recited\s+in|set\s+forth\s+in|defined\s+in|described\s+in)|"
    r"claimed\s+in|recited\s+in|set\s+forth\s+in|defined\s+in|described\s+in|"
    r"in\s+accordance\s+with|"
    r"depending\s+(?:on|from)"
    r")"
)
# Multiple-dependent lead-ins (`of any one of claims 1-5`).
_US_DEP_QUANTIFIER = r"(?:any\s+(?:one\s+)?of\s+|either\s+of\s+|one\s+of\s+)?"

# INVERTED form, admitted on measured evidence, not on principle: the corpus
# carries `The method as claim 1 recites` 17 times in one draft (plus system /
# CRM variants). The connector follows the claim number instead of preceding
# it; the cross-reference is explicit, so it is well-formed.
_US_DEP_INVERTED = (
    r"\bas\s+claims?\s*\d+\s+"
    r"(?:recites?|sets?\s+forth|describes?|defines?|claims?|states?)"
)
# ELIDED NOUN: `as claimed in 14` (US4763545A c17) omits the word `claim`.
# Sloppy, but the connector IS present and the reference is unambiguous - it is
# not the connector-less defect this check targets, so it is not flagged.
_US_DEP_ELIDED_NOUN = (
    r"\b(?:claimed|recited|set\s+forth|defined|described)\s+in\s+\d+\b"
)

_US_DEP_FORMAT = re.compile(
    r"(?:\b" + _US_DEP_CONNECTIVE + r"\s+" + _US_DEP_QUANTIFIER + r"claims?\s*\d+)"
    r"|(?:" + _US_DEP_INVERTED + r")"
    r"|(?:" + _US_DEP_ELIDED_NOUN + r")",
    re.IGNORECASE,
)


def find_malformed_dependency_claims(claims: list[Claim]) -> list[int]:
    """Dependent claims whose cross-reference uses no recognized form.

    Measured on the 705-draft US corpus: 12,186 dependent claims, ZERO
    flagged after the inverted and elided-noun forms were admitted, while
    both connector-less shapes from the R46 reports still flag. A format
    guard that flags nothing real and nothing false is the bar here - the
    check exists to surface a drafting defect, not to editorialize about
    style.
    """
    return [
        c.id for c in claims
        if not c.independent and c.dependencies
        and not _US_DEP_FORMAT.search(c.text)
    ]


def count_independent(claims: list[Claim]) -> int:
    return sum(1 for c in claims if c.independent)


def count_dependent(claims: list[Claim]) -> int:
    return sum(1 for c in claims if not c.independent)


def are_claims_sequential(claim_numbers: list[int]) -> bool:
    for i in range(1, len(claim_numbers)):
        if claim_numbers[i] - claim_numbers[i - 1] != 1:
            return False
    return True


def get_last_sequential_index(claim_numbers: list[int]) -> int:
    for i in range(1, len(claim_numbers)):
        if claim_numbers[i] - claim_numbers[i - 1] != 1:
            return i
    return len(claim_numbers)


def _find_claim_by_id(claim_id: int, claims: list[Claim]) -> Optional[Claim]:
    for c in claims:
        if c.id == claim_id:
            return c
    return None


def get_dependency_chain(claim: Claim, all_claims: list[Claim]) -> str:
    """Build the dependency chain string for a claim."""
    if claim.independent:
        return str(claim.id)

    if claim.dependencies:
        # Renders the primary (first-parent) chain only; multi-parent claims
        # show one of N possible chains.  UX decision, not a bug.
        parent_id = claim.dependencies[0]

        if parent_id == claim.id:
            return "SELF"

        parent = _find_claim_by_id(parent_id, all_claims)
        if parent is None:
            return f"{claim.id} → <Undefined> {parent_id}"

        if parent_id in parent.dependencies:
            return f"{claim.id} → {parent_id}"

        return f"{claim.id} → {get_dependency_chain(parent, all_claims)}"

    return str(claim.id)


_MEANS_PLUS_FUNCTION = re.compile(
    r"(?<!\bby\s)\b(means|step|mechanism|module)\s+for\s+\w+ing\b",
    re.IGNORECASE,
)


def check_excess_claims_count(claims: list[Claim]) -> list[CheckItem]:
    """Flag claims that exceed 37 CFR 1.16(h)/(i) fee-free thresholds.

    37 CFR 1.16(h) charges a per-claim fee for each independent claim
    in excess of 3. 37 CFR 1.16(i) charges a per-claim fee for each
    claim (independent or dependent) in excess of 20. Statute base:
    35 U.S.C. § 41(a)(2). Status verify when either threshold is
    exceeded; PASS otherwise. Thresholds use strict ``>``, matching the
    "in excess of" language in the regulation.
    """
    total = len(claims)
    indep = sum(1 for c in claims if c.independent)
    over_total = total > 20
    over_indep = indep > 3
    if not over_total and not over_indep:
        return [CheckItem(
            status="pass",
            message=(
                f"No excess-claims fee triggers detected "
                f"({total} total, {indep} independent - within "
                f"37 CFR 1.16(h)/(i) fee-free thresholds)."
            ),
            message_key="check.claims.excessClaims.pass",
            reference="37 CFR 1.16(h)(i); 35 U.S.C. § 41(a)(2)",
            diagnostics=_dx(total_count=total, independent_count=indep),
        )]
    issues = []
    if over_total:
        issues.append(f"total claims {total} exceeds 20")
    if over_indep:
        issues.append(f"independent claims {indep} exceeds 3")
    return [CheckItem(
        status="verify",
        message=(
            f"Excess-claims fees may apply ({'; '.join(issues)}). "
            f"37 CFR 1.16(h) charges per-claim fee for each independent "
            f"claim above 3; 37 CFR 1.16(i) charges per-claim fee for "
            f"each claim above 20. Verify your filing fee."
        ),
        message_key="check.claims.excessClaims.verify",
        reference="37 CFR 1.16(h)(i); 35 U.S.C. § 41(a)(2)",
        diagnostics=_dx(
            total_count=total,
            independent_count=indep,
            over_total=over_total,
            over_indep=over_indep,
        ),
    )]


def detect_means_plus_function(claims: list[Claim]) -> list[int]:
    """Detect claims invoking 35 U.S.C. § 112(f) means-plus-function.

    Triggers: "means for", "step for", "mechanism for", "module for" + gerund
    Does NOT trigger: "by means of" (prepositional, not 112(f))
    """
    return [c.id for c in claims if _MEANS_PLUS_FUNCTION.search(c.text)]


_SKIP_TERMS = {"invention", "present invention", "same", "following", "above", "below"}

# R38 (2026-07-23, reports #409/#414): cataphoric leading modifier. `the
# following steps:`, `the following types`, `the following information` point at
# the enumerated list that FOLLOWS in the text, not at a previously-introduced
# element, so they owe no antecedent under MPEP 2173.05(e). `following` is
# already curated as a non-element modifier in `_SKIP_TERMS` (intro side); this
# gates a multi-word REFERENCE by its head word, which a whole-term stop cannot
# reach (`following steps` != `following`). FN-safe on the authoritative ground
# truth: the examiner FN-guard confirms 0 of the recalled examiner-confirmed
# defects begin with `following` (us_examiner_legit has ZERO). The LLM-ensemble
# gold had over-labeled 32 `the following <list-noun>` findings as legit; the
# attorney (reports #409/#414) confirms the whole class is FP, so those are
# gold-corrected to walker_fp in phase2b_results_us_corrections.json (R38).
# DR-1: `above`/`below` (also curated in `_SKIP_TERMS`) are held out - no report
# evidences them and no gold/examiner term is above/below-headed; add on report.
_CATAPHORIC_LEADING = frozenset({"following"})

# Markush "the group" trailing context: when a "the X" reference where
# X is exactly "group" is followed by "consisting of" or "of", the term
# is the head noun of a Markush group definition rather than a missing
# antecedent. Walk-time skip rather than extraction-time carve-out so
# the heuristic stays narrow and inspectable.
_MARKUSH_GROUP_TRAIL = re.compile(r"^\s+(?:consisting\s+of|of)\b", re.IGNORECASE)
# R34 (2026-07-18, report #400): partitive trail after a pronoun head -
# `the switched one OF THE plurality of channels`. Requires a determiner
# after `of` so a genuine compound (`the one of a kind marker`) is untouched.
_PARTITIVE_OF_TRAIL = re.compile(
    r"^\s+of\s+(?:the|a|an|said|these|those|each)\b", re.IGNORECASE
)


def _is_partitive_pronoun_head(term: str) -> bool:
    """True when ``term`` heads on a partitive pronoun rather than an element.

    Plural ``ones`` always qualifies. Singular ``one`` qualifies only when its
    modifier is a past participle, which keeps the guard clear of the
    ordinal/quantifier/deictic singulars the US examiner corpus confirms as
    real §112(b) defects (``the first one``, ``the at least one``).
    """
    words = term.lower().split()
    if not words:
        return False
    if words[-1] == "ones":
        return True
    if words[-1] == "one" and len(words) >= 2:
        return _is_likely_past_participle(words[-2])
    return False


def _word_boundary_match(needle: str, haystack: str) -> bool:
    """Return True iff ``needle`` appears in ``haystack`` as a complete
    word sequence (case-insensitive, anchored on word boundaries).

    Used by the antecedent walker to suppress findings only when an
    introduction and a reference share the same word sequence - short
    introductions like 'common voltage' must NOT silently mask longer
    references like 'the common voltage difference calculation circuit'.
    """
    needle = needle.strip()
    if not needle:
        return False
    pattern = r"\b" + re.escape(needle) + r"\b"
    return re.search(pattern, haystack, re.IGNORECASE) is not None


# US R48 (2026-09-01, report #677) - ANTECEDENT BASIS MUST PRECEDE THE REFERENCE.
# Introductions were pooled per claim with no notion of position, so an
# introduction appearing LATER in the same claim satisfied an EARLIER definite
# reference. The reporter's case: claim 9 writes `a ratio of THE VOLUME of the
# tuning channel to A VOLUME of the first chamber`, and its own later `a volume`
# resolved the earlier `the volume` - so nothing flagged, though claim 1 never
# recites a volume at all. Under MPEP 2173.05(e) the basis must be established
# before the reference, not after it.
#
# Isolated by elimination rather than assumed: deleting the sibling claim 8
# changed nothing, and removing only the LATER `a volume` made the finding
# appear. The sibling claim was never the cause.
#
# SCOPE - narrow on purpose, because vetoing a basis ADDS findings:
#   * ancestor-supplied basis is positionally unconditional and never vetoed;
#   * only PATTERN A introductions (`a X` / `an X` / `at least one X`) carry
#     trustworthy offsets, via `pattern_a_intro_offsets`;
#   * a term reachable through any OTHER arm (bare-noun list, gerund head,
#     self-definition, abbreviation) is left alone - those arms have no offset
#     and guessing one is what broke the two earlier attempts;
#   * a veto still falls through to `has_bare_noun_introduction`, which has
#     always been positional, so an article-less earlier mention rescues it.
#
# Two earlier designs were measured and discarded, both by the corpus rather
# than by inspection: a hand-written determiner regex accepted `an electrolyte
# salt` as introducing `electrolyte` and missed the `andan` PDF collapse; and
# re-running the extractor over the truncated prefix destroyed `comprising:`
# list context, adding 1,577 findings of which 228 were known walker FPs.


# R50: what must follow a bare selector for the capture to be a TRUNCATION -
# a determiner or quantifier opening the noun phrase the selector modifies.
_TRUNCATED_SELECTOR_TRAIL = re.compile(
    r"\s+(?:said|the|an?|each|every|both|all|at\s+least|one\s+of)\b"
)


# Measurement hook (tests/eval): called with (head, tail words, following text)
# for every reference the R59 tier considers. None in production.
_KNOWN_INTRO_TAIL_OBSERVER = None

# US R59 - tails that can follow a complete, introduced noun phrase only as a
# predicate. Closed adverbs, plus the adverb suffixes (a bare -ly test also
# takes subassembly / supply / anomaly).
_PREDICATE_TAIL_ADVERBS: frozenset[str] = frozenset({
    "further", "also", "only", "then", "again", "back", "ahead", "together",
    "therein", "thereby", "thereto", "thereon", "therefrom", "thereafter",
    "respectively", "simultaneously", "additionally", "subsequently",
    "previously", "currently", "still", "already",
})
_PREDICATE_TAIL_ADVERB_SUFFIXES: tuple[str, ...] = (
    "ally", "ively", "ously", "ately", "ently", "antly", "edly", "ingly",
    "fully", "lessly",
)
_OBJECT_START = re.compile(
    r"\s*(?:the|a|an|each|said|one|two|three|its|their|it|them|all|any|"
    r"at least|no|another|such|this|these|that|whether)\b"
)
_PREPOSITION_START = re.compile(
    r"\s*(?:from|to|with|across|within|through|into|onto|on|in|at|for|by|"
    r"between|via|under|over|along|toward|towards|against|about|as)\b"
)


def _is_predicate_tail(tail: list[str], following: str, head: str = "", preceding: str = "") -> bool:
    """True when ``tail`` reads as a predicate run onto a complete noun phrase.

    Shipped classes, measured on the gold corpus (US R59): an adverb; an -ing
    form whose object follows; a lone 3rd-person-singular verb whose object or
    preposition follows (`the timer circuit returns from`, `the firmware
    module writes a flag`). A base-form verb (`clamp`, `meet`) is withheld: it reads
    exactly like a compound noun (`the user device that`), 32 gold-legit
    against 83 walker FPs before a preposition.
    """
    first = tail[0]
    if first in _PREDICATE_TAIL_ADVERBS or (
        len(first) > 5 and first.endswith(_PREDICATE_TAIL_ADVERB_SUFFIXES)
    ):
        return True
    rest = " ".join(tail[1:])
    if first.endswith("ing") and len(first) > 5 and _OBJECT_START.match(
        " " + (rest + " " + following if rest else following)
    ):
        return True
    if (
        len(tail) == 1
        and re.fullmatch(r"[a-z-]+(?:s|es)", first)
        and not first.endswith("ss")
        and (_OBJECT_START.match(following) or _PREPOSITION_START.match(following))
    ):
        return True
    # A BASE-form verb needs a plural or coordinated subject, which a compound
    # noun does not: `the X and the peripheral device communicate with`, `the
    # two interference portions clamp`. Gated on that subject, not on the word.
    if (
        len(tail) == 1
        and re.fullmatch(r"[a-z-]+", first)
        and (_OBJECT_START.match(following) or _PREPOSITION_START.match(following))
        and (
            re.search(r"\band\s*$", preceding)
            or (re.search(r"[a-z]s$", head) and not head.endswith("ss"))
        )
    ):
        return True
    return False


def known_intro_with_predicate_tail(
    term: str, head_has_basis, following: str, preceding: str = ""
) -> str | None:
    """US R59: resolve ``term`` against the longest introduced head it extends.

    A reference that over-captured a predicate (`the gate lines drops from`)
    is resolved by the drafter's own introduction of the head when the
    remainder is a predicate tail. Last-resort and additive, so it can only
    silence; the tail classes are what keep a longer compound (`the control
    circuit board`) from resolving against `control circuit`.
    """
    words = term.split()
    for n in range(len(words) - 1, 0, -1):
        head = " ".join(words[:n])
        if head_has_basis(head):
            if _KNOWN_INTRO_TAIL_OBSERVER is not None:
                _KNOWN_INTRO_TAIL_OBSERVER(head, words[n:], following)
            if _is_predicate_tail(words[n:], following, head, preceding):
                return head
            return None
    return None


def check_antecedent_basis(claims: list[Claim]) -> list[dict]:
    """Check claims for antecedent basis issues.

    A finding is emitted when a definite reference ("the X" or "said X") in
    a claim does not have a matching prior introduction ("a X", "an X", "at
    least one X", etc.) in the same claim or any of its ancestor claims
    (walking the full multi-parent dependency graph).

    Returns: list of dicts with keys claim_id, term, reference_form,
    claim_text, suggested_match. ``suggested_match`` is None for findings
    with no near-match introduction in the ancestor set, otherwise a dict
    ``{"term": <intro_term>, "claim_id": <intro_claim_id>}`` carrying the
    highest-Jaccard introduction (≥ 0.5). Findings are deduped by
    (claim_id, term, reference_form) and sorted.

    Known limitations (deferred):
    - Generic terms ("the user", "the step", "the output") are flagged
      unconditionally even when they may be implicit. A confidence-bucketing
      pass is future work.
    - Possessive constructions are normalized by stripping 's, but complex
      possessives ("the second device's first housing") may still produce
      unexpected captures.
    """
    def get_ancestor_chain(claim: Claim, all_claims: list[Claim]) -> list[Claim]:
        """Return [claim, ...ancestors] walking the full multi-parent BFS.

        Multi-dependent claims (e.g., "claim 5 of claim 1 or claim 3")
        collect introductions from every ancestor path.

        Chain construction uses ``dependencies`` only. ``Claim.quoted_references``
        is populated by the parser for body cross-refs of the form
        `the X according to claim N` (引用記載型式 incorporation-by-reference),
        but extending the chain to traverse those references blanket-grants
        antecedent for ALL of claim N's intros - broader than the US/CN
        doctrine, which says the cross-ref only provides antecedent for the
        SPECIFIC element X named in the cross-ref. Element-scoped chain
        traversal is a future ADR (separate PR); until that lands, the
        chain stays dependencies-only.

        TW walker has the same field but uses broad chain extension -
        permissible because TW practitioner convention treats 引用記載型式
        as wholesale incorporation. US/CN follow stricter MPEP / 审查指南
        readings.
        """
        claims_by_id = {c.id: c for c in all_claims}
        chain = [claim]
        visited = {claim.id}
        queue = list(claim.dependencies)
        while queue:
            parent_id = queue.pop(0)
            if parent_id in visited:
                continue
            visited.add(parent_id)
            parent = claims_by_id.get(parent_id)
            if parent is None:
                continue
            chain.append(parent)
            queue.extend(parent.dependencies)
        return chain

    # All-prior-claims intro registry (Fix #47). Used ONLY as a secondary
    # did-you-mean fallback when the ancestor-chain suggestion is None, so a
    # cross-branch intro (e.g., testspec9 c12 introduces "extending lines"
    # but c13 depends on c9) still surfaces as a hint. Emission decisions
    # remain driven by the ancestor chain - a cross-branch term has no
    # antecedent basis under §112 ¶2 and stays flagged.
    all_intros_registry: dict[str, int] = {}
    for _c in sorted(claims, key=lambda x: x.id):
        for _phrase in extract_introductions_permissive(_c.text):
            if _phrase not in all_intros_registry:
                all_intros_registry[_phrase] = _c.id
        for _abbrev in extract_abbreviation_intros(_c.text):
            if _abbrev not in all_intros_registry:
                all_intros_registry[_abbrev] = _c.id

    issues: list[dict] = []

    for claim in claims:
        chain = get_ancestor_chain(claim, claims)
        claim_text_lower = claim.text.lower()

        # R32-US (2026-05-04): exclude dep preamble from body-reference
        # scan ONLY when entity-consistent with parent. The dep preamble
        # (`The X of claim N`) refers back to the parent via `of claim N`;
        # if X matches the parent's head noun, scanning it as body text
        # produces 2300+ walker_fp emissions (`method ofclaim 1`-shape).
        # When X DOESN'T match the parent's head noun, it's a real §112(b)
        # entity-mismatch drafting error (e.g., US11740393B2 c9: `The
        # energy harvesting system of claim 1` but c1 introduces `image
        # capturing system`). Body scan must still flag those.
        #
        # Use same-length whitespace mask so char offsets in downstream
        # context-extraction still align with the original claim text.
        dep_m = _DEP_PREAMBLE.match(claim.text)
        body_scan_text = claim_text_lower
        if dep_m:
            dep_head_str = dep_m.group(2).strip()
            parent_claim_id = int(dep_m.group(3))
            dep_head = _extract_head_noun(dep_head_str)
            parent_claim = next((c for c in claims if c.id == parent_claim_id), None)
            parent_head = None
            if parent_claim:
                parent_info = _preamble_head_info(parent_claim)
                if parent_info:
                    parent_head = parent_info[0]
            if dep_head and parent_head and _heads_match(dep_head, parent_head):
                body_scan_offset = dep_m.end()
                body_scan_text = (
                    (' ' * body_scan_offset) + claim_text_lower[body_scan_offset:]
                )

        # Gather all introductions, tracking the ancestor claim each came from.
        # When the same intro phrase appears in multiple ancestors, prefer the
        # lowest claim id (the earliest claim that introduced the term) so
        # did-you-mean attributes references to the original intro, not a
        # re-mention in a nearer ancestor.
        intros_by_term: dict[str, int] = {}
        # R42 (2026-05-04): track which intros came from
        # `extract_abbreviation_intros` separately so a downstream
        # multi-abbrev bridge can recognize compound references
        # like `the MAC PDU` against parent abbrev intros `MAC`+`PDU`.
        abbrev_intros: set[str] = set()

        def _record(phrase: str, ancestor_id: int) -> None:
            existing = intros_by_term.get(phrase)
            if existing is None or ancestor_id < existing:
                intros_by_term[phrase] = ancestor_id

        # R53 (2026-09-04, reports #714/#715): supplementary index of intros as
        # they read once the CONTEXTUAL verb stop is applied. Kept SEPARATE from
        # `intros_by_term` and consulted only after every existing tier fails -
        # see `extract_contextual_cleaned_intros` for why cleaning the intro in
        # place manufactured 22 findings.
        contextual_cleaned_intros: set[str] = set()

        for ancestor in chain:
            ancestor_lower = ancestor.text.lower()
            for phrase in extract_introductions(ancestor_lower):
                _record(phrase, ancestor.id)
            contextual_cleaned_intros.update(
                extract_contextual_cleaned_intros(ancestor_lower)
            )
            for abbrev_intro in extract_abbreviation_intros(ancestor.text):
                _record(abbrev_intro, ancestor.id)
                # Bare lowercase abbrev (no trailing word) → confirmed
                # abbreviation. Multi-word forms (`mac protocol data unit`)
                # are excluded from the abbrev set; we want only the
                # compact acronym entries.
                if abbrev_intro.isalpha() and 2 <= len(abbrev_intro) <= 5:
                    abbrev_intros.add(abbrev_intro)

        # R32-US (2026-05-04): head-noun-from-intro. Promote the LAST
        # word of multi-word Pattern A intros as a separate intro entry
        # so a body reference like `the method` resolves against an intro
        # `method for delivering an e-commerce order` (head noun of the
        # apparatus-claim preamble).
        #
        # Three guards (audited against round-1 705-draft US corpus):
        #
        #   1. Pattern A only - promoted heads come from
        #      `extract_pattern_a_intros` (strict `a/an X` matches), NOT
        #      from `extract_bare_noun_intros` (comprising lists with
        #      gerund phrases like `collecting information`) or
        #      self-definition / wherein-bare-subject extractors. The
        #      gerund-phrase exclusion preserves protect:true label
        #      US20240185203A1 c1 `the information` (real §112(b) defect
        #      where `information` was first introduced via the gerund
        #      `collecting information`, not via Pattern A).
        #
        #   2. Multi-modifier ambiguity - if 2+ Pattern A intros share
        #      the same last word (e.g., `first surface` + `second
        #      surface`), bare `surface` is statutorily ambiguous and
        #      MUST stay flagged. Preserves US7839645B2 c15 protect:true
        #      `the surface`.
        #
        #   3. Last-word floor of 4 chars + _SKIP_TERMS / _QUANTIFIER_STOPS
        #      exclusion - prevents over-resolution on common short
        #      ambiguous tokens (set/data/user/one/two).
        pattern_a_phrases: list[tuple[str, int]] = []
        for ancestor in chain:
            for phrase in extract_pattern_a_intros(ancestor.text):
                pattern_a_phrases.append((phrase, ancestor.id))

        last_word_count: dict[str, int] = {}
        for phrase, _ in pattern_a_phrases:
            words = phrase.split()
            if len(words) < 2:
                continue
            lw = words[-1].strip(' ,.;:()')
            last_word_count[lw] = last_word_count.get(lw, 0) + 1

        for phrase, ancestor_id in pattern_a_phrases:
            words = phrase.split()
            if len(words) < 2:
                continue
            last_word = words[-1].strip(' ,.;:()')
            if len(last_word) < 4:
                continue
            if last_word in _SKIP_TERMS:
                continue
            if last_word in _QUANTIFIER_STOPS:
                continue
            if last_word in intros_by_term:
                continue
            if last_word_count.get(last_word, 0) > 1:
                continue
            _record(last_word, ancestor_id)

        # R40 (2026-05-04): leading-bigram registration with
        # participle-suffix gate. Phase A on the post-R36 corpus
        # showed `aggregate metric` 75 wfp / 0 legit - parent intro
        # `aggregate metric indicative` over-captures the trailing
        # `indicative` (an `-ive` participle) before hitting `of`
        # stop word. Bare reference `the aggregate metric` doesn't
        # match.
        #
        # Mechanism: for a 3-word Pattern A intro `<W1> <W2> <W3>`,
        # register the leading bigram `<W1> <W2>` IF AND ONLY IF
        # the third word ends in `-ive`/`-ing`/`-ed`/`-able`/`-ous`/
        # `-ory`/`-ant`/`-ent` (typical participle/adjective endings
        # that signal over-capture, NOT a real compound noun head).
        # This excludes the test case `common voltage difference
        # circuit` (`circuit` is a real noun head) so the existing
        # `test_long_intro_does_not_mask_short_reference` regression
        # gate stays green.
        _PARTICIPLE_SUFFIX = (
            'ive', 'ing', 'ed', 'able', 'ous', 'ory', 'ant', 'ent',
        )
        leading_bigram_count: dict[str, int] = {}
        for phrase, _ in pattern_a_phrases:
            words = phrase.split()
            if len(words) == 3:
                tail = words[-1].strip(' ,.;:()').lower()
                if any(tail.endswith(suf) for suf in _PARTICIPLE_SUFFIX):
                    bg = ' '.join(words[:2]).strip(' ,.;:()')
                    leading_bigram_count[bg] = leading_bigram_count.get(bg, 0) + 1

        for phrase, ancestor_id in pattern_a_phrases:
            words = phrase.split()
            if len(words) != 3:
                continue
            tail = words[-1].strip(' ,.;:()').lower()
            if not any(tail.endswith(suf) for suf in _PARTICIPLE_SUFFIX):
                continue
            bigram = ' '.join(words[:2]).strip(' ,.;:()')
            bg_words = bigram.split()
            if len(bg_words) != 2:
                continue
            if any(len(w) < 3 for w in bg_words):
                continue
            if len(bigram) < 7:
                continue
            if any(w in _SKIP_TERMS or w in _QUANTIFIER_STOPS for w in bg_words):
                continue
            if bigram in intros_by_term:
                continue
            if leading_bigram_count.get(bigram, 0) > 1:
                continue
            _record(bigram, ancestor_id)

        intros = set(intros_by_term.keys())

        intros_by_number_key: dict[str, int] = {}
        for phrase, phrase_claim_id in intros_by_term.items():
            key = en_number_key(phrase)
            intros_by_number_key.setdefault(key, phrase_claim_id)

        # Find definite references ("the X" and "said X") in this claim
        seen: set[tuple[str, str]] = set()
        # R48: Pattern A intro offsets for THIS claim, plus the set of intros
        # reachable only through arms that carry no offset (those are never
        # vetoed). Computed once per claim, not per reference.
        pattern_a_offsets = pattern_a_intro_offsets(claim_text_lower)
        non_pattern_a_intros = set(
            extract_introductions(claim_text_lower)
        ) - set(pattern_a_offsets)
        for m in _DEFINITE_REF.finditer(body_scan_text):
            raw_noun = m.group("noun").strip()
            ext_m = _THROUGH_HOLE_CONTINUATION.match(body_scan_text[m.end():])
            if ext_m and _BARE_CARDINAL_TAIL.match(raw_noun):
                raw_noun = f"{raw_noun} through {ext_m.group('head')}"
            # WS-A3 (2026-06-24, examiner-grounded): strip a trailing comparative
            # clause from the REFERENCE (`the first element other than …`, `the
            # value greater than …`) - `than` is never a noun-phrase terminus.
            # Reference-side only (NOT in clean_noun_phrase) so it can't generalize
            # an intro and mask a real defect. FN-safe: 201 examiner-unconfirmed
            # corpus instances, 0 of 2,965 examiner-confirmed defects altered.
            raw_noun = " ".join(_strip_comparative_tail(raw_noun.split())) or raw_noun
            # R51 (2026-09-03, reports #705/#706): drop a trailing measurement
            # CONDITION (`the glass fiber material under 10 GHz`). Reference-side
            # only, same rationale as the comparative strip above: an intro-side
            # version could generalize an introduction and mask a real defect.
            raw_noun = (
                " ".join(_strip_measurement_condition_tail(raw_noun.split()))
                or raw_noun
            )
            term = clean_noun_phrase(raw_noun)
            term = strip_contextual_verb(term, claim_text_lower[m.end():])
            # R34 (2026-07-18, report #397): drop a trailing manner adverb
            # left behind once the finite verb it modifies is stripped
            # (`the ports closely join …` → `ports closely` → `ports`).
            term = strip_trailing_adverb(term)
            if not term:
                continue
            # Skip standalone quantifiers/pronouns ("the one", "the another")
            if term.lower() in _QUANTIFIER_STOPS:
                continue
            # R50 (2026-09-02): bare DISTRIBUTIVE SELECTOR, not an element.
            # `a sealing apparatus around the respective said intake and said
            # exhaust ports` and `... from the respective at least one of the
            # original source and the potential relay device` both capture the
            # single word `respective`, because the noun scan stops at the
            # determiner that follows. `the` attaches to the noun phrase, not
            # to the selector, so the selector can never carry an antecedent of
            # its own - and the real head IS checked, by its own reference: all
            # 6 corpus occurrences sit in a claim where the walker separately
            # flags `intake` or `relay`. So this drops a truncation artifact,
            # never a defect.
            #
            # ATTORNEY READ (Christopher, 2026-09-02) - the ensemble labelled
            # the IDENTICAL construction both ways, `walker_fp` on US11492933B2
            # and `legit_drafting_error` on US11522827B2, and the legit
            # rationale contradicts itself: it concedes `respective` is an
            # enumerator/selector and then faults it for lacking an
            # "independent antecedent introduction". Attorney-over-corpus
            # applies; the 3 legit labels are gold-corrected with this note.
            #
            # Gated on a FOLLOWING DETERMINER so it fires only where the head
            # demonstrably continues past the capture - the truncation is
            # evidenced, not assumed.
            if (
                term.lower() in _PREDICATIVE_ADJECTIVES
                and _TRUNCATED_SELECTOR_TRAIL.match(claim_text_lower[m.end():])
            ):
                continue
            # R38 (2026-07-23, reports #409/#414): cataphoric leading modifier
            # ("the FOLLOWING steps:", "the FOLLOWING types") - a reference to the
            # enumerated list that follows, not a missing antecedent.
            if term.split()[0].lower() in _CATAPHORIC_LEADING:
                continue
            # R34 (2026-07-18, report #400): partitive pronoun. `the switched
            # one of the plurality of channels` heads on the PRONOUN `one`,
            # not on an element - the element is whatever follows `of`, and it
            # is checked independently by its own reference. The bare `the
            # one` case is already covered by `_QUANTIFIER_STOPS` above.
            #
            # Deliberately NARROW, because the US examiner ground truth
            # carries four confirmed §112(b) rejections whose term ends in a
            # singular `one` (`the respective one`, `the at least one`, `the
            # current one`, `the first one`). Every one of those modifiers is
            # an ordinal/quantifier/deictic - NONE is a past participle. So
            # the guard fires only for:
            #   * plural `ones`  (`the remaining ones`, `the different ones`)
            #   * singular `one` modified by a PAST PARTICIPLE (`the switched
            #     one`, `the selected one`) - the participle names a selection
            #     operation, which is unambiguously partitive.
            # Verified reachability: 0 of the 3,173 examiner-confirmed terms.
            if _is_partitive_pronoun_head(term) and (
                _PARTITIVE_OF_TRAIL.match(claim_text_lower[m.end():])
            ):
                continue
            # Markush "the group consisting of A, B, C" - 'group' is the
            # head of the Markush definition, not a missing antecedent.
            if term.lower() == "group" and _MARKUSH_GROUP_TRAIL.match(
                claim_text_lower[m.end():]
            ):
                continue
            # Primary: bidirectional word-boundary exact match.
            # Fallback 1: ADR-095 Rule 3 analogue - number-agnostic key
            # match for plural-intro / singular-reference pairs.
            # Fallback 2 (R42): multi-abbrev compound bridge - when the
            # reference is exactly N short uppercase-acronym words and
            # EVERY component is a registered abbreviation intro from
            # the chain (`MAC PDU` ref vs intros `MAC` + `PDU`), accept.
            # Reference compound is a defined-term juxtaposition; both
            # halves were established as separate abbrev intros via
            # `<full term> (ABBR)` parenthetical definitions.
            has_basis = any(
                _word_boundary_match(intro, term) and _word_boundary_match(term, intro)
                for intro in intros
            ) or en_number_key(term) in intros_by_number_key
            if not has_basis and abbrev_intros:
                term_words = term.split()
                if (
                    2 <= len(term_words) <= 4
                    and all(w in abbrev_intros for w in term_words)
                ):
                    has_basis = True

            # R53 (2026-09-04, reports #714/#715): LAST tier, additive by
            # construction. The drafter introduced the element and the intro
            # extractor over-captured the following verb (`a main control
            # command signal OUTPUT BY ...`), so the clean reference matched
            # nothing. Runs only once every tier above has already failed, so it
            # can silence a false positive but can never manufacture one.
            if not has_basis and term in contextual_cleaned_intros:
                has_basis = True

            # US R58 (report #823): a verb at the end of a subordinate clause
            # (`when the bus voltage drops, ...`). Last tier, and it resolves
            # only against the drafter's own introduction of the stem, so it can
            # silence a false positive but never manufacture a finding. See
            # `subordinate_clause_final_verb_stem` for why the clause, not the
            # word, is the discriminator.
            if not has_basis:
                stem = subordinate_clause_final_verb_stem(
                    term, claim_text_lower[:m.start()], claim_text_lower[m.end():]
                )
                if stem and stem in intros:
                    has_basis = True
            if not has_basis:
                def _head_has_basis(head: str) -> bool:
                    if head.lower() in _QUANTIFIER_STOPS or head.split()[0].isdigit():
                        return False
                    owners = [
                        i for i in intros
                        if _word_boundary_match(i, head) and _word_boundary_match(head, i)
                    ]
                    if not owners:
                        return False
                    if any(intros_by_term.get(i) != claim.id for i in owners):
                        return True
                    return not (
                        all(i in pattern_a_offsets for i in owners)
                        and not any(i in non_pattern_a_intros for i in owners)
                        and all(min(pattern_a_offsets[i]) > m.start() for i in owners)
                    )
                known = known_intro_with_predicate_tail(
                    term, _head_has_basis, claim_text_lower[m.end():],
                    claim_text_lower[:m.start()],
                )
                if known is not None:
                    has_basis = True

            # US R48 (report #677): basis must PRECEDE the reference.
            #
            # NEVER veto inside the dependent-claim PREAMBLE. `The antibody ...
            # of claim 1` is a back-reference to the parent by construction, so
            # its position within the claim carries no antecedent meaning. The
            # preamble is normally masked out of the body scan, but only when
            # its head noun matches the parent's; US12060411B2 c4 (`The antibody
            # or antigen-binding fragment thereof of claim 1`) fails that head
            # match, so without this guard the veto manufactured a finding on a
            # perfectly ordinary dependent preamble.
            in_dep_preamble = bool(dep_m) and m.start() < dep_m.end()
            if has_basis and not in_dep_preamble:
                exact_matching = [
                    intro for intro in intros
                    if _word_boundary_match(intro, term)
                    and _word_boundary_match(term, intro)
                ]
                number_key_owner = intros_by_number_key.get(en_number_key(term))
                ancestor_basis = any(
                    intros_by_term.get(i) != claim.id for i in exact_matching
                ) or (
                    number_key_owner is not None and number_key_owner != claim.id
                )
                if exact_matching and not ancestor_basis:
                    # Every basis must be a Pattern A intro we can locate, and
                    # every located occurrence must sit after the reference.
                    if all(i in pattern_a_offsets for i in exact_matching) and not any(
                        i in non_pattern_a_intros for i in exact_matching
                    ):
                        if all(
                            min(pattern_a_offsets[i]) > m.start()
                            for i in exact_matching
                        ):
                            has_basis = False

            # Bare-noun introduction (R4, issues #71/#91/#92): a
            # multi-word term first mentioned article-less - earlier in
            # this claim, or in an ancestor - has antecedent basis by
            # implication (MPEP § 2173.05(e)). The intro-pattern
            # extractors only register quantified / framed intros, so
            # preamble terms and verb objects slip through.
            if not has_basis and has_bare_noun_introduction(
                claim.text, chain, term, m.start()
            ):
                has_basis = True

            if not has_basis:
                if term not in _SKIP_TERMS and not term.startswith("fig") and not term.startswith("claim"):
                    prefix = m.group("prefix").lower()
                    reference_form = f"{prefix} {term}"
                    dedup_key = (term, reference_form)
                    if dedup_key not in seen:
                        seen.add(dedup_key)
                        # Did-you-mean: highest-Jaccard intro in ancestor set
                        # at threshold ≥ 0.5. Surfaces morphological variants
                        # (calculation/calculating, protection/protecting)
                        # without silently matching them.
                        # Did-you-mean: pick the highest-Jaccard intro at
                        # threshold ≥ 0.5, with a stemmed-symmetric-difference
                        # tiebreak so morphological pairs (protection/protecting,
                        # both stem to 'protect') beat coincidental token
                        # overlaps with unrelated nouns.
                        #
                        # Tiebreak rationale: when two candidates tie on
                        # Jaccard, the one whose differing tokens stem to the
                        # SAME root as the reference's differing tokens is the
                        # morphological pair we want to surface. On testspec5,
                        # 'surge protecting circuit' ties with both 'surge
                        # protection circuit' (stem_sym_diff = ∅, perfect pair)
                        # and 'surge suppressor circuit' (stem_sym_diff = 2,
                        # unrelated). Stemmed comparison picks the former.
                        #
                        # ADR-090 not violated: this only chooses a BETTER hint
                        # within an already-emitted finding. The reference is
                        # still flagged; stemming never silently masks anything.
                        # Quality threshold (#57): require Jaccard ≥ 2/3
                        # (≥2-of-3 token overlap), with a carveout admitting
                        # 0.5 ≤ score < 2/3 IFF stemming collapsed the
                        # symmetric difference (stem_sym_diff < raw_sym_diff) -
                        # pure morphological variants like protecting/protection
                        # or resister/resistor stay surfaced, while coincidental
                        # 2-of-4-token overlaps ("duty cycle threshold" ↔
                        # "specified duty cycle") drop out.
                        _MIN_JACCARD = 2.0 / 3.0
                        def _accept(score: float, raw_diff: int, stem_diff: int) -> bool:
                            if score + 1e-9 >= _MIN_JACCARD:
                                return True
                            return score >= 0.5 and stem_diff < raw_diff
                        suggested_match: Optional[dict] = None
                        best_score = 0.0
                        best_stem_diff: Optional[int] = None
                        term_tokens = set(term.lower().split())
                        for intro in intros:
                            score = token_set_jaccard(term, intro)
                            intro_tokens = set(intro.lower().split())
                            sym_diff = term_tokens ^ intro_tokens
                            stem_sym_diff = len(
                                set(_stemmer.stemWords(list(sym_diff)))
                            )
                            if not _accept(score, len(sym_diff), stem_sym_diff):
                                continue
                            if (
                                score > best_score
                                or (
                                    score == best_score
                                    and (
                                        best_stem_diff is None
                                        or stem_sym_diff < best_stem_diff
                                    )
                                )
                            ):
                                best_score = score
                                best_stem_diff = stem_sym_diff
                                suggested_match = {
                                    "term": intro,
                                    "claim_id": intros_by_term[intro],
                                }
                        # Fix #47 fallback + cross-branch exact-match override:
                        # scan all-prior-claims registry for a cross-branch intro
                        # from an earlier-numbered claim. Promote when (a) no
                        # ancestor suggestion surfaced, OR (b) the cross-branch
                        # candidate strictly outscores the ancestor pick - this
                        # lets a Jaccard=1.0 cross-branch exact match override a
                        # loose ancestor-chain pairing (e.g. "duty cycle threshold"
                        # in c10 beats "current duty cycle" in c9 ancestor chain).
                        # Informational only; finding remains flagged because
                        # §112 ¶2 antecedent basis requires an ancestor intro.
                        fb_best_score = best_score
                        fb_best_stem_diff: Optional[int] = best_stem_diff
                        for fb_intro, fb_cid in all_intros_registry.items():
                            if fb_cid >= claim.id:
                                continue
                            if fb_intro in intros_by_term:
                                continue
                            fb_score = token_set_jaccard(term, fb_intro)
                            fb_intro_tokens = set(fb_intro.lower().split())
                            fb_sym_diff = term_tokens ^ fb_intro_tokens
                            fb_stem_sym_diff = len(
                                set(_stemmer.stemWords(list(fb_sym_diff)))
                            )
                            if not _accept(fb_score, len(fb_sym_diff), fb_stem_sym_diff):
                                continue
                            if (
                                fb_score > fb_best_score
                                or (
                                    fb_score == fb_best_score
                                    and (
                                        fb_best_stem_diff is None
                                        or fb_stem_sym_diff < fb_best_stem_diff
                                    )
                                )
                            ):
                                fb_best_score = fb_score
                                fb_best_stem_diff = fb_stem_sym_diff
                                # cross_branch flag distinguishes an intro found
                                # outside the current claim's ancestor chain from
                                # an ancestor-chain near-miss. The UI uses this
                                # plus an exact-term-match check to render a
                                # "term defined in claim N, not in dependency
                                # chain" message instead of the generic
                                # "Did you mean …?" DYM hint - the drafter
                                # already knows the term; the real issue is the
                                # dependency structure.
                                suggested_match = {
                                    "term": fb_intro,
                                    "claim_id": fb_cid,
                                    "cross_branch": True,
                                }
                        # Structural fingerprint (ADR-145) - surfaces walker
                        # intro-pool + did-you-mean state. Counts + booleans
                        # only; no claim text, no noun content.
                        diagnostics = {
                            "prefix": prefix,  # "the" or "said" - closed set
                            "term_charlen": len(term),
                            "intros_pool_size": len(intros_by_term),
                            "has_suggested_match": suggested_match is not None,
                            "suggested_cross_branch": bool(
                                suggested_match
                                and suggested_match.get("cross_branch")
                            ) if suggested_match else False,
                        }
                        confidence_score = compute_confidence_score(
                            term=term,
                            prefix=prefix,
                            intros_pool_size=len(intros_by_term),
                            has_suggested_match=suggested_match is not None,
                            suggested_cross_branch=bool(
                                suggested_match
                                and suggested_match.get("cross_branch")
                            ),
                            suggested_jaccard=fb_best_score if suggested_match else None,
                            suggested_same_claim=bool(
                                suggested_match
                                and suggested_match.get("claim_id") == claim.id
                            ),
                            reference_form=reference_form,
                            jurisdiction="US",
                        )
                        # Parent-claim diagnostic enrichment: does the
                        # flagged term appear verbatim in an ancestor
                        # claim? If so the introduction exists but in a
                        # shape the intro extractor missed (walker FP);
                        # if not, a genuine §112 gap. `ancestor_match_text`
                        # stays in-process - the extractor windows it.
                        anc_match_id, anc_match_text = first_ancestor_with_term(
                            chain, term
                        )
                        # DISPLAY-ONLY term cleanup (2026-09-02, reports
                        # #676/#681/#688). See `gerund_display_head` for why
                        # this is applied HERE and nowhere else: resolution,
                        # the `seen` dedup, the document dedup key and the
                        # ancestor diagnostic all keep the RAW term, so the
                        # finding COUNT is provably unchanged and only what the
                        # reporter reads gets cleaner.
                        #
                        # BOTH emitted fields are cleaned, because the surfaces
                        # the reporter actually sees render `reference_form`
                        # and fall back to `term`, never the other way round
                        # (AntecedentBasisCard `f.reference_form || f.term`,
                        # ReportModal, and the PDF export). Cleaning `term`
                        # alone would have been invisible in the UI, the report
                        # payload and the PDF - i.e. invisible to exactly the
                        # people who filed these reports.
                        display_term = (
                            gerund_display_head(term)
                            or strip_display_negation(term)
                            or term
                        )
                        display_reference_form = (
                            f"{prefix} {display_term}"
                            if display_term != term else reference_form
                        )
                        issues.append({
                            "claim_id": claim.id,
                            "term": display_term,
                            "reference_form": display_reference_form,
                            "claim_text": claim.text,
                            "suggested_match": suggested_match,
                            "cross_ref": None,
                            "diagnostics": diagnostics,
                            "document_dedup_key": make_document_dedup_key(
                                term, reference_form
                            ),
                            "confidence_score": confidence_score,
                            "ancestor_claim_ids": [c.id for c in chain[1:]],
                            "ancestor_match_claim_id": anc_match_id,
                            "ancestor_match_text": anc_match_text,
                        })

    issues.sort(key=lambda x: (x["claim_id"], x["term"], x["reference_form"]))
    return issues


def _get_ngrams(text: str, n: int) -> list[str]:
    words = text.lower().split()
    return [" ".join(words[i:i + n]) for i in range(len(words) - n + 1)]


def calculate_similarity(text1: str, text2: str) -> float:
    """Calculate similarity using N-gram Jaccard index."""
    ngrams1 = set(_get_ngrams(text1, 1) + _get_ngrams(text1, 2))
    ngrams2 = set(_get_ngrams(text2, 1) + _get_ngrams(text2, 2))

    intersection = ngrams1 & ngrams2
    union = ngrams1 | ngrams2

    return len(intersection) / len(union) if union else 0.0


# --- Preamble consistency (B1) ---

_TRANSITIONS = re.compile(
    r",?\s*(?:"
    r"(?:"
    r"comprising\s*(?:the\s+steps?\s+of\s*)?"
    r"|consisting\s+essentially\s+of"
    r"|consisting\s+of"
    r"|including"
    r"|having"
    r")\s*:"
    r"|wherein\b"
    r")",
    re.IGNORECASE,
)

_DEP_PREAMBLE = re.compile(
    # Covers MPEP § 608.01(n)(iii) accepted forms:
    #   "The X of claim N"           (most common)
    #   "The X according to claim N"
    #   "The X as in claim N"        ("as in")
    #   "The X as claimed in claim N"  (British form)
    #   "The X as recited in claim N"
    #   "The X as set forth in claim N"
    #
    # R32-US (2026-05-04): leading `\d+\.` claim-number prefix tolerated
    # (Claim.text often retains the parser's claim number); connector→
    # claim spacing relaxed from \s+ to \s* so Google Patents HTML
    # extraction artifacts (`ofclaim 1`, `according toclaim 1`) still
    # match. ~2300 walker_fp emissions on the round-1 705-draft US corpus
    # arose from dep-preamble detection failing → walker scanned the
    # preamble as body text and emitted `the method ofclaim 1` as a
    # bogus reference.
    #
    # R46 (2026-08-25, reports #603/#604/#605/#606/#607/#608): the CONNECTOR
    # is optional. A drafter wrote `The command message exchanging method
    # claim 10, further comprising ...`, dropping `according to`. This is the
    # exact sibling of R40, which made the WORD `claim` optional in _DEP_REF
    # after a drafter wrote `according to 1`; here the connector is dropped
    # instead and `claim N` survives.
    #
    # The dependency itself already resolved - `_DEP_REF` is `claims?\s+\d+`
    # and matched, so the claim parsed as dependent on 10 and inherited its
    # ancestors. What FAILED is only this preamble exclusion, so the walker
    # scanned the preamble as body text and emitted the reference
    # `the command message exchanging method claim 10` - a string that
    # appears nowhere in the draft. SIX reports (#603-#608, five antecedent
    # plus one spec-support) trace to this one unexcluded preamble.
    #
    # FN-safety: the entity-consistency guard downstream is unchanged, so the
    # exclusion still only applies when the preamble head matches the parent's
    # head noun - a genuine entity mismatch (`The energy harvesting system
    # claim 1` over an image-capturing parent) is still scanned and still
    # flagged. And the reading is not new: `_DEP_REF` already committed this
    # claim to depending on 10, so making the connector optional aligns the
    # exclusion with a dependency the parser had already resolved rather than
    # inventing one. The drafter's omission remains visible through the
    # dependency-format check; the claim text is never rewritten.
    r"^(?:\d+\s*[.\-]?\s*)?(The|An?)\s+(.*?)\s+"
    r"(?:"
    r"of"
    r"|according\s+to"
    r"|as\s+in"
    r"|as\s+claimed\s+in"
    r"|as\s+recited\s+in"
    r"|as\s+set\s+forth\s+in"
    r")?\s*claims?\s+(\d+)",
    re.IGNORECASE,
)

_JEPSON_PATTERN = re.compile(
    r"^In\s+(?:a|an)\s+.*?,\s+the\s+improvement\s+comprising",
    re.IGNORECASE,
)

_METHOD_NOUNS = {"method", "process", "technique", "procedure", "step"}
_CRM_NOUNS = {"medium", "memory", "storage"}
_CRM_CONTEXT = {"readable", "transitory", "non-transitory"}

# Stop words for head noun extraction.
# Includes prepositional / participial phrase markers so the head noun
# extractor stops at the first qualifier rather than swallowing the rest
# of the preamble (e.g., "motor driver for adjusting power based on
# common voltage" → "motor driver" instead of the whole string).
_PREAMBLE_STOP = re.compile(
    r"\b(for|of|to|with|having|comprising|including|that|which"
    r"|based\s+on|adapted\s+to|configured\s+to|capable\s+of|storing)\b",
    re.IGNORECASE,
)


def _extract_head_noun(preamble_text: str) -> str | None:
    """Extract the core head noun from a claim preamble text."""
    # Remove leading article
    text = re.sub(r"^(?:a|an|the)\s+", "", preamble_text.strip(), flags=re.IGNORECASE).strip()
    if not text:
        return None

    # Stop at first comma, or purpose clause
    comma_idx = text.find(",")
    if comma_idx > 0:
        text = text[:comma_idx].strip()

    # Stop at stop words
    m = _PREAMBLE_STOP.search(text)
    if m:
        text = text[:m.start()].strip()

    # Take last meaningful word(s) - typically the head noun
    words = text.lower().split()
    if not words:
        return None

    return " ".join(words)


def _classify_entity(head_noun: str, full_preamble: str) -> str:
    """Classify entity as 'method', 'crm', or 'product'."""
    words = head_noun.lower().split()
    # Check if any word is a method noun
    if any(w in _METHOD_NOUNS for w in words):
        return "method"
    # Check CRM
    if any(w in _CRM_NOUNS for w in words):
        preamble_lower = full_preamble.lower()
        if any(ctx in preamble_lower for ctx in _CRM_CONTEXT):
            return "crm"
    return "product"


def _find_root_independent(claim: Claim, all_claims: list[Claim]) -> Claim | None:
    """Walk dependency graph (BFS) to find the first reachable independent claim.

    If a dependent claim has multiple independent roots with conflicting
    preamble entity types (rare in multi-dep claims), only the first
    BFS-reached root is returned.  This is a known limitation.
    """
    if claim.independent:
        return claim
    claims_by_id = {c.id: c for c in all_claims}
    visited: set[int] = {claim.id}
    queue = list(claim.dependencies)
    while queue:
        parent_id = queue.pop(0)
        if parent_id in visited:
            continue
        visited.add(parent_id)
        parent = claims_by_id.get(parent_id)
        if parent is None:
            continue
        if parent.independent:
            return parent
        queue.extend(parent.dependencies)
    return None


def _find_immediate_parent(claim: Claim, all_claims: list[Claim]) -> Claim | None:
    """Return the first existing immediate parent from claim.dependencies.

    For multi-dependent claims (dependencies = [1, 5]), callers should iterate
    all dependencies via _find_all_immediate_parents to unflag when ANY parent
    head matches. This helper returns only the first existing parent.

    Unlike _find_root_independent (which walks the full dependency graph BFS
    to find the transitive root), this helper walks exactly one hop. Used by
    check_preamble_consistency per ADR-092: the comparison target for
    §608.01(m) indefinite-article and noun-mismatch branches is the immediate
    parent, not the transitive root. Cross-category dependents (MPEP
    608.01(n)(III)) may introduce new entities that incorporate their parent,
    and the article rule applies relative to the nearest ancestor, not the
    original independent.
    """
    if claim.independent:
        return None
    claims_by_id = {c.id: c for c in all_claims}
    for parent_id in claim.dependencies:
        parent = claims_by_id.get(parent_id)
        if parent is not None:
            return parent
    return None


def _find_all_immediate_parents(claim: Claim, all_claims: list[Claim]) -> list[Claim]:
    """Return all existing immediate parent claims (multi-dependent support).

    Multi-dependent claim unflagging rule: check_preamble_consistency unflags
    when the dep head noun matches ANY immediate parent's head noun.
    """
    if claim.independent:
        return []
    claims_by_id = {c.id: c for c in all_claims}
    parents: list[Claim] = []
    for parent_id in claim.dependencies:
        parent = claims_by_id.get(parent_id)
        if parent is not None:
            parents.append(parent)
    return parents


def _preamble_head_info(claim: Claim) -> tuple[str, str] | None:
    """Return (head_noun, entity_type) for any claim (independent or dependent).

    Independent claims: extract the head noun from the preamble text before
    the transitional phrase. Dependent claims: use the noun phrase captured
    between the leading article and "of claim N" / "according to claim N"
    in the dependent preamble, then normalize via _extract_head_noun so the
    comma stop and stop-word tail trimming apply consistently.
    """
    if claim.independent:
        tm = _TRANSITIONS.search(claim.text)
        if not tm:
            return None
        preamble_text = claim.text[:tm.start()].strip()
        head = _extract_head_noun(preamble_text)
        if not head:
            return None
        return head, _classify_entity(head, preamble_text)

    dm = _DEP_PREAMBLE.match(claim.text)
    if not dm:
        return None
    dep_raw = dm.group(2).strip()
    head = _extract_head_noun(dep_raw)
    if not head:
        return None
    return head, _classify_entity(head, dep_raw)


def _heads_match(dep_head: str, parent_head: str) -> bool:
    """Case-insensitive exact-or-substring match per ADR-092 v1 semantics.

    Hyponym detection is deferred; exact and substring containment are
    sufficient for observed cross-category dependents.
    """
    if not dep_head or not parent_head:
        return False
    a = dep_head.lower().strip()
    b = parent_head.lower().strip()
    if a == b:
        return True
    return a in b or b in a


def check_preamble_consistency(claims: list[Claim]) -> list[CheckItem]:
    """Check that dependent claims reference the same entity type as their
    immediate parent (ADR-092).

    Both branches (indefinite-article §608.01(m) and noun/entity mismatch)
    compare the dependent claim's head noun against its immediate parent(s),
    not the transitive root independent. For multi-dependent claims, a match
    against ANY existing immediate parent unflags the finding.

    Returns CheckItem per finding (PASS if no issues, AMEND/VERIFY per problem).
    """
    results: list[CheckItem] = []
    has_issue = False
    # ADR-145: track dependents whose preamble didn't match any recognized
    # MPEP § 608.01(n)(iii) form so the aggregate parseUnclear finding can
    # surface them as a single "walker couldn't verify" signal rather than
    # silently skipping.
    unclear_ids: list[int] = []
    unclear_fp: dict[str, Any] | None = None

    for claim in claims:
        if claim.independent:
            continue

        dm = _DEP_PREAMBLE.match(claim.text)
        if not dm:
            unclear_ids.append(claim.id)
            if unclear_fp is None:
                unclear_fp = {
                    "dep_preamble_matched": False,
                    "claim_charlen": len(claim.text),
                }
            continue

        article = dm.group(1)
        parent_claim_num = int(dm.group(3))

        dep_info = _preamble_head_info(claim)
        if dep_info is None:
            unclear_ids.append(claim.id)
            if unclear_fp is None:
                unclear_fp = {
                    "dep_preamble_matched": True,
                    "head_noun_extracted": False,
                }
            continue
        dep_noun, dep_entity = dep_info

        parents = _find_all_immediate_parents(claim, claims)
        parent_infos = [
            info for info in (_preamble_head_info(p) for p in parents) if info is not None
        ]
        if not parent_infos:
            continue

        # §608.01(m) indefinite-article branch. Per MPEP 608.01(n)(III), a
        # dependent claim may introduce a new entity that incorporates its
        # parent - in that case "A/An" is mandatory. Only flag when the dep
        # head noun matches an immediate parent's head noun (i.e., same
        # entity, user typed the wrong article).
        if article.lower() in ("a", "an"):
            matches_parent = any(
                _heads_match(dep_noun, p_noun) for p_noun, _ in parent_infos
            )
            if matches_parent:
                results.append(CheckItem(
                    status="amend",
                    message=f"Claim {claim.id}: indefinite article '{article}' in dependent claim preamble (should be 'The').",
                    message_key="checks.preamble_indefinite_article",
                    details=f"Claim {claim.id} depends on claim {parent_claim_num}",
                    details_key="details.preambleIndefiniteArticle",
                    details_params={
                        "claim": str(claim.id),
                        "parent": str(parent_claim_num),
                        "article": article,
                        "noun": dep_noun,
                    },
                    diagnostics={
                        "article": article.lower(),
                        "dep_head_charlen": len(dep_noun),
                    },
                ))
                has_issue = True
            continue

        # Noun/entity mismatch branch. Unflag if any immediate parent matches
        # both head noun and entity type.
        if any(
            _heads_match(dep_noun, p_noun) and dep_entity == p_entity
            for p_noun, p_entity in parent_infos
        ):
            continue

        # No immediate parent matched - report against the first parent.
        p_noun, p_entity = parent_infos[0]

        if dep_entity != p_entity:
            results.append(CheckItem(
                status="amend",
                message=f"Claim {claim.id}: cross-category mismatch ({dep_entity} depends on {p_entity} claim {parent_claim_num}).",
                message_key="checks.preamble_cross_category_mismatch",
                details=f"Dependent '{dep_noun}' vs parent '{p_noun}'",
                details_key="details.nounMismatch",
                details_params={"dependent": dep_noun, "independent": p_noun},
                diagnostics={
                    "dep_entity": dep_entity,
                    "parent_entity": p_entity,
                    "dep_head_charlen": len(dep_noun),
                    "parent_head_charlen": len(p_noun),
                },
            ))
            has_issue = True
        elif dep_noun != p_noun:
            results.append(CheckItem(
                status="verify",
                message=f"Claim {claim.id}: preamble noun '{dep_noun}' differs from parent claim '{p_noun}'.",
                message_key="checks.preamble_noun_mismatch",
                details=f"Claim {claim.id} depends on claim {parent_claim_num}",
                details_key="details.preambleNounMismatch",
                details_params={
                    "claim": str(claim.id),
                    "parent": str(parent_claim_num),
                    "dependent": dep_noun,
                    "independent": p_noun,
                },
                diagnostics={
                    "dep_head_charlen": len(dep_noun),
                    "parent_head_charlen": len(p_noun),
                },
            ))
            has_issue = True

    if unclear_ids:
        claims_str = ", ".join(str(i) for i in unclear_ids)
        results.append(CheckItem(
            status="verify",
            message=f"{len(unclear_ids)} dependent claim(s) with an unrecognized preamble - couldn't verify preamble consistency (claims: {claims_str}).",
            message_key="checks.preamble_parse_unclear",
            details=f"{len(unclear_ids)} claims",
            details_key="details.preambleParseUnclear",
            details_params={"count": len(unclear_ids), "claims": unclear_ids},
            diagnostics=unclear_fp,
        ))
        has_issue = True

    if not has_issue:
        results.append(CheckItem(
            status="pass",
            message="Claim preambles are consistent.",
            message_key="checks.preamble_cross_category_pass",
        ))

    return results


# --- Spec support (B3) ---

_stemmer = _sb.stemmer("english")

# --- Claim transition phrase check (Issue #4) ---

_TRANSITION_PHRASES = re.compile(
    r"\b(?:"
    r"comprising|comprises"
    r"|consisting\s+essentially\s+of|consists\s+essentially\s+of"
    r"|consisting\s+of|consists\s+of"
    r"|including|includes"
    r"|containing|contains"
    r"|having"
    r"|characterized\s+in\s+that"
    r"|characterized\s+by"
    r")\b",
    re.IGNORECASE,
)

_TRANSITION_AT_BOUNDARY = re.compile(
    r"\b(?:"
    r"(?:comprising|comprises)\s*(?:the\s+steps?\s+of\s*)?"
    r"|(?:consisting|consists)\s+essentially\s+of"
    r"|(?:consisting|consists)\s+of"
    r"|including|includes"
    r"|containing|contains"
    r"|having"
    r"|characterized\s+by"
    r")\s*:"
    r"|\bcharacterized\s+in\s+that\b",
    re.IGNORECASE,
)


def check_claim_transitions(claims: list[Claim]) -> list[CheckItem]:
    """Check that every independent claim contains a recognized transition phrase.

    Returns one AMEND CheckItem per independent claim missing a transition,
    or a single PASS if all independent claims have transitions.
    """
    results: list[CheckItem] = []

    for claim in claims:
        if not claim.independent:
            continue
        has_transition = _TRANSITION_AT_BOUNDARY.search(claim.text)
        if not has_transition:
            if ":" not in claim.text:
                has_transition = _TRANSITION_PHRASES.search(claim.text)
            else:
                # Colon present but the transition is not immediately before
                # it. A transition word can still legitimately sit earlier in
                # the preamble ahead of a body-introducing colon, e.g.
                # `... method, comprising performing, by a device, the
                # following processes:` (#212) or `... medium comprising a
                # plurality of instructions that, when executed, cause the
                # processor to:` (#213). The transition's role is to divide
                # preamble from body, so it must appear BEFORE the first
                # colon - scan only that span (avoids matching an incidental
                # `having`/`including` inside the colon-introduced body).
                pre_colon = claim.text.split(":", 1)[0]
                has_transition = _TRANSITION_PHRASES.search(pre_colon)
        if not has_transition:
            results.append(CheckItem(
                status="amend",
                message=f"Claim {claim.id} is missing a transitional phrase (e.g., 'comprising', 'consisting of')",
                message_key="check.claims.missingTransition",
                details=f"Claim {claim.id} does not contain a recognized transitional phrase. Every claim must include a transitional phrase such as 'comprising', 'consisting of', 'consisting essentially of', 'including', 'containing', 'characterized by', or 'characterized in that' between the preamble and the claim body.",
                details_key="check.claims.missingTransitionDetails",
                details_params={"claimNumber": str(claim.id)},
                diagnostics=_dx(
                    flagged_claim_id=claim.id,
                    has_colon=":" in claim.text,
                    total_claims=len(claims),
                    preamble=(claim.text or "")[:120],
                    claim_text_charlen=len(claim.text or ""),
                ),
            ))

    if not results:
        results.append(CheckItem(
            status="pass",
            message="All claims contain transitional phrases.",
            message_key="check.claims.transitionsPresent",
        ))

    return results


# --- Special claim format checks (Issue #6) ---

_JEPSON_SPECIAL = re.compile(
    r"\b(?:"
    r"the\s+improvement\s+(?:comprising|which\s+comprises|wherein)"
    r"|wherein\s+the\s+improvement(?:\s+comprises)?"
    r")\b",
    re.IGNORECASE,
)

_CRM_MEDIUM = re.compile(
    r"\b(?:computer[- ]?readable|machine[- ]?readable)\s+(?:storage\s+)?medium"
    r"|\b(?:storage|recording)\s+medium",
    re.IGNORECASE,
)

_NON_TRANSITORY = re.compile(r"\bnon[- ]?transitory\b", re.IGNORECASE)

_MARKUSH_OPEN = re.compile(
    r"selected\s+from\s+(?:the|a)\s+group\s+"
    r"(comprising|including|containing)",
    re.IGNORECASE,
)

_OMNIBUS_LANG = re.compile(
    r"\bsubstantially\s+as\s+(?:shown|described|illustrated)\b"
    r"|\bas\s+(?:herein|hereinbefore|hereinabove)\s+described\b"
    r"|\bas\s+(?:shown|described|illustrated|depicted)\s+in\s+(?:the\s+)?(?:figures?|drawings?|FIG)\b"
    r"|\bthe\s+invention\s+as\s+described\b",
    re.IGNORECASE,
)


def check_special_claim_formats(claims: list[Claim]) -> list[CheckItem]:
    """Detect special claim formats and emit actionable warnings.

    Returns CheckItems only for detected formats - no PASS when nothing found.

    Checks:
    1. Jepson claims - prior art concession warning (VERIFY)
    2. CRM claims missing "non-transitory" (AMEND)
    3. Markush groups with open transitional phrase (VERIFY)
    4. Omnibus claims (AMEND)
    """
    results: list[CheckItem] = []

    for claim in claims:
        # 1. Jepson - independent only
        if claim.independent and _JEPSON_SPECIAL.search(claim.text):
            results.append(CheckItem(
                status="verify",
                message=(
                    f"Claim {claim.id} uses Jepson format - preamble elements "
                    f"are treated as admitted prior art (MPEP § 2129)"
                ),
                message_key="claims.jepsonPriorArt",
                details=(
                    f"Claim {claim.id} is drafted in Jepson format. Under MPEP § 2129, "
                    f"the elements recited in the preamble of a Jepson claim are treated "
                    f"as an implied admission that they are prior art. Verify that this "
                    f"admission is intentional."
                ),
                details_key="claims.jepsonPriorArtDetails",
                details_params={"claimNumber": str(claim.id)},
                diagnostics=_dx(
                    **extract_special_format(claim, kind="jepson"),
                    total_claims=len(claims),
                    reason_code="jepson_format",
                ),
            ))

        # 2. CRM non-transitory - independent only
        if claim.independent and _CRM_MEDIUM.search(claim.text):
            if not _NON_TRANSITORY.search(claim.text):
                results.append(CheckItem(
                    status="amend",
                    message=(
                        f"Claim {claim.id}: computer-readable medium claim "
                        f"is missing 'non-transitory' qualifier"
                    ),
                    message_key="claims.crmNonTransitory",
                    details=(
                        f"Claim {claim.id} recites a computer-readable medium without "
                        f"the 'non-transitory' qualifier. Without this qualifier, the "
                        f"claim covers transitory signals (e.g., carrier waves), which "
                        f"are not patent-eligible subject matter under 35 U.S.C. § 101. "
                        f"Add 'non-transitory' before the medium term."
                    ),
                    details_key="claims.crmNonTransitoryDetails",
                    details_params={"claimNumber": str(claim.id)},
                    diagnostics=_dx(
                        **extract_special_format(claim, kind="crm_non_transitory"),
                        total_claims=len(claims),
                        reason_code="missing_non_transitory_qualifier",
                    ),
                ))

        # 3. Markush - all claims
        markush_match = _MARKUSH_OPEN.search(claim.text)
        if markush_match:
            transition = markush_match.group(1)
            results.append(CheckItem(
                status="amend",
                message=(
                    f"Claim {claim.id}: Markush group uses open-ended "
                    f"'{transition}' instead of 'consisting of'"
                ),
                message_key="claims.markushOpenTransition",
                details=(
                    f"Claim {claim.id} contains a Markush group using '{transition}' "
                    f"instead of the required 'consisting of'. Markush groups must use "
                    f"closed transitional language per MPEP § 2117. Using open-ended "
                    f"language may result in an improper Markush grouping rejection."
                ),
                details_key="claims.markushOpenTransitionDetails",
                details_params={"claimNumber": str(claim.id), "transition": transition},
                diagnostics=_dx(
                    flagged_claim_id=claim.id,
                    transition=transition.lower(),
                    total_claims=len(claims),
                    matched_phrase=(markush_match.group(0) if markush_match else "")[:120],
                    preamble=(claim.text or "")[:120],
                ),
            ))

        # 4. Omnibus - all claims, requires short text + omnibus language
        word_count = len(claim.text.split())
        omnibus_match = _OMNIBUS_LANG.search(claim.text)
        if word_count < 50 and omnibus_match:
            results.append(CheckItem(
                status="amend",
                message=f"Claim {claim.id} appears to be an omnibus claim",
                message_key="claims.omnibusClaim",
                details=(
                    f"Claim {claim.id} references the description or drawings without "
                    f"reciting specific technical features. Omnibus claims are "
                    f"categorically rejected under 35 U.S.C. § 112(b) in U.S. utility "
                    f"patents (MPEP § 2173.05(r)). Rewrite the claim to recite specific "
                    f"structural or method limitations."
                ),
                details_key="claims.omnibusClaimDetails",
                details_params={"claimNumber": str(claim.id)},
                diagnostics=_dx(
                    flagged_claim_id=claim.id,
                    word_count=word_count,
                    total_claims=len(claims),
                    matched_phrase=omnibus_match.group(0)[:120],
                    preamble=(claim.text or "")[:120],
                ),
            ))

    if not results:
        results.append(CheckItem(
            status="pass",
            message="No special claim format issues detected.",
            message_key="claims.specialFormatsPass",
        ))

    return results


def check_claim_punctuation(claims: list[Claim]) -> list[CheckItem]:
    """Check claim punctuation rules per MPEP § 608.01(m).

    Sub-checks:
    1. Missing final period - every claim must end with a period
    2. Extra periods - claims should not contain misplaced periods mid-claim
    3. Wherein comma - 'wherein' clauses require correct comma placement

    Emits individual AMEND/VERIFY per finding, or single PASS if all clean.
    """
    from patentlint.parser.claims import detect_incorrect_wherein_commas

    results: list[CheckItem] = []

    # Pre-compute per-claim character lookups so fingerprints can carry
    # the last-char codepoint (spots fullwidth vs halfwidth period
    # confusion) without rescanning claims for every finding.
    claim_text_by_id = {c.id: c.text.strip() for c in claims}

    for claim_id in find_missing_periods(claims):
        text = claim_text_by_id.get(claim_id, "")
        last_cp = ord(text[-1]) if text else None
        results.append(CheckItem(
            status="amend",
            message=f"Claim {claim_id} does not end with a period.",
            message_key="claims.missingPeriod",
            details=f"Claim {claim_id} is missing its final period. Every claim must end with a single period per MPEP § 608.01(m).",
            details_key="claims.missingPeriodDetails",
            details_params={"claimNumber": str(claim_id)},
            diagnostics=_dx(
                flagged_claim_id=claim_id,
                last_codepoint=last_cp,
                last_char_class=("digit" if text and text[-1].isdigit()
                                 else "letter" if text and text[-1].isalpha()
                                 else "punct" if text else "empty"),
                claim_text_charlen=len(text),
                total_claims=len(claims),
                last_30_chars=text[-30:] if text else "",
            ),
        ))

    for claim_id in find_extra_periods(claims):
        text = claim_text_by_id.get(claim_id, "")
        results.append(CheckItem(
            status="amend",
            message=f"Claim {claim_id} contains extra or misplaced periods.",
            message_key="claims.extraPeriod",
            details=f"Claim {claim_id} has periods in unexpected positions. A claim should contain only one period at the very end per MPEP § 608.01(m).",
            details_key="claims.extraPeriodDetails",
            details_params={"claimNumber": str(claim_id)},
            diagnostics=_dx(
                flagged_claim_id=claim_id,
                period_count=text.count("."),
                claim_text_charlen=len(text),
                total_claims=len(claims),
                preamble=text[:80] if text else "",
            ),
        ))

    for claim_id in detect_incorrect_wherein_commas(claims):
        results.append(CheckItem(
            status="verify",
            message=f"Claim {claim_id}: review comma usage after 'wherein'.",
            message_key="claims.whereinComma",
            details=f"Claim {claim_id} may have incorrect comma placement around a 'wherein' clause. Review punctuation per MPEP § 608.01(m).",
            details_key="claims.whereinCommaDetails",
            details_params={"claimNumber": str(claim_id)},
            diagnostics=_dx(
                flagged_claim_id=claim_id,
                total_claims=len(claims),
                reason_code="wherein_comma_irregular",
                preamble=(claim_text_by_id.get(claim_id, "") or "")[:120],
                wherein_count=claim_text_by_id.get(claim_id, "").lower().count("wherein"),
            ),
        ))

    if not results:
        results.append(CheckItem(
            status="pass",
            message="Claim punctuation is correct.",
            message_key="claims.punctuationPass",
        ))

    return results


_GENERIC_TERMS = {
    "system", "device", "method", "apparatus", "means", "step", "element",
    "member", "portion", "surface", "end", "side", "part",
}

_BOILERPLATE_TERMS = {
    "plurality", "embodiment", "thereof", "herein", "foregoing",
}

# Sliding-window size for spec-support proximity matching (Tier 2 stemmed,
# Tier 3 raw). Hoisted so both tiers share a single constant.
WINDOW_SIZE = 10


# Spec-support phrase hygiene (US, wave B). `only` never ends an element name
# (#944: `the third switch only when ...`), and a mid-phrase `further` is the
# adverb of a predicate the capture ran into (#887: `the instructions further
# cause`); as an adjective it LEADS the noun (`a further layer`).
def _trim_spec_support_predicate_tail(phrase: str) -> str:
    words = phrase.split()
    lowered = [w.lower() for w in words]
    if "further" in lowered[1:]:
        words = words[:lowered.index("further", 1)]
    elif len(words) > 1 and lowered[-1] == "only" and lowered[-2] != "read":
        words = words[:-1]
    return " ".join(words)


_POSITIONAL_PARTITIVE_WORDS = frozenset({
    "last", "preceding", "previous", "next", "subsequent", "succeeding",
    "former", "latter", "remaining", "other", "another", "same",
})
_PARTITIVE_ONE_OF = re.compile(
    r"\s+(?:ones?\s+)?of\s+(?:the|a|an|said|these|those|each)\b"
)


def _is_positional_partitive(phrase_lower: str, body_lower: str) -> bool:
    """`a last one of the plurality of X`: the phrase is only a position."""
    words = phrase_lower.split()
    if words and words[-1] in ("one", "ones"):
        words = words[:-1]
    if not words or not all(w in _POSITIONAL_PARTITIVE_WORDS for w in words):
        return False
    for m in re.finditer(r"\b" + re.escape(phrase_lower) + r"\b", body_lower):
        if _PARTITIVE_ONE_OF.match(body_lower, m.end()):
            return True
    return False


def _stems_within_window(
    phrase_words: list[str],
    phrase_stems: list[str],
    stem_positions: dict[str, list[tuple[int, str]]],
    window_size: int,
) -> bool:
    """Tier 2: every phrase word has an INFLECTION of itself in one window.

    The stem must match and the spec word may differ from the claim word by at
    most two characters (terminal/terminals, detect/detected). Report #880: a
    bare stem match let a `connect terminal` borrow support from `a connection
    unit having an input terminal` (synthetic shape) - connection is a
    different word, not a form of connect, and the term was unsupported.
    """
    lists = []
    for word, stem in zip(phrase_words, phrase_stems):
        hits = [i for i, w in stem_positions.get(stem, ()) if abs(len(w) - len(word)) <= 2]
        if not hits:
            return False
        lists.append(hits)
    # Smallest range holding one position from every list (sorted inputs).
    heap = [(positions[0], k, 0) for k, positions in enumerate(lists)]
    heapq.heapify(heap)
    high = max(positions[0] for positions in lists)
    while True:
        low, k, j = heapq.heappop(heap)
        if high - low < window_size:
            return True
        if j + 1 == len(lists[k]):
            return False
        nxt = lists[k][j + 1]
        high = max(high, nxt)
        heapq.heappush(heap, (nxt, k, j + 1))


def check_spec_support(
    claims: list[Claim],
    spec_text: str,
) -> list[UnsupportedTerm]:
    """Check that claim noun phrases have support in the specification.

    Three-tier matching: exact, stemmed, word-window.

    Per ADR-091 (Option Y), this check no longer suppresses phrases already
    flagged by ``check_antecedent_basis``. Both checks now emit findings
    independently; the pipeline computes a cross-reference set so the
    frontend can render hint lines linking related findings instead of
    silently hiding one branch.
    """
    from patentlint.analysis.utils import extract_noun_phrases

    spec_lower = spec_text.lower()
    spec_words = spec_lower.split()

    # Pre-stem spec words for Tier 2. Order-preserving list (not a set) so
    # the Tier 2 sliding window can enforce proximity rather than checking
    # set membership across the entire spec.
    spec_stems = list(_stemmer.stemWords(spec_words))
    stem_positions: dict[str, list[tuple[int, str]]] = {}
    for idx, (word, stem) in enumerate(zip(spec_words, spec_stems)):
        stem_positions.setdefault(stem, []).append((idx, word))

    unsupported: list[UnsupportedTerm] = []

    for claim in claims:
        # Extract noun phrases from the claim body (skip preamble)
        # Find transition to skip preamble
        tm = _TRANSITIONS.search(claim.text)
        if tm:
            body = claim.text[tm.end():]
        else:
            body = claim.text

        phrases = extract_noun_phrases(body)
        body_lower = body.lower()

        for phrase in phrases:
            phrase = _trim_spec_support_predicate_tail(phrase)
            phrase_lower = phrase.lower()
            if not phrase_lower:
                continue

            # Mirrors of two antecedent-side guards (reports #890, #921/#922):
            # the Markush head `the group consisting of` and a positional
            # partitive (`a last one of the plurality of X`) name no element,
            # so there is nothing for the description to support.
            if phrase_lower == "group" and re.search(
                r"\bgroup\s+(?:consisting\s+of|of)\b", body_lower
            ):
                continue
            if _is_positional_partitive(phrase_lower, body_lower):
                continue

            # Skip generic/boilerplate terms
            if phrase_lower in _GENERIC_TERMS or phrase_lower in _BOILERPLATE_TERMS:
                continue

            # R38 (2026-07-23, report #414): cataphoric leading modifier ("the
            # following steps:") - a reference to the enumerated list, never a
            # written-description-bearing element (mirror of the antecedent-side
            # guard). FN-safe: `following` is never the leading word of a real
            # element name.
            if phrase_lower.split()[0] in _CATAPHORIC_LEADING:
                continue

            # Skip single common words
            if len(phrase_lower.split()) == 1 and phrase_lower in _GENERIC_TERMS:
                continue

            tiers_checked: list[str] = []

            # Tier 1: Exact match
            tiers_checked.append("exact")
            if phrase_lower in spec_lower:
                continue

            # Tier 2: Stemmed sliding window. All phrase stems must appear
            # together inside a single window. Window size grows to fit the
            # phrase if the phrase is longer than WINDOW_SIZE; otherwise the
            # window is fixed at WINDOW_SIZE so multi-word terms whose stems
            # are scattered across the spec are NOT silently matched.
            tiers_checked.append("stemmed")
            phrase_stems = list(_stemmer.stemWords(phrase_lower.split()))
            if phrase_stems:
                window_size = max(len(phrase_stems), WINDOW_SIZE)
                if _stems_within_window(
                    phrase_lower.split(), phrase_stems, stem_positions, window_size
                ):
                    continue

            # Tier 3: Word window (all words appear within WINDOW_SIZE-word window)
            tiers_checked.append("word_window")
            phrase_words = phrase_lower.split()
            if len(phrase_words) >= 2:
                found_window = False
                for i in range(len(spec_words) - len(phrase_words) + 1):
                    window = set(spec_words[i:i + WINDOW_SIZE])
                    if all(w in window for w in phrase_words):
                        found_window = True
                        break
                if found_window:
                    continue

            unsupported.append(UnsupportedTerm(
                claim_number=claim.id,
                phrase=phrase,
                tiers_checked=tiers_checked,
            ))

    return unsupported


def attach_cross_references(
    antecedent_findings: list[dict],
    unsupported_terms: list[UnsupportedTerm],
) -> None:
    """Cross-link antecedent and spec-support findings on the same term.

    Per ADR-091 (Option Y), the spec-support check no longer suppresses
    phrases already flagged by antecedent basis. Instead, when the same
    ``(claim_id, term)`` pair appears in both lists, each finding is
    annotated with a ``cross_ref`` pointing at the sibling check so the
    frontend can render a hint line:

    - ``cross_ref="spec_support"`` on antecedent findings → "Also flagged
      for spec support - see § 112(a) card."
    - ``cross_ref="antecedent"`` on spec-support findings → "Also flagged
      for antecedent basis - see § 112(b) card."

    Mutates both lists in place. Comparison is case-insensitive on the
    bare term.
    """
    ab_pairs: set[tuple[int, str]] = {
        (item["claim_id"], item["term"].lower()) for item in antecedent_findings
    }
    spec_pairs: set[tuple[int, str]] = {
        (ut.claim_number, ut.phrase.lower()) for ut in unsupported_terms
    }

    for item in antecedent_findings:
        if (item["claim_id"], item["term"].lower()) in spec_pairs:
            item["cross_ref"] = "spec_support"

    for ut in unsupported_terms:
        if (ut.claim_number, ut.phrase.lower()) in ab_pairs:
            ut.cross_ref = "antecedent"
