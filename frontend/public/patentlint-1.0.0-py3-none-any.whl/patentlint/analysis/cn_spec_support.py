# SPDX-License-Identifier: LicenseRef-PolyForm-Strict-1.0.0
# Copyright (c) 2025-2026 Christopher Chen
"""CN specification-support analysis (说明书支持分析).

Implements 专利法 §26 第4款 ("权利要求书应当以说明书为依据") and the
corresponding 审查指南 第二部分第二章 §3.2.1 examination guideline.
Mirrors the TW spec-support walker at ``tw_spec_support.py`` (ADR-138)
with three CN-specific adaptations:

  1. **No Tier 0 symbol-table whitelist.** CN drafters do not maintain
     a standalone 符号说明 section (that surface is TIPO-unique); CN
     reference numerals appear inline in 具体实施方式, already inside
     the Tier 1-3 search surface. Dropping the tier simplifies the
     matcher without precision cost.
  2. **Excludes 背景技术 from spec_text.** 审查指南 §2.2.3 defines
     背景技术 as prior-art context, not disclosure of the invention.
     §3.2.1 grounds support in "充分公开的内容" - sufficiently
     disclosed content. A claim term supported *only* by 背景技术 is
     not drafted as disclosed by the inventor; flagging it is the
     correct §26 第4款 behavior.
  3. **Native-CN-drafting-grounded stoplists.** Seeds for conjunctions,
     prepositions, boilerplate, leading-rejects, trailing tokens,
     suffix-only leads, and interior rejects are grounded in 审查指南
     drafting conventions + CN practitioner style rather than
     TW-corpus artifacts.

Emits ``UnsupportedTerm`` findings for each claim noun phrase that fails
all three tiers:

  Tier 1: aggressively-normalized exact substring - claim-side term
    goes through ``_normalize_for_spec_support_cn`` (walker normalizer
    + leading preposition strip 于/到/在/自/由/从/向/对 + both paren
    and bare-numeral ref-numeral strip), then tested as a substring
    of spec_text.
  Tier 2: raw-form exact substring - catches over-normalization cases
    where the drafter's literal claim phrasing appears verbatim in
    the spec.
  Tier 3: CJK character-window fallback - normalized term's bigrams
    must all co-occur within a ±30-char sliding window over spec_text.

Spec_text composition: ``technical_field + summary + detailed_description``.
Excludes ``background`` (prior-art context, not disclosure),
``drawings_description`` (figure captions, FP risk), and ``abstract_text``
(not written-description).

Claim-side inventory hygiene additionally skips terms flagged by the
antecedent walker as ``category: "tw_contamination"`` (该等/该些 residue
from 繁转简 conversion - those are parser-level artifacts, not native
CN terms worth spec-support analysis).
"""

from __future__ import annotations

import collections
import re

from patentlint.analysis.cjk_tokenize import tokenize_cn
from patentlint.analysis.cn_claims import (
    _F10_SINGLE_CHAR_SUFFIXES_CN,
    _INTERIOR_VERB_BOUNDARIES_CN,
    _TRAILING_VERB_DENYLIST_CN,
    extract_introductions_cn,
    normalize_arabic_ordinal_to_cjk,
    normalize_reference_term_cn,
)
from patentlint.models import Claim, CnPatentDocument, UnsupportedTerm

# --- Stoplists -------------------------------------------------------------

# Generic preamble-category nouns too broad to meaningfully check against
# spec text. Exact-match only (walker inventory uses ``final in``). Grounded
# in 审查指南 §3.1.1 canonical genus forms (一种X where X is 方法/装置/系统/
# 设备/手段/步骤) + 技术方案 (the generic term 审查指南 uses throughout for
# "the claimed invention"). Deliberately excludes 元件/组件/构件/部分/表面/
# 部位/侧/面/结构 - these form legitimate compound terms (开口部, 底部,
# 第一表面, 连接结构) per TW audit #2 lesson.
_CN_GENERIC_TERMS: frozenset[str] = frozenset({
    "系统",
    "装置",
    "方法",
    "设备",
    "手段",
    "步骤",
    "技术方案",
    # 单元 is bare-genus in CN drafting (drafters write 处理单元 / 存储单元
    # as compounds). Bare 单元 in inventory is walker stranding from
    # patterns like 单元在第二X / 单元能够X - after interior reject + verb
    # strip, the residue lands as bare 单元, which we reject here as too
    # broad to meaningfully spec-check (CN115485995B).
    "单元",
})

# Boilerplate fragments / back-reference residues that should never flow
# into the spec-support inventory. Checked both as exact match
# (``final in _CN_BOILERPLATE_TERMS``) and as a prefix
# (``final.startswith(phrase)``) so walker captures like
# 根据权利要求4至权利要求10 are also filtered.
#
# Excluded deliberately:
#   - 所述 / 其中 - these are reference particles, not standalone noun
#     phrases; walker should never emit them bare, and including here
#     would mask a walker bug.
_CN_BOILERPLATE_TERMS: frozenset[str] = frozenset({
    # CN plural quantifiers (若干 / 一些 are CN-only; TIPO drafters don't
    # use them). Walker should strip via strip_leading_quantifier_cn, but
    # defense-in-depth against leakage.
    "多个",
    "若干",
    "一些",
    "数个",
    "复数",
    "复数个",
    "两个",
    "三个",
    # Anaphoric markers (parallel to TW 前述/上述/如上所述).
    "前述",
    "上述",
    "如上所述",
    # CN claim-reference prefixes (parallel to TW 如请求项).
    # Bare 权利要求 catches walker leakage where 如/根据 was stripped
    # upstream - appears in 5+ publication fixtures (CN112271269B,
    # CN114357105B, CN115485995B, CN117427144B, CN120266060A).
    "如权利要求",
    "根据权利要求",
    "权利要求",
    # Walker over-strip of 非瞬时性 (non-transitory) - drops 时性 leaving
    # bare 非瞬 (CN115952274B). Length-2 fragment, never a real term.
    "非瞬",
    # R67 (2026-05-08) - method-claim listing boilerplate. Universal
    # "the following <X>" pattern. CN parity with TW filter.
    "下列步骤",
    "下列方法",
    "下列特征",
    "以下步骤",
    "以下方法",
})

# Trailing clause tokens from native-CN drafting conventions. Applied
# iteratively (longest-first) after the walker normalizer. Grounded in
# CN practitioner verbal habits per 审查指南 §3.3 claim-drafting
# conventions + 专利代理人 training materials.
#
# Rationale by token family:
#   - Spatial suffixes (之间/之上/之下/之内/之外): CN drafters strand
#     these when walker captures positional clauses like
#     "X之间设置有Y" → capture lands as "X之间".
#   - Locative copulas (位于/设于/置于/处于): "X位于Y" stranding.
#   - Action-verb residues (构成/组成/形成): "由X构成Y" strand-shape.
#   - Relational pair predicates (相连/相接/相对/相邻): CN claim idiom.
#   - Comparison verbs (超过/介于/大于/小于/等于): direct TW parallel
#     plus CN-specific comparisons.
#   - Generic stranding (时/设置/配置): direct TW parallel (TW 時 → 时;
#     TW 設 → 设置/配置 since CN uses the longer compound).
_CN_SPEC_SUPPORT_TRAILING_TOKENS: tuple[str, ...] = tuple(sorted(
    (
        # Spatial
        "之间", "之上", "之下", "之内", "之外",
        # 2026-06-29 cross-jurisdiction parity with TW spec-support
        # (TW reports #302/#303 added 電性): 电性 is the bound morpheme
        # leading the verb phrase 电性连接 ("electrically connect") /
        # 电性耦接; the walker stops at 电性 before the excluded 连
        # (导电胶体电性 → 导电胶体). Never a noun terminus in CNIPA
        # drafting - conductivity is 导电性 (导电+性), not bare 电性.
        # Generalizing now (no CN report yet; zero CN corpus findings
        # contain 电性, so additive-only) per the standing CN↔TW mirror.
        "电性",
        # Locative copulas
        "位于", "设于", "置于", "处于",
        # Action verbs (manufacturing / construction)
        "构成", "组成", "形成", "制造",
        # Relational pairs
        "相连", "相接", "相对", "相邻",
        # 2026-06-01 batch - adapter / fastener drafter spec-support
        # over-captures: trailing 抵靠 (abut), 穿设 (set-through),
        # 分别穿过 (respectively pass-through). All verb-phrase tails
        # never noun-phrase termini in CNIPA drafting.
        "抵靠", "穿设", "穿過", "分别穿过",
        # Comparison
        "超过", "介于", "大于", "小于", "等于",
        # Generic verbal residues. 配 catches 避让组件配 (CN213655447U)
        # where walker truncated 配置.
        "设置", "配置", "配",
        "时",
        # R67 (2026-05-08): walker over-capture truncated at preposition
        # `以`. Drafter wrote `一基板以及一岛状...`, walker capture spanned
        # `包含一基板以及一岛状` (post-process produced multiple candidates
        # one of which terminated mid-conjunction). Bare `以` trailing
        # is always a truncated preposition - `以` is never the terminus
        # of a legitimate compound noun.
        "以及",
        "以",
        # R67: parity with TW _TW_SPEC_SUPPORT_TRAILING_TOKENS additions.
        # `第` alone at term end = truncated ordinal prefix.
        "的第",
        "第",
        # 2026-05-21: parity mirror of the TW #77/#69 spec-support fix.
        # `各` - distributive quantifier ("each"), never a noun terminus;
        # `减薄` - process verb ("thin / reduce"), a predicate fragment.
        "减薄",
        "各",
        # 2026-06-09 batch (USB-hub / display auto-config CN drafter, report
        # queue #228/#232/#233). `至该` ("to the …") is the goal-preposition
        # + demonstrative tail of `发送<X>指令至该显示器` clauses, captured
        # whole as `查询指令至该` / `启动指令至该` / `窗口指定指令至该`. Never a
        # noun-phrase terminus - strips to the clean head `<X>指令`. 2-char
        # so it can't fire mid-noun (夏至/冬至 end in 至, not 至该). Already
        # present as a LEADING reject; the trailing form is the new arm.
        "至该",
    ),
    key=len,
    reverse=True,
))

# Leading verbal / clause-fragment prefixes. CN drafters use existential
# verbs (设有/装有/备有/配置有/设置有) heavily for "is provided" /
# "comprises" - pattern `在所述X上设置有Y` is canonical per 审查指南
# §3.3 examples. Walker capture strand-shapes land at capture *start*;
# stripping at leading-reject layer prevents inventory pollution.
#
# TW has nothing analogous because TIPO drafting prefers 具有/包含 over
# existential 設有 constructions. Multi-char sequences only - single-char
# leads can't be blanket-rejected without FN risk on compound nouns.
_CN_SPEC_SUPPORT_LEADING_REJECTS: tuple[str, ...] = (
    # CN existential-verb prefixes (审查指南 §3.3 drafting conventions)
    "装设有",
    "配置有",
    "设置有",
    "安装有",
    "存储有",
    "形成有",
    "设有",
    "装有",
    "备有",
    # Relational (noun dropped, prep+ref stranded)
    "对该",
    "至该",
    "向该",
    "与该",
    # Verbal prefixes (CN claim-drafting idioms)
    "用以",
    "用于",
    "能够",
    "以使",
    "以控",
    "以从",
    # 2026-06-09 batch (#228/#234): leading `以<verb>` purpose-clause
    # connectors ("in order to <verb>"). `以取得处于实体连接状态的…` (#228)
    # and `以通过该传输接口发送…` (#234) are verb clauses captured at the
    # start, never noun phrases. Same 2-char `以<verb>` shape as 以使/以控/
    # 以从. Safe vs nouns: 以太网 (Ethernet) starts 以太, 以下步骤 starts
    # 以下 - neither matches 以取/以通.
    "以取",
    # R60 (2026-08-10) - TW R37 #510 mirror. `配置以切换多个所述灯具` captures
    # 以切换多个: the 以-purpose connective plus the head of the following verb,
    # with no noun in the span. Same 2-char `以<verb>` shape as 以使 / 以控,
    # which CN carries in BOTH the leading and interior sets - 以切 joins both
    # for parity. Safe on the same argument: 以太网 (Ethernet) opens 以太, and
    # 切换器 / 切换单元 as element heads do not open with 以.
    "以切",
    "以通",
    # Direct parallels to TW audit tokens
    "有多",
    "有一",
    "有可",  # 有可被X (CN115952274B)
    "有计",  # 有计算机指令 (CN115952274B)
    "显示",
    "描述",
    # Walker fragment from 如权利要求N项所述 - `项所` strands when 述
    # gets cut by interior boundary detection (CN114357105B claim 6).
    "项所",
    # 2026-05-21: parity mirror of TW #78 - `中一` is a stranded
    # `其中一(个)` connective fragment (walker dropped the leading 其).
    "中一",
    # CN R71 (#879) - the same fragment from 其中之一 / 其中另一, and the
    # parity mirror of TW `中兩` (#194). None of 中之 / 中另 / 中两 opens a noun.
    "中之", "中另", "中两",
    # 2026-05-29 - issue #145. Drafter claim 10 preamble
    # `一种用于折叠支撑脚组件的折叠支撑脚` had `种用` over-captured: walker
    # strips the leading `一` quantifier and lands on `种` (kind), then
    # extends through `用` (used) before the `于` boundary cuts the
    # capture. `一种用于X的Y` is the universal CN preamble form per
    # 审查指南 §3.1.1; `种用` is never a real noun head. Multi-char so
    # no FN risk on `种类` / `品种` legitimate compounds.
    "种用",
)

# Characters that appear ONLY as noun suffixes in CN patent diction
# (开口部, 顶端). When one appears at position 0 of a normalized term,
# the walker captured a fragment starting mid-compound. Reject these
# single-char leads. Dropped TW's 埠 - TIPO-specific for USB-shaped Latin
# loanwords; CN uses 口 which has too many legitimate compound uses
# (开口, 出口) to blanket-reject.
_CN_SUFFIX_ONLY_LEADS: frozenset[str] = frozenset({"部", "端"})

# Structural interior markers - substrings that, if present anywhere in
# a captured term, indicate it's a clause / verb-phrase / boilerplate
# fragment, not a noun phrase. Comprehensive list grounded in CN claim-
# drafting conventions (审查指南 §3) plus walker-fragment audit across the
# 10 CN publication fixtures. Each entry has near-zero FN risk on
# legitimate compound nouns: these are particles, modal/auxiliary verbs,
# manner adverbs, locative+ordinal phrases, and passive-marker
# constructions that don't appear in real claim-element names.
_CN_SPEC_SUPPORT_INTERIOR_REJECTS: tuple[str, ...] = (
    # Comparison clauses (TW parallel)
    "超过",
    "超出",
    "彼此",
    # Claim reference particles - 权利要求 anywhere in a captured term is
    # walker meta-reference leakage (e.g., "通信设备执行如权利要求",
    # "采用如权利要求1-9中任", "介质所在设备执行权利要求"). Affects 4+
    # fixtures (CN115485995B, CN112271269B, CN116662522B, CN114357105B).
    "权利要求",
    # Modal / auxiliary verbs
    "能够",
    # Adverbs (manner, sequence, intensity)
    "进一步",
    "依次",
    "相向地",
    "相背地",
    "相对地",
    # Purposive verb phrases
    "用于",
    "以使",
    "以控",
    # R60 (2026-08-10) - TW R37 #510 mirror. `配置以切换多个所述灯具` captures
    # 以切换多个: the 以-purpose connective plus the head of the following
    # verb, with no noun in the span. Same 2-char `以<verb>` shape as
    # 以使 / 以控 above, and safe on the same argument - 以太网 (Ethernet)
    # opens 以太, and 切换器 / 切换单元 as element heads do not open with 以.
    # Reproduced on the CN normalizer before shipping, not assumed.
    "以切",
    # Locative + ordinal - CN drafters write "在第二起始时刻" etc.
    "在第",
    # Genus + preposition stranding - walker capture lands on bare-genus
    # plus stranded 在 (CN115485995B `单元在`). Each pattern catches the
    # walker artifact without affecting compound nouns.
    "单元在",
    "装置在",
    "组件在",
    # Preposition phrases (sequential / proximal)
    "沿远离",
    "沿靠近",
    # Passive-marker constructions - `被进一步`, `被进行`, `被执行`. Bare
    # `被` excluded: too common in legitimate compound nouns
    # (e.g., 被覆层 / 被加热部).
    "被进",
    "被执行",
    # 2026-05-21: parity mirror of TW #76 - a coupling/connection verb
    # taking an indefinite object (`<verb>一<NOUN>`) is a relational
    # predicate, never a noun's name. Gated on `一` so real noun
    # compounds (连接器 / 耦合器, no `一`) stay inventoried.
    "耦接一",
    "耦合一",
    "连接一",
    # 2026-06-01 (issue #177): possession verb taking an indefinite object
    # - `<noun>具有一<noun>` ("X has a Y") is a predication, never the
    # name of a noun. Spec-support inventory walker captured the entire
    # span `间具有一锐角` (`间` locative + `具有一` possession + `锐角`)
    # as a duplicate intro alongside the clean `锐角`. The clean form
    # already inventoried; this rejects the duplicate. Gated on `一` so
    # genuine compounds with `具有` at PREFIX (e.g. `具有性`) stay safe.
    "具有一",
)

# Leading prepositions that survive walker normalization. Strip these
# claim-side before the Tier 1 exact check. Spec-side text is unchanged.
# TW's 於/到/在/自/由 direct-converted, plus CN-specific 从/向/对 (CN
# drafters use 从所述X frequently where TW uses 自; 向所述 and 对所述
# are CN-native prepositions absent from TW practice).
# 作为 ("as") is the coverb of 其中另一作为X; CN R71 (#879), mirror of TW R65.
_CN_LEADING_PREPOSITIONS: tuple[str, ...] = ("作为", "于", "到", "在", "自", "由", "从", "向", "对")
# Words that open with one of those prepositions (从动带轮, 对象, 向量, 自由端).
# A census over the CN corpus intros found each heading real terms (自动 64,
# 从动 60, 对象 58, 自由 27, 对接 17, 向量 15, 在线 15); the strip cut them to
# 动带轮 / 象 / 量. Mirror of the TW guard (wave C).
_CN_PREPOSITION_WORD_HEADS: tuple[str, ...] = (
    "自动", "自由", "自主", "自身", "自适应", "自锁", "从动", "从属",
    "对象", "对应", "对接", "向量", "在线",
)

# Reference numerals per 专利法实施细则 §21 - drafters inline element
# numerals like 底座(10). NON-ANCHORED to handle:
#   (a) Trailing parens (底座(10) → 底座)
#   (b) Interior parens when walker capture has trailing text
#       (屏幕支撑组件(100)的Y → 屏幕支撑组件 after 的Y also strips)
#   (c) Walker-truncated unbalanced parens (屏幕支撑组件(100 → 屏幕支撑组件)
# Restricted inside-content to ASCII alnum + dashes - never CJK - so we
# don't accidentally strip parenthesized noun phrases like (展开状态).
_PAREN_REF_NUMERAL_RE = re.compile(r"[（(]\s*[A-Za-z0-9\-—–]+\s*[）)]?")

# Bare-numeral reference per CN-specific drafting. CN drafters sometimes
# write 底座10 without parentheses (vs. TW's universal parenthesization
# per 施行细则 §19). NON-ANCHORED - strips numerals after any CJK char
# that isn't 第 (lookbehind gates against ordinals 第一/第二). Handles
# both trailing (底座10 → 底座) and interior (底座10的位置 → 底座的位置).
# Also handles bibliographic chemistry ranges 碳数～20 / X~30 by stripping
# optional [～~-] separators between the CJK char and digit run
# (CN120266060A claim 1).
_BARE_REF_NUMERAL_CN_RE = re.compile(
    r"(?<=[一-鿿])[～~\-—–]?(?<!第)\d+[a-zA-Z'′]?"
)

# Coordinating conjunctions. TW's 以及/及/與/和 direct-converted (與 → 与,
# Simplified) plus 或. CN claims use `包括A或B` (disjunctive alternative)
# more often than TW; both A and B should enter the inventory because
# both are within claim scope. TW audit didn't surface 或-split because
# TIPO drafters prefer the word 或者 which is distinct.
_CN_CONJUNCTIONS: tuple[str, ...] = ("以及", "及", "和", "与", "或")
# #350 parity - bare quantifiers that, on the right of a conjunction with no
# noun after them, mark a walker-over-captured clause boundary (X 及 一个).
_CN_BARE_QUANTIFIERS: frozenset[str] = frozenset({
    "一", "一个", "一种", "两", "二", "两个", "多个", "若干", "各", "至少一",
})

# Sliding-window size (in CJK characters) for Tier 3 proximity matching.
# Same ±30-char width as TW - Chinese noun phrases are 2-4 chars; ±30
# spans ~5-8 clauses of context, matching the granularity at which a
# drafter would declare support for a compound term.
_CHAR_WINDOW_SIZE: int = 30

# Minimum bare-noun length for a term to enter the inventory. Filters
# single-char residues.
_MIN_INVENTORY_LENGTH: int = 2

# R60 (2026-08-10) - TW R37 #508 / #511 mirror: interior TRANSFER COVERB +
# determiner. `输出一第二电能至一耗电负载` captured 第二电能至一耗电负载 and
# `提供一第一电能给一永磁马达` captured 第一电能给一永磁马达 - the coverb marks
# the recipient, so a second complete noun phrase got glued onto the theme
# noun. Both recipients are separately inventoried from their own intro, so
# the cut loses no coverage. Verified to reproduce on the CN normalizer with
# the same draft family that produced the TW reports.
#
# Gate is POSITIONAL, not lexical (the R41 -ward lesson): the coverb cuts only
# when a DETERMINER follows, which is what opens a new noun phrase. In
# compound position it is followed by its own head (补给站, 冬至日) and nothing
# is cut.
_CN_INTERIOR_COVERBS: tuple[str, ...] = ("至", "给")
_CN_COVERB_DETERMINERS: tuple[str, ...] = ("一", "所述", "该")

# R60 (2026-08-10) - TW R37 #509 mirror: INLINE element numerals on the SPEC
# side. 专利法实施细则 §21 practice puts 元件符号 inline in the description
# (`联轴器4的两端分别连接永磁同步电机2A`), which breaks both the exact-substring
# tiers and the Tier-3 bigrams for a claim phrase written without the numeral.
# The CN claim side already strips a trailing bare numeral
# (``_BARE_REF_NUMERAL_CN_RE``); the spec side stripped nothing, so the
# asymmetry was invisible until a drafter used the inline notation.
#
# Gated on a following STRUCTURAL character so the strip cannot JOIN two
# adjacent annotated element names (`电机2固定座3` -> `电机固定座` would
# manufacture support for a compound the spec never describes - a real
# 专利法 §26(4) false negative). Additive fallback tier only.
_CN_SPEC_INLINE_REF_NUMERAL_RE = re.compile(
    r"(?<=[\u4e00-\u9fff])\d+[A-Za-z]?"
    r"(?=[\u7684\u4e4b\u4e0e\u53ca\u548c\u3001\uff0c\u3002\uff1b\uff1a\uff09)\s]|$)"
)


def _cut_at_interior_coverb_cn(term: str) -> str:
    """Truncate at an interior transfer coverb (至 / 给) that opens a new NP."""
    for idx, ch in enumerate(term):
        if ch not in _CN_INTERIOR_COVERBS or idx < _MIN_INVENTORY_LENGTH:
            continue
        if any(term[idx + 1:].startswith(d) for d in _CN_COVERB_DETERMINERS):
            return term[:idx]
    return term


def _strip_inline_ref_numerals_cn(spec_text: str) -> str:
    """Drop inline 元件符号 from CN spec text (联轴器4的两端 -> 联轴器的两端)."""
    return _CN_SPEC_INLINE_REF_NUMERAL_RE.sub("", spec_text)

# Maximum length (chars) for an inventory term. Captures beyond this
# length are almost always walker clause artifacts rather than genuine
# compound nouns. 10 chars is ~3-5 Chinese morphemes - long enough for
# legitimate compound terms and short enough to reject full clauses.
# CN tightened from TW's 12 because publication-fixture audit showed
# 9-12-char clause leakage (法律知识领域中的知识内容 = 11,
# 介质所在设备执行权利要求 = 12 - CN116662522B).
_MAX_INVENTORY_LENGTH: int = 10


# --- Normalization helpers -------------------------------------------------


def _normalize_for_spec_support_cn(
    text: str,
    *,
    strict_qualifier_matching: bool = False,
) -> str:
    """Normalize a claim-side term for CN spec-support matching.

    Order:
        1. Strip trailing parenthetical reference numeral 专利法实施细则 §21
           (底座(10) → 底座).
        2. Strip trailing bare reference numeral (底座10 → 底座) -
           CN-specific; TW doesn't need this because TIPO drafters
           universally parenthesize per 施行细则 §19.
        3. Strip leading preposition (于/到/在/自/由/从/向/对).
        4. Run the walker normalizer (strip_reference_form_prefix_cn +
           strip_leading_qualifier_cn + clean_noun_phrase_cn +
           strip_leading_quantifier_cn).
        5. Mid-phrase reference-prefix recovery (catches stranded
           该/所述/前述 at interior positions).
        6. Trailing conjunction strip (顔色与 → 顔色).
        7. Trailing CN-drafting-specific token strip (iterative,
           longest-first).
        8. Re-strip trailing numerals exposed by the verb strip.

    Spec-side text is NOT normalized - the match is asymmetric, so
    "使用者界面" (claim) matches both "使用者界面" (bare) and
    "所述使用者界面" (prefixed) in the spec.
    """
    if not text:
        return text
    t = _PAREN_REF_NUMERAL_RE.sub("", text).strip()
    t = _BARE_REF_NUMERAL_CN_RE.sub("", t).strip()
    for prep in _CN_LEADING_PREPOSITIONS:
        if t.startswith(_CN_PREPOSITION_WORD_HEADS):
            break
        if t.startswith(prep) and len(t) > len(prep):
            t = t[len(prep):]
            break
    t = normalize_reference_term_cn(
        t,
        strict_qualifier_matching=strict_qualifier_matching,
    )
    t = _recover_from_midphrase_prefix_cn(
        t,
        strict_qualifier_matching=strict_qualifier_matching,
    )
    t = _strip_trailing_conjunction_cn(t)
    # Before the token strip, which takes the 于 off 等于 and strands 等.
    t = _strip_comparison_verb_cn(t)
    t = _strip_spec_support_trailing_tokens_cn(t)
    # #321 parity - re-run the conjunction strip after the token strip: a token
    # strip can remove an intervening predicate/preposition and re-expose a
    # dangling coordinating conjunction (基部及位于 → 基部及 → 基部).
    t = _strip_trailing_conjunction_cn(t)
    # Re-strip trailing numerals exposed by the verb strip.
    t = _PAREN_REF_NUMERAL_RE.sub("", t).strip()
    t = _BARE_REF_NUMERAL_CN_RE.sub("", t).strip()
    # R60 - interior transfer coverb, last so it runs on the stripped head.
    t = _cut_at_interior_coverb_cn(t)
    # A comparison verb is the predicate on the element before it (阈值等于,
    # 浓度高于): keep the element.
    return _strip_comparison_verb_cn(t)


def _strip_spec_support_trailing_tokens_cn(term: str) -> str:
    """Iteratively strip trailing CN clause tokens (longest-first)."""
    for _ in range(8):
        stripped = False
        for token in _CN_SPEC_SUPPORT_TRAILING_TOKENS:
            if term.endswith(token) and len(term) > len(token):
                term = term[: -len(token)]
                stripped = True
                break
        if not stripped:
            break
    return term


def _has_leading_reject_cn(term: str) -> bool:
    """True if the term starts with a known verbal/clause-fragment prefix."""
    if not term:
        return False
    if term[0] in _CN_SUFFIX_ONLY_LEADS:
        return True
    return any(term.startswith(p) for p in _CN_SPEC_SUPPORT_LEADING_REJECTS)


def _has_interior_reject_cn(term: str) -> bool:
    """True if the term contains a structural interior marker.

    See ``_CN_SPEC_SUPPORT_INTERIOR_REJECTS`` for the full marker
    catalog: comparison clauses, claim-reference particles, modals,
    manner/sequence adverbs, purposive phrases, locative+ordinal,
    preposition phrases, and passive-marker constructions.
    """
    return any(marker in term for marker in _CN_SPEC_SUPPORT_INTERIOR_REJECTS)


# R65 (2026-09-01) - LEXEME-GATED LEADING 并, the CN half of TW R52.
# `_CN_CONJUNCTIONS` models coordinating conjunctions but holds only
# ("以及", "及", "和", "与", "或") - 并且 was never a member, so three of the
# five documented Engine-2 quality residuals (并且在 / 并且当 / 并且-) opened
# with a clause connective and were inventoried as element names.
#
# Bare 并 cannot be cut for the same reason bare 並 cannot on TW: 并联 occurs
# 81x. Measured on the CN corpus, 并 + next character: 并且 4,328 · 并将 167 ·
# 并在 125 · 并与 103 · 并通 81 · 并联 81 · 并入 64 … everything frequent
# except 并联 / 并列 / 并排 / 并行 is 并 + a VERB.
#
# Kept as its own predicate rather than added to `_CN_CONJUNCTIONS`, because
# that tuple is also consumed by `_split_on_conjunction_cn` and
# `_strip_trailing_conjunction_cn`, where a new member would silently change
# splitting behaviour. ENGINE 2 ONLY, same as the TW half.
_CN_CONJ_NOUN_LEXEMES: tuple[str, ...] = (
    "\u5e76\u8054", "\u5e76\u5217", "\u5e76\u6392", "\u5e76\u884c",
)


def _has_leading_conj_bing_cn(term: str) -> bool:
    """True when the term opens with the connective 并 rather than a 并-noun."""
    if not term.startswith("\u5e76") or len(term) < 3:
        return False
    return not term.startswith(_CN_CONJ_NOUN_LEXEMES)


def _has_leading_conjunction_cn(term: str) -> bool:
    """True if the term starts with a CN conjunction.

    Walker-capture artifact: when claim text uses `X或Y`, `X与Y`, `X和Y`,
    walker may strand `或所述`, `与所述`, `和X` as the entire intro. These
    are clause-fragments, not noun phrases. Affects CN115485995B
    (`或所述`), CN115952274B (`与所述`).

    Multi-char conjunctions checked first (以及 before 及).
    """
    for conj in sorted(_CN_CONJUNCTIONS, key=len, reverse=True):
        if term.startswith(conj) and len(term) > len(conj):
            return True
    return False


def _is_boilerplate_cn(term: str) -> bool:
    """True if term matches a boilerplate phrase exactly or as a prefix."""
    if term in _CN_BOILERPLATE_TERMS:
        return True
    return any(term.startswith(phrase) for phrase in _CN_BOILERPLATE_TERMS)


def _recover_from_midphrase_prefix_cn(
    term: str,
    *,
    strict_qualifier_matching: bool = False,
) -> str:
    """Recover a clean noun from a walker-captured phrase with stranded
    reference-form prefix in the middle.

    CN equivalent of TW's ``_recover_from_midphrase_prefix``. Splits at
    the LAST occurrence of 前述/所述/该 and takes the suffix (the noun
    being referenced). Position 0 matches are ignored (already handled
    upstream by ``strip_reference_form_prefix_cn``).
    """
    for prefix in ("前述", "所述", "该"):
        idx = term.rfind(prefix)
        if idx > 0:
            suffix = term[idx + len(prefix):].strip()
            if suffix and len(suffix) >= _MIN_INVENTORY_LENGTH:
                return normalize_reference_term_cn(
                    suffix,
                    strict_qualifier_matching=strict_qualifier_matching,
                )
    return term


def _strip_trailing_conjunction_cn(term: str) -> str:
    """Strip a dangling trailing conjunction (X及, X和, X与, X或)."""
    for conj in _CN_CONJUNCTIONS:
        if term.endswith(conj) and len(term) > len(conj):
            return term[:-len(conj)]
    return term


def _split_on_conjunction_cn(
    term: str,
    *,
    strict_qualifier_matching: bool = False,
) -> list[str]:
    """Split a walker-captured conjunction phrase into constituent nouns.

    When a normalized intro spans ``X <conj> Y``, returns [X, Y]. Both
    sides must be ≥ ``_MIN_INVENTORY_LENGTH`` chars - protects compound
    nouns that happen to contain 及/和/与 as morphemes (rare in CN
    patent diction but possible).
    """
    for conj in _CN_CONJUNCTIONS:
        idx = term.find(conj)
        if idx < 0:
            continue
        left = term[:idx].strip()
        raw_right = term[idx + len(conj):].strip()
        # Right side may carry a leading quantifier the walker preserved
        # because it started mid-phrase. Re-normalize.
        right = (
            normalize_reference_term_cn(
                raw_right,
                strict_qualifier_matching=strict_qualifier_matching,
            )
            if raw_right
            else raw_right
        )
        if len(left) >= _MIN_INVENTORY_LENGTH and len(right) >= _MIN_INVENTORY_LENGTH:
            return (
                _split_on_conjunction_cn(
                    left,
                    strict_qualifier_matching=strict_qualifier_matching,
                )
                + _split_on_conjunction_cn(
                    right,
                    strict_qualifier_matching=strict_qualifier_matching,
                )
            )
        # #350 parity - stranded leading-quantifier tail (X及一个): keep the left
        # noun, drop the tail. Gated on an EXACT bare-quantifier set (not a
        # blanket right<MIN test) so a short non-quantifier residue (基板及A)
        # stays whole.
        if len(left) >= _MIN_INVENTORY_LENGTH and raw_right in _CN_BARE_QUANTIFIERS:
            return _split_on_conjunction_cn(
                left,
                strict_qualifier_matching=strict_qualifier_matching,
            )
    return [term]


def _collect_spec_text_cn(doc: CnPatentDocument) -> str:
    """Concatenate the body subsections used for CN spec-support matching.

    Includes: technical_field + summary + detailed_description.
    Excludes: background (审查指南 §2.2.3 - prior-art context, not
    disclosure of the invention; a claim term supported only by
    背景技术 is itself a §26 第4款 violation), drawings_description
    (figure captions, FP risk), abstract_text (not written-description).

    R67 (2026-05-08) - Arabic→CJK ordinal normalization applied so the
    Tier 1 / Tier 3 substring checks see the same ordinal form the
    claim-side normalize chain produces. Without this, drafter's
    `第1间隔件` in spec body misses against claim's normalized
    `第一间隔件`. Symmetric to R63 walker fix on the supplementary
    intro path.
    """
    parts: list[str] = []
    parts.extend(doc.technical_field)
    parts.extend(doc.summary)
    parts.extend(doc.detailed_description)
    return normalize_arabic_ordinal_to_cjk("\n".join(parts))


# Mirrors of the TW wave C inventory rules; see tw_spec_support for the
# reasoning behind each.
_BACK_REFERENCE_PREFIXES_CN: tuple[str, ...] = ("所述", "前述", "上述", "该")
_QUANTIFIER_OPENERS_CN: tuple[str, ...] = ("至少", "一", "多", "数", "两")
_MARKUSH_GROUP_CN_RE = re.compile(r"(?:所|由)?组成[之的]群组")
_YI_WORD_LEADS_CN: frozenset[str] = frozenset("第唯同统单进万均逐专划整归十百千")
_YI_CHEMICAL_HEADS_CN: tuple[str, ...] = ("水合", "氧化", "价")
_LATIN_TERM_CN_RE = re.compile(r"[A-Za-z][A-Za-z0-9 .\-/+]*")


# What a split quantifier leaves on a back-reference (所述一或多種X -> 種X).
_MEASURE_RESIDUE_CN_RE = re.compile(r"^(?:或多[种个条]|或更多[种个条]|[种个条])")


# Reference-confirmed terms: mirror of the TW pass (wave C); see
# tw_spec_support._confirm_against_references_tw for the reasoning.
_BOUNDED_REFERENCE_CN_RE = re.compile(
    r"(?:所述|前述|该)((?:(?!所述|前述|该)[\u4e00-\u9fffA-Za-z0-9]){2,16}?)"
    r"(?=[，。；：、,.;:（(的之与及和或\s]|$)"
)
_BARE_ORDINAL_CN_RE = re.compile(r"第[一二三四五六七八九十百\d]+")
_PREDICATE_OPENING_CHARS_CN: frozenset[str] = frozenset(
    "更具做将以使于在并且而也均皆已才则即被从往给把让令呈"
)
_FORMATION_VERBS_CN: frozenset[str] = frozenset({"成型", "成形", "形成", "构成", "而成"})
_PREDICATE_VERBS_CN: tuple[str, ...] = tuple(sorted(
    {v for v in tuple(_INTERIOR_VERB_BOUNDARIES_CN) + tuple(_TRAILING_VERB_DENYLIST_CN)
     if len(v) >= 2} | {"使用"},
    key=len, reverse=True,
))


def _opens_predicate_cn(rest: str) -> bool:
    # 發送定時有關的資訊: the element is the head after 的, and the front is
    # its relative clause, so the run-on reading does not apply.
    if re.search(r"[的之].", rest):
        return False
    for verb in _PREDICATE_VERBS_CN:
        if rest.startswith(verb):
            tail = rest[len(verb):]
            if tail and tail[0] in _F10_SINGLE_CHAR_SUFFIXES_CN:
                return False
            if (len(tail) in (2, 3) and not set(tail) & _PREDICATE_OPENING_CHARS_CN
                    and tail not in _PREDICATE_VERBS_CN
                    and tail not in _FORMATION_VERBS_CN):
                return False
            return True
    return rest[0] in _PREDICATE_OPENING_CHARS_CN


def _confirm_against_references_cn(
    inventory: list[tuple[int, str]], claims: list[Claim]
) -> list[tuple[int, str]]:
    refs: set[str] = set()
    for claim in claims:
        for m in _BOUNDED_REFERENCE_CN_RE.finditer(claim.text):
            # 如請求項1所述的X: that 所述 closes the preamble, it is no reference.
            if not m.group(1).startswith("的"):
                refs.add(m.group(1))
    head_counts = collections.Counter(t[-1] for t in refs if len(t) >= 2)
    out: list[tuple[int, str]] = []
    seen: set[str] = set()
    for cid, term in inventory:
        last = term[-1]
        ends_as_noun = last not in _PREDICATE_OPENING_CHARS_CN and (
            last in _F10_SINGLE_CHAR_SUFFIXES_CN or head_counts[last] >= 2
        )
        if term not in refs and not ends_as_noun:
            heads = [
                r for r in refs
                if len(r) >= _MIN_INVENTORY_LENGTH and len(r) < len(term)
                and term.startswith(r) and not _BARE_ORDINAL_CN_RE.fullmatch(r)
                and _opens_predicate_cn(term[len(r):])
            ]
            if heads:
                term = max(heads, key=len)
        if term not in seen:
            seen.add(term)
            out.append((cid, term))
    return out


def _is_quantified_back_reference_cn(orig: str, norm: str, claim_text: str) -> bool:
    """所述至少一X: a reference the quantifier arm registered as an intro."""
    if (orig == norm or not orig.startswith(_QUANTIFIER_OPENERS_CN)
            or not 0 < orig.find(norm) <= 4):
        return False
    # Test the quantified noun itself, not the recorded span: the extractor
    # can record a later 所述兩X內 while the first mention 包括兩X, is the
    # real introduction.
    quantified = orig[: orig.find(norm) + len(norm)]
    start = claim_text.find(quantified)
    if start < 0:
        return False
    while start >= 0:
        if not claim_text[:start].endswith(_BACK_REFERENCE_PREFIXES_CN):
            return False
        start = claim_text.find(quantified, start + 1)
    return True


def _spans_two_introductions_cn(term: str, claim_norms: set[str]) -> bool:
    """侧板延展形成一凸缘: a clause running into a second introduced element."""
    for i in range(2, len(term) - 1):
        if term[i] != "一" or term[i - 1] in _YI_WORD_LEADS_CN:
            continue
        rest = term[i + 1:]
        if term[i - 2:i] == "分之" or rest.startswith(_YI_CHEMICAL_HEADS_CN):
            continue
        if any(len(n) >= 2 and n != term and (n.startswith(rest) or rest.startswith(n))
               for n in claim_norms):
            return True
    return False


def _is_parenthetical_gloss_cn(term: str, claim_text: str) -> bool:
    """A Latin gloss of the CJK name before it: 同步信号(Sync)."""
    if not _LATIN_TERM_CN_RE.fullmatch(term):
        return False
    return re.search(
        r"[\u4e00-\u9fff][（(]" + re.escape(term) + r"[)）]", claim_text
    ) is not None


_CN_COMPARISON_VERBS: tuple[str, ...] = (
    "大于或等于", "小于或等于", "大于", "小于", "等于", "高于", "低于",
    "多于", "少于", "优于", "差于",
)


def _strip_stranded_comparison_cn(term: str, claim_text: str) -> str:
    """The CN noun capture stops at 于, so 阈值等于 arrives as 阈值等.

    Strip the stranded first character of the comparison verb when the claim
    shows the 于 right after it. Run on both the inventory and the Tier-2 raw
    index so the two key the same term.
    """
    if (len(term) - 1 >= _MIN_INVENTORY_LENGTH and term[-1] in "等大小高低多少优差"
            and term + "于" in claim_text):
        # 上限值或小於 leaves the alternative's 或 behind too.
        return term[:-2] if term[-2] == "或" and len(term) - 2 >= _MIN_INVENTORY_LENGTH else term[:-1]
    return term


def _strip_comparison_verb_cn(term: str) -> str:
    for verb in _CN_COMPARISON_VERBS:
        if term.endswith(verb):
            head = term[: -len(verb)]
            if len(head) >= _MIN_INVENTORY_LENGTH and not head.endswith(("或", "及", "与", "和")):
                return head
            break
    return term


def _build_inventory_cn(
    claims: list[Claim],
    *,
    contamination_terms: frozenset[str],
    strict_qualifier_matching: bool = False,
) -> list[tuple[int, str]]:
    """Build deduped claim-term inventory from intros across all claims.

    Returns a list of ``(claim_id, normalized_term)`` pairs. Terms
    flagged by the antecedent walker as ``category="tw_contamination"``
    (该等/该些 residue from 繁转简 conversion) are skipped - they're
    parser-level artifacts, not native CN terms worth checking.
    """
    seen: dict[str, int] = {}
    inventory: list[tuple[int, str]] = []
    deferred: list[tuple[int, str]] = []
    for claim in claims:
        pairs = extract_introductions_cn(
            claim,
            strict_qualifier_matching=strict_qualifier_matching,
        )
        claim_norms = {norm for _orig, norm in pairs}
        for orig, norm in pairs:
            back_reference = _is_quantified_back_reference_cn(
                orig, norm, claim.text
            )
            if _MARKUSH_GROUP_CN_RE.match(orig) or (
                    orig in ("之群组", "的群组")
                    and _MARKUSH_GROUP_CN_RE.search(claim.text)):
                continue
            # A capture running into the frame keeps the alternative in front
            # of it (A、B和光干涉组成的群组 -> 光干涉). Mirror of TW.
            frame = _MARKUSH_GROUP_CN_RE.search(norm or orig)
            if frame:
                norm = (norm or orig)[: frame.start()]
                if len(norm) < _MIN_INVENTORY_LENGTH:
                    continue
            root = _strip_stranded_comparison_cn(
                _normalize_for_spec_support_cn(
                    norm or orig,
                    strict_qualifier_matching=strict_qualifier_matching,
                ),
                claim.text,
            )
            if not root:
                continue
            for final in _split_on_conjunction_cn(
                root,
                strict_qualifier_matching=strict_qualifier_matching,
            ):
                if not final or len(final) < _MIN_INVENTORY_LENGTH:
                    continue
                if len(final) > _MAX_INVENTORY_LENGTH:
                    continue
                if _has_leading_reject_cn(final) or _has_interior_reject_cn(final):
                    continue
                if _has_leading_conjunction_cn(final):
                    continue
                # R65: lexeme-gated leading 并 (并 + verb).
                if _has_leading_conj_bing_cn(final):
                    continue
                if final in _CN_GENERIC_TERMS or _is_boilerplate_cn(final):
                    continue
                # Wave F: a hyphen-led span is a formula fragment (一个或多个-L4-嵌段),
                # never an element name the description would spell the same way.
                if final[0] in "-－":
                    continue
                # A name never ends in the preposition 于 or a determiner
                # (以固定该): that is a verb phrase cut off before its object.
                # Comparison verbs were already stripped by the normalizer.
                # Mirror of TW (wave C).
                if final.endswith(("于", "该")) and not final.endswith("应该"):
                    continue
                if final in contamination_terms:
                    continue
                if _spans_two_introductions_cn(final, claim_norms):
                    continue
                if _is_parenthetical_gloss_cn(final, claim.text):
                    continue
                if back_reference:
                    deferred.append((claim.id, final))
                    continue
                if final in seen:
                    continue
                seen[final] = claim.id
                inventory.append((claim.id, final))
    inventory = _confirm_against_references_cn(inventory, claims)
    seen = {t: cid for cid, t in inventory}
    # A back-reference counts only when nothing introduced covers its head
    # (the extractor can miss the real introduction). Mirror of TW.
    for claim_id, final in deferred:
        core = _MEASURE_RESIDUE_CN_RE.sub("", final)
        if final in seen or any(core.startswith(t) for t in seen):
            continue
        seen[final] = claim_id
        inventory.append((claim_id, final))
    return inventory


# --- Tier matchers ---------------------------------------------------------


def _tier1_normalized_exact(norm_term: str, spec_text: str) -> bool:
    return norm_term in spec_text


def _tier2_raw_exact(raw_candidates: list[str], spec_text: str) -> bool:
    """True if any raw (unnormalized) intro candidate appears verbatim."""
    return any(raw and raw in spec_text for raw in raw_candidates)


def _tier3_char_window(norm_term: str, spec_text: str) -> bool:
    """True if all normalized-term bigrams co-occur within a ±window."""
    term_tokens = set(tokenize_cn(norm_term))
    if not term_tokens:
        return False
    for tok in term_tokens:
        if tok not in spec_text:
            return False
    window = _CHAR_WINDOW_SIZE
    spec_len = len(spec_text)
    if spec_len < window:
        return True
    for i in range(0, spec_len - window + 1):
        slice_ = spec_text[i:i + window]
        if all(tok in slice_ for tok in term_tokens):
            return True
    return False


# --- Public API ------------------------------------------------------------


def check_spec_support_cn(
    doc: CnPatentDocument,
    *,
    antecedent_findings: list[dict] | None = None,
    strict_qualifier_matching: bool = False,
) -> list[UnsupportedTerm]:
    """Check that claim noun phrases have support in the CNIPA specification.

    Per 专利法 §26 第4款 + 审查指南 第二部分第二章 §3.2.1. Three tiers
    (see module docstring). Tier 0 (symbol-table whitelist) intentionally
    absent - CN has no 符号说明 surface.

    When ``antecedent_findings`` is provided, terms flagged with
    ``category="tw_contamination"`` are skipped from the inventory so
    spec_support doesn't double-report parser-level 繁转简 artifacts.
    """
    if not doc.claims:
        return []

    contamination_terms: frozenset[str] = frozenset(
        item.get("term", "")
        for item in (antecedent_findings or [])
        if item.get("category") == "tw_contamination"
    )

    spec_text = _collect_spec_text_cn(doc)
    spec_text_bare = _strip_inline_ref_numerals_cn(spec_text)
    inventory = _build_inventory_cn(
        doc.claims,
        contamination_terms=contamination_terms,
        strict_qualifier_matching=strict_qualifier_matching,
    )

    # Pre-collect raw intro candidates per normalized term so Tier 2
    # can test every original span that produced this normalized form.
    raw_by_norm: dict[str, list[str]] = {}
    for claim in doc.claims:
        for orig, norm in extract_introductions_cn(
            claim,
            strict_qualifier_matching=strict_qualifier_matching,
        ):
            final = _strip_stranded_comparison_cn(
                _normalize_for_spec_support_cn(
                    norm or orig,
                    strict_qualifier_matching=strict_qualifier_matching,
                ),
                claim.text,
            )
            if not final:
                continue
            raw_by_norm.setdefault(final, []).append(orig)

    unsupported: list[UnsupportedTerm] = []

    for claim_id, norm_term in inventory:
        tiers: list[str] = []

        # Tier 1: normalized exact substring
        tiers.append("normalized_exact")
        if _tier1_normalized_exact(norm_term, spec_text):
            continue

        # Tier 2: raw exact substring
        tiers.append("raw_exact")
        if _tier2_raw_exact(raw_by_norm.get(norm_term, []), spec_text):
            continue

        # Tier 3: CJK character-window fallback
        tiers.append("char_window")
        if _tier3_char_window(norm_term, spec_text):
            continue

        # Tier 4 (R60): retry Tiers 1 + 3 against spec text with inline
        # 元件符号 removed. Strictly additive - runs only after the raw spec
        # text has already failed, so it can never lose an existing match.
        tiers.append("numeral_stripped")
        if _tier1_normalized_exact(norm_term, spec_text_bare) or _tier3_char_window(
            norm_term, spec_text_bare
        ):
            continue

        unsupported.append(UnsupportedTerm(
            claim_number=claim_id,
            phrase=norm_term,
            tiers_checked=tiers,
        ))

    return unsupported


def attach_cross_references_cn(
    antecedent_findings: list[dict],
    unsupported_terms: list[UnsupportedTerm],
) -> None:
    """Cross-link CN antecedent and spec-support findings on the same term.

    Mirrors ``attach_cross_references_tw``. When the same
    ``(claim_id, normalized_term)`` pair appears in both lists, each
    finding is annotated with a ``cross_ref`` pointing at the sibling
    check so the frontend renders a hint line.

    Mutates both lists in place.
    """
    ab_pairs: set[tuple[int, str]] = {
        (item["claim_id"], item.get("term", ""))
        for item in antecedent_findings
    }
    spec_pairs: set[tuple[int, str]] = {
        (ut.claim_number, ut.phrase) for ut in unsupported_terms
    }

    for item in antecedent_findings:
        if (item["claim_id"], item.get("term", "")) in spec_pairs:
            item["cross_ref"] = "spec_support"

    for ut in unsupported_terms:
        if (ut.claim_number, ut.phrase) in ab_pairs:
            ut.cross_ref = "antecedent"
